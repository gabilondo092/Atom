package utilities

import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions.col

object FilteredSave {

  def fGuardarFiltrados(poDF:DataFrame,pColumnKey:String,pRoute:String, filename: String):Unit={
    //poDF.select(pColumnKey).dropDuplicates().show(200,false)
//    println(poDF.select(pColumnKey).dropDuplicates().collect().map(_.toSeq).flatten.foreach( x =>{
//      println("El mes 1 es: "+x)
//    }))
    poDF.select(pColumnKey).orderBy(pColumnKey).dropDuplicates().collect().map(_.toSeq).flatten.
      foreach( x =>{
        //println("El mes es: "+x)
        SaveCSV.guardarDFEnCSV(poDF.filter(col(pColumnKey)===x),
          pRoute+"\\"+x,false,filename+"_"+x)
      })

    //poDF.select(pColumnKey).dropDuplicates()
    //      .collectAsList().toArray().toSeq.mkString(",").replaceAll("\\[|\\]|,","").

  }
}
