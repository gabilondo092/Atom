package utilities

import java.io.BufferedOutputStream

import org.apache.hadoop.fs.FileSystem
import org.apache.hadoop.fs.permission.{FsAction, FsPermission}
import org.apache.spark.sql.{DataFrame, SparkSession}


/**
 * Objeto que gestiona la sesión de Spark
 */
object SparkUtils {
  lazy val spark: SparkSession = obtenerSparkSession

  /**
   * Utilidad para unificar la obtención del SparkContext.
   *
   * @return SparkContext
   */
  private def obtenerSparkSession: SparkSession = {
    val spark = SparkSession.builder()
      .master("local[*]")
      .appName("generarCSV")
      //.enableHiveSupport()
      .getOrCreate()
    spark.sparkContext.setLogLevel("ERROR")
    spark.conf.set("spark.sql.streaming.schemaInference", true)
    // Los modos estrictos de particiones dinámicas requieren al menos una columna de partición estática.

    spark.sqlContext.setConf("hive.exec.dynamic.partition", "true")
    spark.sqlContext.setConf("hive.exec.dynamic.partition.mode", "nonstrict")
    spark
  }


  /**
   * Método encargado de cerrar el contexto de Spark.
   */
  def cerrarContexto(): Unit = {
    spark.close()
  }


  /**
    * Funcion que se encarga de guardar las tablas que se han procesado
    *
    * @param table     String con el nombre de la tabla a tratar.
    *
    */
  def writeTableOk(table: String, fs: FileSystem) = {
    val infoToWrite = table+"\n"
    writeToHDFS(table, fs, "SFSF/validacionGlobalF3/tablas_ok/",infoToWrite)


  }

  /**
    * Funcion que se encarga de guardar las tablas que se han procesado
    *
    * @param table     String con el nombre de la tabla a tratar.
    *
    */
  def writeCsvTable(table: String, fs: FileSystem, df: DataFrame) = {
    val infoToWrite = table+"\n"
    val path = new org.apache.hadoop.fs.Path("SFSF/validacionGlobalF3/tablas_ko/"+table)
    fs.delete(path,true)
    fs.create(path)
    fs.setPermission(path, new FsPermission(FsAction.ALL,FsAction.ALL,FsAction.ALL, true) )
    df.repartition(1).write.
      format("csv").
      option("header","true").
      option("encoding", "UTF-8").
      option("delimiter", ";")
      .csv(path.toString)
    //Escribes el csv a esa carpeta
    //writeToHDFS(table, fs, "SFSF/validacionGlobalF3/tablas_ko/",infoToWrite)


  }
  /**
    * Funcion que se encarga de generar un fichero con información en una ruta en HDFS
    *
    * @param table     String con el nombre de la tabla a tratar.
    *
    */
  def writeToHDFS(table: String, fs: FileSystem, pathToWrite:String, textToWrite:String) = {
    //Se escribe en HDFS, en la ruta /usr/onhr_master/application_id, el ID de la aplicación que se ha ejecutado en YARN.
    //  val processedPath = "hdfs://" + configProperties.nodo + Variables.Paths.PROCESSED_TABLES

    val path = new org.apache.hadoop.fs.Path(pathToWrite+table)
    fs.delete(path,true)
    val text = textToWrite
    val out = new BufferedOutputStream(fs.create(path))
    out.write(text.getBytes("UTF-8"))
    out.flush()
    out.close()

  }

}

