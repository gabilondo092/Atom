package utilities


import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions.{concat, format_string, lit, lower, row_number, when}

object CheckIdGlobal {

  def compruebaIDGlobal(df: DataFrame, nameMatricula: String) : DataFrame = {
    //println("Tamaño total df: "+df.count())
    val dfFilteredIDSFSFNULL = df.filter(df(Names.GENERAL_ID_SSFF).isNull
      .or(df(Names.GENERAL_ID_SSFF) === "")
      .or(df(Names.GENERAL_ID_SSFF) === "N/A")
      .or(df(Names.GENERAL_ID_SSFF) === "0")
      .or(df(Names.GENERAL_ID_SSFF) === "-")
      .or(df(Names.GENERAL_ID_SSFF) === "#N/D")
      .or(df(Names.GENERAL_ID_SSFF) === "pendente")
      .or(df(Names.GENERAL_ID_SSFF) === "no aplica")
      .or(df(Names.GENERAL_ID_SSFF) === "NA")
      .or(df(Names.GENERAL_ID_SSFF) === "#N/A")
      .or(df(Names.GENERAL_ID_SSFF) === "No posee ID de SSFF")
      .or(lower(df(Names.GENERAL_ID_SSFF)) === "no tiene")
    )
    //println("Tamaño filtrado: "+ dfFilteredIDSFSFNULL.count())
    if(dfFilteredIDSFSFNULL.count()>0) {
      //Hay valores de id sfsf sin informar

      val dfsinSFSFNULL = df.filter(df(Names.GENERAL_ID_SSFF).isNotNull
        .and(df(Names.GENERAL_ID_SSFF) =!= "")
        .and(df(Names.GENERAL_ID_SSFF) =!= "N/A")
        .and(df(Names.GENERAL_ID_SSFF) =!= "0")
        .and(df(Names.GENERAL_ID_SSFF) =!= "-")
        .and(df(Names.GENERAL_ID_SSFF) =!= "#N/D")
        .and(df(Names.GENERAL_ID_SSFF) =!= "pendente")
        .and(df(Names.GENERAL_ID_SSFF) =!= "no aplica")
        .and(df(Names.GENERAL_ID_SSFF) =!= "NA")
        .and(df(Names.GENERAL_ID_SSFF) =!= "#N/A")
        .and(df(Names.GENERAL_ID_SSFF) =!= "No posee ID de SSFF")
        .and(lower(df(Names.GENERAL_ID_SSFF)) =!= "no tiene")
      )
      //println("Tamaño sin null: "+ dfsinSFSFNULL.count())
      //dfFilteredIDSFSFNULL.select(dfFilteredIDSFSFNULL(nameMatricula)).distinct().show(50000,false)
      //Si ID_SFSF está sin informar tenemos que comprobar el valor de la matrícula
      //Ahora dentro de estos tenemos que filtrar los que tienen la matrícula vacía o a null
      //println("Tamaño a null sfsf que hay que recalcular: "+dfFilteredIDSFSFNULL.count())
      val matriculaFilterNull = dfFilteredIDSFSFNULL.filter(dfFilteredIDSFSFNULL(nameMatricula).isNull
        .or(df(nameMatricula) === "")
        .or(df(nameMatricula) === "N/A")
        .or(df(nameMatricula) === "0")
        .or(df(nameMatricula) === "-")
        .or(df(nameMatricula) === "#N/D")
        .or(df(nameMatricula) === "pendente")
        .or(df(nameMatricula) === "no aplica")
        .or(df(nameMatricula) === "NA")
        .or(df(nameMatricula) === "#N/A")
        .or(df(nameMatricula) === "No posee ID de SSFF")
        .or(lower(df(nameMatricula)) === "no tiene")
      )
      //println("Matriculas que cumplen el filtro: "+matriculaFilterNull.count())
      if (matriculaFilterNull.count() > 0) {
        //Si la matrícula no está filtrada trabajamos con esos campos
        //Primero hacemos un except para tener ya listos los valores con la matrícula informada
        val dfMatInformada = dfFilteredIDSFSFNULL.filter(dfFilteredIDSFSFNULL(nameMatricula).isNotNull
          .and(df(nameMatricula) =!= "")
          .and(df(nameMatricula) =!= "N/A")
          .and(df(nameMatricula) =!= "0")
          .and(df(nameMatricula) =!= "-")
          .and(df(nameMatricula) =!= "#N/D")
          .and(df(nameMatricula) =!= "pendente")
          .and(df(nameMatricula) =!= "no aplica")
          .and(df(nameMatricula) =!= "NA")
          .and(df(nameMatricula) =!= "#N/A")
          .and(df(nameMatricula) =!= "No posee ID de SSFF")
          .and(lower(df(nameMatricula)) =!= "no tiene")
        )
        //println("Matriculas informadas: "+dfMatInformada.count())
        val dfUnionFinalMatInfo=cambiaValorIdSFSFMatricula(dfMatInformada,nameMatricula)
        //Ahora para los valores sin matrícula informada tenemos que generar el nuevo valor
        val dfNuevaMatriculaGen = generateNewIdMatricula(matriculaFilterNull,nameMatricula)
        //Aqui tengo los valores con la matrícula no informada y asignados a ID_SSFF
        val dfUnionNuevaMat = dfNuevaMatriculaGen.withColumn(Names.GENERAL_ID_SSFF,dfNuevaMatriculaGen(nameMatricula))
        //devuelvo la union de los dos df con las matrículas y el df original
        val dffinal = dfsinSFSFNULL.union(dfUnionNuevaMat).union(dfUnionFinalMatInfo).withColumn(Names.GENERAL_ID_GLOBAL, df(Names.GENERAL_ID_SSFF))
        //println("df final devuelto despues validacion id global: "+dffinal.count())
        dffinal
      } else {
        //Como no hay ningún valor de la matrícula vacío/nulo se pone tanto en id_ssff como en el id global este valor
        dfsinSFSFNULL.union(cambiaValorIdSFSFMatricula(dfFilteredIDSFSFNULL,nameMatricula)
          )
          .withColumn(Names.GENERAL_ID_GLOBAL, df(Names.GENERAL_ID_SSFF))
      }


    }else{
      //No hay valores de SFSF a null o vacíos, se devuelve el df de entrada
      df
    }


  }

  def cambiaValorIdSFSFMatricula(df: DataFrame, nameMatricula: String) : DataFrame = {
    df
      .withColumn(Names.GENERAL_ID_SSFF,
        concat(df(Names.GENERAL_COD_LEGAL_ENTITY), lit("_"), df(nameMatricula)))
  }

  def generateNewIdMatricula(df: DataFrame, nameMatricula: String) : DataFrame = {
    val w = Window.orderBy(nameMatricula)
    val column_index = df
      .withColumn("index", row_number().over(w))

    column_index.withColumn(nameMatricula,
      concat(lit("ID_NA_M_"), format_string("%07d", column_index("index"))))
      .drop("index")
  }
}
