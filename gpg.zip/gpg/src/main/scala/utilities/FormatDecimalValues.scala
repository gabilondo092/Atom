package utilities

import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions.{col, regexp_replace, round, when}
import org.apache.spark.sql.types.DoubleType
object FormatDecimalValues {


  //Lo ideal que reciba un DF y formatee las columnas automáticamente
  def formatDecimalValues ( columnsToFormat: List[String],df: DataFrame):DataFrame={
    columnsToFormat match {
      case Nil => df
      case _ => {
//        println("Se cambia el formato del campo: "+columnsToFormat.head)
//        //df.printSchema()
//        //df.select(col(columnsToFormat.head)).show(false)
//        //df.filter(col(Names.GENERAL_ID_SSFF) === "7349773").show(false)
//        val a: DataFrame = df.withColumn(columnsToFormat.head,
//          when(col(columnsToFormat.head).isNull.or(col(columnsToFormat.head)==="0"),
//          "0.0").otherwise(col(columnsToFormat.head)))
//        //a.select(col(columnsToFormat.head)).show(false)
//        val b: DataFrame = a.withColumn(columnsToFormat.head,regexp_replace(a(columnsToFormat.head),",","."))
//        //b.select(col(columnsToFormat.head)).show(false)
//        //b.select(round(col(columnsToFormat.head).cast(DoubleType),2)).show(false)
//        //val c: DataFrame = b.withColumn(columnsToFormat.head,round(col(columnsToFormat.head).cast(DoubleType),2))
//        val c: DataFrame = b.withColumn(columnsToFormat.head, when(col(columnsToFormat.head)==="0.0",col(columnsToFormat.head))
//          .otherwise(col(columnsToFormat.head).cast("Decimal(20,2)")))

        //c.select(col(columnsToFormat.head)).show(false)

        formatDecimalValues(columnsToFormat.tail, formatDecimalValues(columnsToFormat.head, df))
      }
    }



  }

  def formatDecimalValues (column: String,df: DataFrame):DataFrame={

    //println("Se cambia el formato del campo: "+column)
    //df.printSchema()
    //df.select(col(column)).show(false)
    val a: DataFrame = df.withColumn(column,
      when(col(column).isNull.or(col(column)==="0"),
        "0.0").otherwise(col(column)))
    //a.select(col(column)).show(false)
    val b: DataFrame = a.withColumn(column,regexp_replace(a(column),",","."))
    //b.select(col(column)).show(false)
    //b.select(round(col(columnsToFormat.head).cast(DoubleType),2)).show(false)
    val c: DataFrame = b.withColumn(column, when(col(column)==="0.0",col(column))
                .otherwise(col(column).cast("Decimal(20,2)")))
    c


  }

}
