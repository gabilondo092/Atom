package utilities

import mapeo.Legal_entities
import org.apache.spark.sql.functions.col
import org.apache.spark.sql.types.StringType

object LegalEntitiesNotIncluded {

  def generarLENI(filen: Integer)={

    var file: String = null
    if(filen == 1 ) {
      file =Routes.PLN_HEADCOUNTS_FILENAME_1
    }else if(filen == 2){
      file =Routes.PLN_HEADCOUNTS_FILENAME_2
    }else if(filen == 3){
      file =Routes.PLN_HEADCOUNTS_FILENAME_3
    }
    //Convierto el fichero fuente en un DF
    val HST_HEADCOUNTS_TOT_DF = ReadExcel.leerCSVADF(file+".csv",false)
    val HST_HEADCOUNTS2_TOT_DF = HST_HEADCOUNTS_TOT_DF.select(
      col(Names.HST_PLN_COUNTRY).cast(StringType).as(Names.PLN_COUNTRY)
    ).distinct()
    println("lectura fichero: "+HST_HEADCOUNTS2_TOT_DF.count())
    HST_HEADCOUNTS2_TOT_DF.show(20,false)
    SaveCSV.guardarDFEnCSV(HST_HEADCOUNTS2_TOT_DF, System.getProperty("user.dir")+"\\PLN\\COUNTRY\\"+filen+"",
      true, file+"_countries.csv")

//    val legalEnt = new Legal_entities
//    val le = legalEnt.miDF.select(
//      col("Código Entidad Legal").cast(StringType).as(Names.GENERAL_COD_LEGAL_ENTITY),
//      col("Entidad Legal").as(Names.GENERAL_LEGAL_ENTITY)
//    )
//    println("fich legal entity: "+ le.count())
//    le.show(20,false)
//    val lene = HST_HEADCOUNTS2_TOT_DF.except(le)
//    println("le que no existen: "+lene.count())
//    lene.show(20,false)


  }
}
