package utilities

import org.apache.spark.sql.functions.udf

object GlobalIdGenerator {
  val generar_IDGLOBAL=udf((ID_SSFF:String,COD_LEGAL_ENTITY:String,ID_REGISTRATION:String)=>{
    if(ID_SSFF == null || ID_SSFF.isEmpty) COD_LEGAL_ENTITY+"_"+ID_REGISTRATION
    else ID_SSFF
  })
}
