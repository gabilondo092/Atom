package utilities

import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.types.StructType

object ReadExcel {
  def leerExcelADF(pFile: String, pPerisit: Boolean): DataFrame = {

    //val input = new FileInputStream(new File(getClass.getResource("/"+pFile).getPath))

    if (pPerisit) {
      SparkUtils.spark.read.format("com.crealytics.spark.excel").
        //  option("dataAddress", "INFO").
        option("useHeader", "true").
        option("charset", "ISO-8859-1").
        option("treatEmptyValuesAsNulls", "true").
        //option("inferSchema", "true").
        option("maxRowsInMemory", 10000).
        option("addColorColumns", "false").
        //load("hdfs://euhsuf0092fxmpp.serv.dc.tg.telefonica:8020/user/onhr_master/SFSF/GPG/"+pFile)
        load("C:\\Users\\galcaraz\\Documents\\Telefonica\\pruebas\\" + pFile).persist()
      //new FileInputStream(new File(getClass.getResource("/"+pFile).getPath))
    } else {
      SparkUtils.spark.read.format("com.crealytics.spark.excel").
        //  option("dataAddress", "INFO").
        option("useHeader", "true").
        option("treatEmptyValuesAsNulls", "true").
        //option("inferSchema", "true").
        option("addColorColumns", "false").
                //load("hdfs://euhsuf0092fxmpp.serv.dc.tg.telefonica:8020/user/onhr_master/SFSF/GPG/"+pFile)
        load("C:\\Users\\galcaraz\\Documents\\Telefonica\\pruebas\\" + pFile)
    }

  }

  def leerExcelADFWithEschema(pFile: String, pPerisit: Boolean, schema: StructType): DataFrame = {
    if (pPerisit) {
      SparkUtils.spark.read.format("com.crealytics.spark.excel").
        //  option("dataAddress", "INFO").
        option("useHeader", "true").
        option("treatEmptyValuesAsNulls", "true").
        //option("inferSchema", "true").
        option("addColorColumns", "false").
        schema(schema).
        load("hdfs://euhsuf0092fxmpp.serv.dc.tg.telefonica:8020/user/onhr_master/SFSF/GPG/" + pFile).persist()
    } else {
      SparkUtils.spark.read.format("com.crealytics.spark.excel").
        //  option("dataAddress", "INFO").
        option("useHeader", "true").
        option("treatEmptyValuesAsNulls", "true").
        //option("inferSchema", "true").
        option("addColorColumns", "false").
        schema(schema).
        load("hdfs://euhsuf0092fxmpp.serv.dc.tg.telefonica:8020/user/onhr_master/SFSF/GPG/" + pFile)

    }


  }

  def leerCSVADF(pFile: String, pPerisit: Boolean): DataFrame = {
      leerCSVADF(pFile,"C:\\Users\\galcaraz\\Documents\\Telefonica\\pruebas\\" + pFile,pPerisit)
    }

    def leerCSVADF(pFile: String,ruta: String, pPerisit: Boolean): DataFrame = {
      leerCSVADF(pFile,ruta,pPerisit,true)
  }
  def leerCSVExcel(pFile: String, pPerisit: Boolean): DataFrame ={
    leerCSVADF(pFile,"C:\\Users\\galcaraz\\Documents\\Telefonica\\pruebas\\" + pFile,pPerisit,false)
  }

  def leerCSVADF(pFile: String,ruta: String, pPerisit: Boolean, utf8: Boolean): DataFrame = {
    var df : DataFrame = null
    if(utf8){
      df = SparkUtils.spark.read.
        format("csv").
        // option("dataSheet", "00_Cabecera").
        //option("encoding", "ISO-8859-1").
        option("delimiter", ";").
        option("header", "true").
        option("inferSchema", "true").
        //load("hdfs://euhsuf0092fxmpp.serv.dc.tg.telefonica:8020/user/onhr_master/SFSF/GPG/"+pFile)
        load(ruta)
    }else{
      df = SparkUtils.spark.read.
        format("csv").
        // option("dataSheet", "00_Cabecera").
        option("encoding", "ISO-8859-1").
        option("delimiter", ";").
        option("header", "true").
        option("inferSchema", "true").
        //load("hdfs://euhsuf0092fxmpp.serv.dc.tg.telefonica:8020/user/onhr_master/SFSF/GPG/"+pFile)
        load(ruta)
    }

    if (pPerisit) {
      df.persist()
    } else{
      df
    }

  }
}