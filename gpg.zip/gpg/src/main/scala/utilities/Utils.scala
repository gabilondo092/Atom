package utilities

import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions.col

object Utils {

  def getValorDeDf(DF:DataFrame,ColumnIn:String, ColumnOut:String,ValKey:String):String={
    DF.select(col(ColumnOut)).filter(DF.col(ColumnIn)===ValKey).collectAsList().get(0).get(0).toString
  }
}
