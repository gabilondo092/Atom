package utilities

import org.apache.spark.sql.DataFrame

import scala.tools.nsc.io.Path
object SaveCSV {
  def guardarDFEnCSV(pDF:DataFrame,pPaht:String,pBUnpersit:Boolean, filename:String):Unit={
    //println("Se guarda el fichero: "+filename + " con lineas: "+pDF.count())
    //val pathToWrite: String = System.getProperty("user.dir")+"\\"+pPaht
    pDF.repartition(1).// si vemos que el fichero es muy pesado, se puede quitar este atributo
      write.
      mode("overwrite").
      option("header","true").
      option("encoding", "UTF-8").
      option("delimiter", ";").
      csv(pPaht)

    println("CSV guardado")
    //Se guardan los ficheros sin el nombre de salida esperado, ya que pone part-0000
    // actualizamos el nombre del fichero

        val regex_filename="""part.*\.csv""".r
        val regex_filename_delete="""^[\.|_].*""".r

        val values = Path.apply(pPaht).toDirectory.files map (_.name) flatMap { case n @ regex_filename() => Some(n) case _ => None }
        val values_delete = Path.apply(pPaht).toDirectory.files map (_.name) flatMap { case n @ regex_filename_delete() => Some(n) case _ => None }
        val wrongFilename = values.toList.head
       new java.io.File(pPaht+"\\"+wrongFilename).renameTo(new java.io.File(pPaht+"\\"+filename+".csv"))
        values_delete.toList.map(filename => {new java.io.File(pPaht+"\\"+filename).delete()})
    if(pBUnpersit)
      pDF.unpersist()
  }
}
