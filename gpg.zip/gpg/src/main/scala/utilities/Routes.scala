package utilities

object Routes {

  //val GPG_MAIN_OUT_DIR="hdfs://euhsuf0092fxmpp.serv.dc.tg.telefonica:8020/user/onhr_master/GPG/GPG"
  val GPG_MAIN_OUT_DIR=System.getProperty("user.dir")+"\\GPG\\GPG"
  val GPG_MAIN_OUT_DIR2=System.getProperty("user.dir")+"\\GPG\\GPG\\FINAL"
  //val GPG_OTHERS_OUT_DIR="hdfs://euhsuf0092fxmpp.serv.dc.tg.telefonica:8020/user/onhr_master/GPG/GPG_OTHERS"
  val GPG_OTHERS_OUT_DIR=System.getProperty("user.dir")+"\\GPG\\GPG_OTHERS"
  val GPG_OTHERS_OUT_DIR_2=System.getProperty("user.dir")+"\\GPG\\GPG_OTHERS\\FINAL"
  val GPG_IN_DIR ="C:\\Users\\galcaraz\\Documents\\Telefonica\\pruebas"
  val GPG_MAIN_IN_FILE="GPG_pru_Info.csv"
  val GPG_BENEF_DET_IN_FILE="GPG_pru_benef_det.csv"
  val GPG_OTHER_BENEF_IN_FILE="GPG_pru_benef_other.csv"
  val GPG_FILENAME="GPG"
  val GPG_OTHERS_FILENAME="GPG_Others"

  val PLN_HEADCOUNTS_OUT_DIR_F1=System.getProperty("user.dir")+"\\PLN\\HEADCOUNTS\\F1"
  val PLN_HEADCOUNTS_OUT_DIR_2=System.getProperty("user.dir")+"\\PLN\\HEADCOUNTS\\F1\\FINAL"
  val PLN_HEADCOUNTS_OUT_DIR_F2=System.getProperty("user.dir")+"\\PLN\\HEADCOUNTS\\F2"
  val PLN_HEADCOUNTS_OUT_DIR_3=System.getProperty("user.dir")+"\\PLN\\HEADCOUNTS\\F2\\FINAL"
  val PLN_HEADCOUNTS_OUT_DIR_F3=System.getProperty("user.dir")+"\\PLN\\HEADCOUNTS\\F3"
  val PLN_HEADCOUNTS_OUT_DIR_4=System.getProperty("user.dir")+"\\PLN\\HEADCOUNTS\\F3\\FINAL"
  val PLN_HEADCOUNTS_IN_DIR="C:\\Users\\galcaraz\\Documents\\Telefonica\\pruebas"
  val PLN_HEADCOUNTS_FILENAME_1="RRHH Export Headcount Rework_Ene_Abr"
  val PLN_HEADCOUNTS_FILENAME_2="RRHH Export Headcount Rework_May_Ago"
  val PLN_HEADCOUNTS_FILENAME_3="RRHH Export Headcount Rework_Sep_Dic"
  val PLN_HEADCOUNTS_OUT_ERROR_DIR=System.getProperty("user.dir")+"\\PLN\\HEADCOUNTS\\ERROR"

  val PLN_ALTAS_OUT_DIR=System.getProperty("user.dir")+"\\PLN\\ALTAS"
  val PLN_ALTAS_OUT_DIR_2=System.getProperty("user.dir")+"\\PLN\\ALTAS\\FINAL"
  val PLN_ALTAS_IN_DIR="C:\\Users\\galcaraz\\Documents\\Telefonica\\pruebas"
  val PLN_ALTAS_FILENAME="RRHH Export Altas Rework_2019"
  val PLN_BAJAS_OUT_DIR=System.getProperty("user.dir")+"\\PLN\\BAJAS"
  val PLN_BAJAS_OUT_DIR_2=System.getProperty("user.dir")+"\\PLN\\BAJAS\\FINAL"
  val PLN_BAJAS_IN_DIR="C:\\Users\\galcaraz\\Documents\\Telefonica\\pruebas"
  val PLN_BAJAS_FILENAME="RRHH Export Bajas Rework_2019"
  val PLN_BAJAS_PICKLIST_OUT=System.getProperty("user.dir")+"\\PLN\\PICKLIST\\BAJAS"
  val PLN_ALTAS_PICKLIST_OUT=System.getProperty("user.dir")+"\\PLN\\PICKLIST\\ALTAS"
  val PLN_HEADCOUNTS_PICKLIST_OUT=System.getProperty("user.dir")+"\\PLN\\PICKLIST\\HEADCOUNT"


}
