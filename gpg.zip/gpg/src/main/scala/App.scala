import org.apache.hadoop.fs.FileSystem
import pln.{Altas, AltasValidated, Bajas, BajasValidated, Headcount, HeadcountValidated, ValidationPicklistHeadCount}
import processgpg.{FinalCSVGPG, GPGOtros, GPGOtrosValidated, GPGValidated}
import utilities.{CheckIdGlobal, LegalEntitiesNotIncluded, SparkUtils}

object App extends App {

  System.setProperty("hadoop.home.dir", "C:\\bin")

  println("Se inicia la ejecución de la transformación")
  val spark = SparkUtils.spark
  val conf = spark.sparkContext.hadoopConfiguration
  val fs : FileSystem = org.apache.hadoop.fs.FileSystem.get(conf)

  //FinalCSVGPG.generaCSVGPG()
  //GPGValidated.validacionesGPG()
//  GPGOtros.generarGPGOtros()
//  GPGOtrosValidated.validacionesGPGOtros()
//  Headcount.generarHeadcount(1)
//  Headcount.generarHeadcount(2)
//  Headcount.generarHeadcount(3)
 // HeadcountValidated.validar(1)
 // HeadcountValidated.validar(2)
 // HeadcountValidated.validar(3)
 // Altas.generarAltas()
 AltasValidated.validarAltas
 // Bajas.generarBajas()
  BajasValidated.validar


  println("Finaliza la ejecución de la transformacion")
}
