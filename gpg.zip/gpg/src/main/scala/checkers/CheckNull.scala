package checkers

import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions.when
import utilities.Names

object CheckNull {



  def checkNull(df:DataFrame,isCode: Boolean, column:String) ={
    if(!isCode){
      df.withColumn(column,
        when(df(column).isNull,
          "Desconocido").
          otherwise(df(column))).dropDuplicates()
    }else{
      df.withColumn(column,
        when(df(column).isNull,
          "0").
          otherwise(df(column))).dropDuplicates()
    }

  }


  def changeNullToDecimal(df:DataFrame, column:String) ={

      df.withColumn(column,
        when(df(column).isNull,
          "0.00").
          otherwise(df(column))).dropDuplicates()

  }
}
