package checkers

import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions.{col, concat, format_string, lit, row_number}
import utilities.{Names, SparkUtils}

object TratamientoDuplicados {

  def compruebaGeneraNuevosDuplicadosDF(df: DataFrame) = {
    import SparkUtils.spark.implicits._
    //println("Tamaño df original: " + df.dropDuplicates().count())

    //Hay que sacar los valores duplicados para la pk ID_GLOBAL, COD_LEGAL_ENTITY, MONTH, YEAR
    val valoresDuplicadosDF = df
      .select(
        Names.GENERAL_MONTH,
        Names.GENERAL_YEAR,
        Names.GENERAL_COD_LEGAL_ENTITY,
        Names.GENERAL_ID_GLOBAL,
        Names.PLN_LEAVERS_DATE)
      .groupBy(
        Names.GENERAL_MONTH,
        Names.GENERAL_YEAR,
        Names.GENERAL_COD_LEGAL_ENTITY,
        Names.GENERAL_ID_GLOBAL,
        Names.PLN_LEAVERS_DATE)
      .count().filter("count > 1").drop("count")
      .withColumn("id", concat(df(Names.GENERAL_MONTH),
        df(Names.GENERAL_YEAR),
        df(Names.GENERAL_COD_LEGAL_ENTITY),
        df(Names.GENERAL_ID_GLOBAL),
        df(Names.PLN_LEAVERS_DATE)))
      .withColumnRenamed(Names.GENERAL_MONTH, Names.GENERAL_MONTH + "_nd")
      .withColumnRenamed(Names.GENERAL_YEAR, Names.GENERAL_YEAR + "_nd")
      .withColumnRenamed(Names.GENERAL_COD_LEGAL_ENTITY, Names.GENERAL_COD_LEGAL_ENTITY + "_nd")
      .withColumnRenamed(Names.GENERAL_ID_GLOBAL, Names.GENERAL_ID_GLOBAL + "_nd")
      .withColumnRenamed(Names.PLN_LEAVERS_DATE, Names.PLN_LEAVERS_DATE + "_nd").dropDuplicates()

    //println("Valores con duplicados: "+valoresDuplicadosDF.count())
    if (valoresDuplicadosDF.count() > 0) {
      //println("Existen duplicados")
      //Forma con id autogenerado
      val dftvni = df.withColumn("id", concat(df(Names.GENERAL_MONTH),
        df(Names.GENERAL_YEAR),
        df(Names.GENERAL_COD_LEGAL_ENTITY),
        df(Names.GENERAL_ID_GLOBAL),
        df(Names.PLN_LEAVERS_DATE))).dropDuplicates()

      //con anti join, valores duplicados y original df
      val todosValoresSinDuplicados = dftvni.as("tb1").join(valoresDuplicadosDF.as("tb2"),
        $"tb1.id" === $"tb2.id", "leftanti"
      ).drop("id")

     // println("Todos los valores sin duplicados : " + todosValoresSinDuplicados.count())
//      FilteredSave.fGuardarFiltrados(todosValoresSinDuplicados,Names.GENERAL_MONTH,
//        Routes.PLN_HEADCOUNTS_OUT_DIR, Routes.PLN_HEADCOUNTS_FILENAME+"_duplicados")

      /**
       * Ya hemos generado el archivo sin los duplicados, ahora vamos a generar los nuevos ID
       */
      val todosValoresConDuplicados = valoresDuplicadosDF.join(df,
        (df(Names.GENERAL_MONTH) === valoresDuplicadosDF(Names.GENERAL_MONTH + "_nd"))
          .and(df(Names.GENERAL_YEAR) === valoresDuplicadosDF(Names.GENERAL_YEAR + "_nd"))
          .and(df(Names.GENERAL_COD_LEGAL_ENTITY) === valoresDuplicadosDF(Names.GENERAL_COD_LEGAL_ENTITY + "_nd"))
          .and(df(Names.GENERAL_ID_GLOBAL) === valoresDuplicadosDF(Names.GENERAL_ID_GLOBAL + "_nd"))
          .and(df(Names.PLN_LEAVERS_DATE) === valoresDuplicadosDF(Names.PLN_LEAVERS_DATE + "_nd")))
        .drop(Names.GENERAL_MONTH + "_nd",
          Names.GENERAL_YEAR + "_nd",
          Names.GENERAL_COD_LEGAL_ENTITY + "_nd",
          Names.GENERAL_ID_GLOBAL + "_nd",
          Names.PLN_LEAVERS_DATE + "_nd",
          "id")


      //todosValoresConDuplicados.show(1000000,false)

      /*
      Una vez que tenemos todos los valores con los duplicados ahora recalculamos los ig_globales
      con id ficticios como ID_NA_0000001
       */
      val w = Window.orderBy(Names.GENERAL_ID_GLOBAL)
      val column_index = todosValoresConDuplicados
        //.withColumnRenamed(Names.GENERAL_ID_GLOBAL, Names.GENERAL_ID_GLOBAL+"_nd")
        .withColumn("index", row_number().over(w))

      val indiceNuevo = column_index.withColumn(Names.GENERAL_ID_GLOBAL,
        concat(lit("ID_NA_PK_"), format_string("%07d", column_index("index"))))
        .drop("index")
      //println("resultado final")
      //indiceNuevo.show(false)
      //indiceNuevo.filter(indiceNuevo("ID_REGISTRATION").isNull).orderBy(indiceNuevo("MONTH")).show(5000, false)
      //indiceNuevo.show(3000000,false)
//      println("Tamaño df original: " + df.count() + " tamaño duplicados: " + indiceNuevo.count()
//        + " tamaño df sin duplicados: " + todosValoresSinDuplicados.count())
      val dffinal = todosValoresSinDuplicados.union(indiceNuevo).withColumn(Names.GENERAL_ID_SSFF,col(Names.GENERAL_ID_GLOBAL))
      //dffinal.filter(dffinal("ID_REGISTRATION").isNull.and(dffinal("MONTH") === "1")).show(500, false)
      //println("tamaño final que se guarda: "+dffinal.count())
      dffinal
    } else {
      println("No existen duplicados se devuelve el df original")
      df
    }

  }


  def compruebaGeneraNuevosDuplicadosDFBajas(df: DataFrame) = {
    import SparkUtils.spark.implicits._
    //println("Tamaño df original: " + df.dropDuplicates().count())

    //Hay que sacar los valores duplicados para la pk ID_GLOBAL, COD_LEGAL_ENTITY, MONTH, YEAR
    val valoresDuplicadosDF = df
      .select(
        Names.GENERAL_MONTH,
        Names.GENERAL_YEAR,
        Names.GENERAL_COD_LEGAL_ENTITY,
        Names.GENERAL_ID_GLOBAL,
        Names.PLN_LEAVERS_DATE)
      .groupBy(
        Names.GENERAL_MONTH,
        Names.GENERAL_YEAR,
        Names.GENERAL_COD_LEGAL_ENTITY,
        Names.GENERAL_ID_GLOBAL,
        Names.PLN_LEAVERS_DATE)
      .count().filter("count > 1").drop("count")
      .withColumn("id", concat(df(Names.GENERAL_MONTH),
        df(Names.GENERAL_YEAR),
        df(Names.GENERAL_COD_LEGAL_ENTITY),
        df(Names.GENERAL_ID_GLOBAL),
        df(Names.PLN_LEAVERS_DATE)))
      .withColumnRenamed(Names.GENERAL_MONTH, Names.GENERAL_MONTH + "_nd")
      .withColumnRenamed(Names.GENERAL_YEAR, Names.GENERAL_YEAR + "_nd")
      .withColumnRenamed(Names.GENERAL_COD_LEGAL_ENTITY, Names.GENERAL_COD_LEGAL_ENTITY + "_nd")
      .withColumnRenamed(Names.GENERAL_ID_GLOBAL, Names.GENERAL_ID_GLOBAL + "_nd")
      .withColumnRenamed(Names.PLN_LEAVERS_DATE, Names.PLN_LEAVERS_DATE + "_nd").dropDuplicates()

    //println("Valores con duplicados: "+valoresDuplicadosDF.count())
    if (valoresDuplicadosDF.count() > 0) {
      //println("Existen duplicados")
      //Forma con id autogenerado
      val dftvni = df.withColumn("id", concat(df(Names.GENERAL_MONTH),
        df(Names.GENERAL_YEAR),
        df(Names.GENERAL_COD_LEGAL_ENTITY),
        df(Names.GENERAL_ID_GLOBAL),
        df(Names.PLN_LEAVERS_DATE))).dropDuplicates()

      //con anti join, valores duplicados y original df
      val todosValoresSinDuplicados = dftvni.as("tb1").join(valoresDuplicadosDF.as("tb2"),
        $"tb1.id" === $"tb2.id", "leftanti"
      ).drop("id")

      // println("Todos los valores sin duplicados : " + todosValoresSinDuplicados.count())
      //      FilteredSave.fGuardarFiltrados(todosValoresSinDuplicados,Names.GENERAL_MONTH,
      //        Routes.PLN_HEADCOUNTS_OUT_DIR, Routes.PLN_HEADCOUNTS_FILENAME+"_duplicados")

      /**
       * Ya hemos generado el archivo sin los duplicados, ahora vamos a generar los nuevos ID
       */
      val todosValoresConDuplicados = valoresDuplicadosDF.join(df,
        (df(Names.GENERAL_MONTH) === valoresDuplicadosDF(Names.GENERAL_MONTH + "_nd"))
          .and(df(Names.GENERAL_YEAR) === valoresDuplicadosDF(Names.GENERAL_YEAR + "_nd"))
          .and(df(Names.GENERAL_COD_LEGAL_ENTITY) === valoresDuplicadosDF(Names.GENERAL_COD_LEGAL_ENTITY + "_nd"))
          .and(df(Names.GENERAL_ID_GLOBAL) === valoresDuplicadosDF(Names.GENERAL_ID_GLOBAL + "_nd"))
          .and(df(Names.PLN_LEAVERS_DATE) === valoresDuplicadosDF(Names.PLN_LEAVERS_DATE + "_nd")))
        .drop(Names.GENERAL_MONTH + "_nd",
          Names.GENERAL_YEAR + "_nd",
          Names.GENERAL_COD_LEGAL_ENTITY + "_nd",
          Names.GENERAL_ID_GLOBAL + "_nd",
          Names.PLN_LEAVERS_DATE + "_nd",
          "id")


      //todosValoresConDuplicados.show(1000000,false)

      /*
      Una vez que tenemos todos los valores con los duplicados ahora recalculamos los ig_globales
      con id ficticios como ID_NA_0000001
       */
      val w = Window.orderBy(Names.GENERAL_ID_GLOBAL)
      val column_index = todosValoresConDuplicados
        //.withColumnRenamed(Names.GENERAL_ID_GLOBAL, Names.GENERAL_ID_GLOBAL+"_nd")
        .withColumn("index", row_number().over(w))

      val indiceNuevo = column_index.withColumn(Names.GENERAL_ID_GLOBAL,
        concat(lit("ID_NA_PK_"), format_string("%07d", column_index("index"))))
        .drop("index")
      //println("resultado final")
      //indiceNuevo.show(false)
      //indiceNuevo.filter(indiceNuevo("ID_REGISTRATION").isNull).orderBy(indiceNuevo("MONTH")).show(5000, false)
      //indiceNuevo.show(3000000,false)
      //      println("Tamaño df original: " + df.count() + " tamaño duplicados: " + indiceNuevo.count()
      //        + " tamaño df sin duplicados: " + todosValoresSinDuplicados.count())
      val dffinal = todosValoresSinDuplicados.union(indiceNuevo).withColumn(Names.GENERAL_ID_SSFF,col(Names.GENERAL_ID_GLOBAL))
      //dffinal.filter(dffinal("ID_REGISTRATION").isNull.and(dffinal("MONTH") === "1")).show(500, false)
      //println("tamaño final que se guarda: "+dffinal.count())
      dffinal
    } else {
      println("No existen duplicados se devuelve el df original")
      df
    }

  }

  def compruebaGeneraNuevosDuplicadosDFOther(df: DataFrame) = {
    import SparkUtils.spark.implicits._
    //println("Tamaño df original: " + df.dropDuplicates().count())

    //Hay que sacar los valores duplicados para la pk ID_GLOBAL, COD_LEGAL_ENTITY, MONTH, YEAR
    val valoresDuplicadosDF = df
      .select(
        Names.GENERAL_MONTH,
        Names.GENERAL_YEAR,
        Names.GENERAL_COD_LEGAL_ENTITY,
        Names.GENERAL_ID_GLOBAL,
        Names.GPG_OB_TYPE_EXPENSE,
        Names.GPG_OB_REASON)
      .groupBy(
        Names.GENERAL_MONTH,
        Names.GENERAL_YEAR,
        Names.GENERAL_COD_LEGAL_ENTITY,
        Names.GENERAL_ID_GLOBAL,
        Names.GPG_OB_TYPE_EXPENSE,
        Names.GPG_OB_REASON)
      .count().filter("count > 1").drop("count")
      .withColumn("id", concat(df(Names.GENERAL_MONTH),
        df(Names.GENERAL_YEAR),
        df(Names.GENERAL_COD_LEGAL_ENTITY),
        df(Names.GENERAL_ID_GLOBAL),
        df(Names.GPG_OB_TYPE_EXPENSE),
        df(Names.GPG_OB_REASON)
      ))
      .withColumnRenamed(Names.GENERAL_MONTH, Names.GENERAL_MONTH + "_nd")
      .withColumnRenamed(Names.GENERAL_YEAR, Names.GENERAL_YEAR + "_nd")
      .withColumnRenamed(Names.GENERAL_COD_LEGAL_ENTITY, Names.GENERAL_COD_LEGAL_ENTITY + "_nd")
      .withColumnRenamed(Names.GENERAL_ID_GLOBAL, Names.GENERAL_ID_GLOBAL + "_nd")
      .withColumnRenamed(Names.GPG_OB_TYPE_EXPENSE, Names.GPG_OB_TYPE_EXPENSE + "_nd")
      .withColumnRenamed(Names.GPG_OB_REASON, Names.GPG_OB_REASON + "_nd").dropDuplicates()

    //println("Valores con duplicados: "+valoresDuplicadosDF.count())
    if (valoresDuplicadosDF.count() > 0) {
      //println("Existen duplicados")
      //Forma con id autogenerado
      val dftvni = df.withColumn("id", concat(df(Names.GENERAL_MONTH),
        df(Names.GENERAL_YEAR),
        df(Names.GENERAL_COD_LEGAL_ENTITY),
        df(Names.GENERAL_ID_GLOBAL),
        df(Names.GPG_OB_TYPE_EXPENSE),
        df(Names.GPG_OB_REASON))).dropDuplicates()

      //con anti join, valores duplicados y original df
      val todosValoresSinDuplicados = dftvni.as("tb1").join(valoresDuplicadosDF.as("tb2"),
        $"tb1.id" === $"tb2.id", "leftanti"
      ).drop("id")

      // println("Todos los valores sin duplicados : " + todosValoresSinDuplicados.count())
      //      FilteredSave.fGuardarFiltrados(todosValoresSinDuplicados,Names.GENERAL_MONTH,
      //        Routes.PLN_HEADCOUNTS_OUT_DIR, Routes.PLN_HEADCOUNTS_FILENAME+"_duplicados")

      /**
       * Ya hemos generado el archivo sin los duplicados, ahora vamos a generar los nuevos ID
       */
      val todosValoresConDuplicados = valoresDuplicadosDF.join(df,
        (df(Names.GENERAL_MONTH) === valoresDuplicadosDF(Names.GENERAL_MONTH + "_nd"))
          .and(df(Names.GENERAL_YEAR) === valoresDuplicadosDF(Names.GENERAL_YEAR + "_nd"))
          .and(df(Names.GENERAL_COD_LEGAL_ENTITY) === valoresDuplicadosDF(Names.GENERAL_COD_LEGAL_ENTITY + "_nd"))
          .and(df(Names.GENERAL_ID_GLOBAL) === valoresDuplicadosDF(Names.GENERAL_ID_GLOBAL + "_nd"))
          .and(df(Names.GPG_OB_TYPE_EXPENSE) === valoresDuplicadosDF(Names.GPG_OB_TYPE_EXPENSE + "_nd"))
          .and(df(Names.GPG_OB_REASON) === valoresDuplicadosDF(Names.GPG_OB_REASON + "_nd")))
        .drop(Names.GENERAL_MONTH + "_nd",
          Names.GENERAL_YEAR + "_nd",
          Names.GENERAL_COD_LEGAL_ENTITY + "_nd",
          Names.GPG_OB_TYPE_EXPENSE + "_nd",
          Names.GPG_OB_REASON + "_nd",
          "id")


      //todosValoresConDuplicados.show(1000000,false)

      /*
      Una vez que tenemos todos los valores con los duplicados ahora recalculamos los ig_globales
      con id ficticios como ID_NA_0000001
       */
      val w = Window.orderBy(Names.GENERAL_ID_GLOBAL)
      val column_index = todosValoresConDuplicados
        //.withColumnRenamed(Names.GENERAL_ID_GLOBAL, Names.GENERAL_ID_GLOBAL+"_nd")
        .withColumn("index", row_number().over(w))

      val indiceNuevo = column_index.withColumn(Names.GENERAL_ID_GLOBAL,
        concat(lit("ID_NA_PK_"), format_string("%07d", column_index("index"))))
        .drop("index")
      //println("resultado final")
      //indiceNuevo.show(false)
      //indiceNuevo.filter(indiceNuevo("ID_REGISTRATION").isNull).orderBy(indiceNuevo("MONTH")).show(5000, false)
      //indiceNuevo.show(3000000,false)
      //      println("Tamaño df original: " + df.count() + " tamaño duplicados: " + indiceNuevo.count()
      //        + " tamaño df sin duplicados: " + todosValoresSinDuplicados.count())
      val dffinal = todosValoresSinDuplicados.union(indiceNuevo).withColumn(Names.GENERAL_ID_SSFF,col(Names.GENERAL_ID_GLOBAL))
      //dffinal.filter(dffinal("ID_REGISTRATION").isNull.and(dffinal("MONTH") === "1")).show(500, false)
      //println("tamaño final que se guarda: "+dffinal.count())
      dffinal
    } else {
      println("No existen duplicados se devuelve el df original")
      df
    }

  }



}
