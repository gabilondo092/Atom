package generacionpicklist

import checkers.CheckNull
import org.apache.spark.sql.functions.col
import org.apache.spark.sql.types.{IntegerType, StringType}
import utilities.{Names, ReadExcel, Routes, SaveCSV}

object GeneracionPicklistsAltas {

  def generaPicklistAltas()={
    val HST_ALTAS_TOT_DF = ReadExcel.leerCSVADF( Routes.PLN_ALTAS_FILENAME+".csv", false)
    HST_ALTAS_TOT_DF.show(200, false)
    println("tamaño fichero: "+ HST_ALTAS_TOT_DF.count())
    val PLN_HIST_ALTAS2_TOT = HST_ALTAS_TOT_DF
      .select(
        //   col(Names.GENERAL_YEAR),
        col(Names.HST_PLN_IDMONTH).cast(IntegerType).as(Names.GENERAL_MONTH),
        col(Names.HST_PLN_COD_LEGAL_ENTITY).cast(StringType).as(Names.GENERAL_COD_LEGAL_ENTITY),
        col(Names.HST_PLN_REPORTED_LEGAL_ENTITY).as(Names.GENERAL_LEGAL_ENTITY),
        col(Names.HST_GENERAL_ID_SSFF).cast(StringType).as(Names.GENERAL_ID_SSFF),
        col(Names.HST_PLN_ID_REGISTRATION).cast(StringType).as(Names.GENERAL_ID_REGISTRATION),
        col(Names.HST_PLN_ALT_BAJ_GENDER).as(Names.GENERAL_GENDER),
        col(Names.HST_PLN_ALT_BAJ_BIRTH_DATE).as(Names.PLN_BIRTH_DATE),
        col( Names.HST_PLN_ALT_STARTERS_DATE).as(Names.PLN_STARTERS_DATE),
        col(Names.HST_PLN_ALT_STARTERS_LOCAL_TYPE).as(Names.PLN_STARTERS_LOCAL_TYPE),
        col( Names.HST_PLN_ALT_STARTERS_GLOBAL_TYPE).as(Names.PLN_STARTERS_GLOBAL_TYPE),
        col( Names.HST_PLN_BUSINESS_UNIT).as(Names.PLN_BUSINESS_UNIT),
        col( Names.HST_PLN_ALT_BAJ_EMPLOYEE_CLASS).as(Names.PLN_EMPLOYEE_CLASS),
        col( Names.HST_PLN_NOMBRE_PUESTO).as(Names.PLN_LOCAL_CATEGORY),
        col( Names.HST_PLN_GLOBAL_CATEGORY).as(Names.PLN_GLOBAL_CATEGORY),
        col( Names.HST_PLN_SUBACTIVITY).as(Names.PLN_SUBACTIVITY)
      ).dropDuplicates()

    val GENDER_OK= CheckNull.checkNull(PLN_HIST_ALTAS2_TOT,true,Names.GENERAL_GENDER)
    SaveCSV.guardarDFEnCSV(GENDER_OK.select(Names.GENERAL_GENDER).distinct(), Routes.PLN_ALTAS_PICKLIST_OUT+"\\"+Names.GENERAL_GENDER, true, "ALTAS_PICKLIST_"+Names.GENERAL_GENDER)
    val EMPLOYE_CLASS_OK = CheckNull.checkNull(GENDER_OK,false,Names.PLN_EMPLOYEE_CLASS)
    SaveCSV.guardarDFEnCSV(EMPLOYE_CLASS_OK.select(Names.PLN_EMPLOYEE_CLASS).distinct(), Routes.PLN_ALTAS_PICKLIST_OUT+"\\"+Names.PLN_EMPLOYEE_CLASS, true, "ALTAS_PICKLIST_"+Names.PLN_EMPLOYEE_CLASS)
    val GLOBAL_CATEGORY_OK = CheckNull.checkNull(EMPLOYE_CLASS_OK,false,Names.PLN_GLOBAL_CATEGORY)
    SaveCSV.guardarDFEnCSV(GLOBAL_CATEGORY_OK.select(Names.PLN_GLOBAL_CATEGORY).distinct(), Routes.PLN_ALTAS_PICKLIST_OUT+"\\"+Names.PLN_GLOBAL_CATEGORY, true, "ALTAS_PICKLIST_"+Names.PLN_GLOBAL_CATEGORY)
    //val LOCAL_CATEGORY_OK = CheckNull.checkNull(GLOBAL_CATEGORY_OK,false,Names.PLN_LOCAL_CATEGORY)
    //SaveCSV.guardarDFEnCSV(LOCAL_CATEGORY_OK.select(Names.PLN_LOCAL_CATEGORY).distinct(), Routes.PLN_ALTAS_PICKLIST_OUT, true, "ALTAS_PICKLIST_"+Names.PLN_LOCAL_CATEGORY)
    //val STARTERS_LOCAL_TYPE_OK = CheckNull.checkNull(LOCAL_CATEGORY_OK,false,Names.PLN_STARTERS_LOCAL_TYPE)
    //SaveCSV.guardarDFEnCSV(STARTERS_LOCAL_TYPE_OK.select(Names.PLN_STARTERS_LOCAL_TYPE).distinct(), Routes.PLN_ALTAS_PICKLIST_OUT, true, "ALTAS_PICKLIST_"+Names.PLN_STARTERS_LOCAL_TYPE)
    val STARTERS_GLOBAL_TYPE_OK = CheckNull.checkNull(GLOBAL_CATEGORY_OK,false,Names.PLN_STARTERS_GLOBAL_TYPE)
    SaveCSV.guardarDFEnCSV(STARTERS_GLOBAL_TYPE_OK.select(Names.PLN_STARTERS_GLOBAL_TYPE).distinct(), Routes.PLN_ALTAS_PICKLIST_OUT+"\\"+Names.PLN_STARTERS_GLOBAL_TYPE, true, "ALTAS_PICKLIST_"+Names.PLN_STARTERS_GLOBAL_TYPE)
    val COD_LEGAL_ENTITY_OK = CheckNull.checkNull(STARTERS_GLOBAL_TYPE_OK, false,Names.GENERAL_COD_LEGAL_ENTITY)
    SaveCSV.guardarDFEnCSV(COD_LEGAL_ENTITY_OK.select(Names.GENERAL_COD_LEGAL_ENTITY).distinct(), Routes.PLN_ALTAS_PICKLIST_OUT+"\\"+Names.GENERAL_COD_LEGAL_ENTITY, true, "ALTAS_PICKLIST_"+Names.GENERAL_COD_LEGAL_ENTITY)
    val BUSSINESS_UNIT_OK = CheckNull.checkNull(COD_LEGAL_ENTITY_OK,false,Names.PLN_BUSINESS_UNIT)
    SaveCSV.guardarDFEnCSV(BUSSINESS_UNIT_OK.select(Names.PLN_BUSINESS_UNIT).distinct(), Routes.PLN_ALTAS_PICKLIST_OUT+"\\"+Names.PLN_BUSINESS_UNIT, true, "ALTAS_PICKLIST_"+Names.PLN_BUSINESS_UNIT)
    val SUBACTIVITY_OK = CheckNull.checkNull(BUSSINESS_UNIT_OK,false,Names.PLN_SUBACTIVITY)
    SaveCSV.guardarDFEnCSV(SUBACTIVITY_OK.select(Names.PLN_SUBACTIVITY).distinct(), Routes.PLN_ALTAS_PICKLIST_OUT+"\\"+Names.PLN_SUBACTIVITY, true, "ALTAS_PICKLIST_"+Names.PLN_SUBACTIVITY)

  }
}
