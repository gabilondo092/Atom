package processgpg

import checkers.TratamientoDuplicados
import mapeo.Benefits
import org.apache.spark.sql.{DataFrame, Row}
import org.apache.spark.sql.functions.{col, lit, when}
import org.apache.spark.sql.types.{DoubleType, StringType, StructField, StructType}
import utilities.{FormatDecimalValues, Names, ReadExcel, Routes, SaveCSV, SparkUtils}

object GPGOtros {

  def fPivotar_Benef_Otr(pDF: DataFrame): DataFrame = {

    println(pDF.count())
    /**
     * Este método pivota todas las columnas del DF ordenándolas en dos nuevas columnas
     * REASON -> Cuyo valor es el de la antigua columna
     * AMOUNT -> Cuyo valor es el valor de la antigua columna
     * En este caso NO se pivotan 2 columnas
     * ID_SSFF-> Porque es la PK del nuevo DF
     * Total-> Porque es un valor acumulativo que no se va a ingestar (dicho valor será calculado por la aplicación)
     */

    val schema_Benef_otr = pDF.schema.toList
    // Definimos la estructura que del nuevo DF, y lo creamos  vacío

    val schema = StructType(
      StructField(Names.HST_GENERAL_ID_SSFF, StringType, true) ::
        StructField(Names.GPG_OB_TYPE_EXPENSE, StringType, true) ::
        StructField(Names.GPG_OB_REASON, StringType, true) ::
        StructField(Names.GPG_OB_AMOUNT_LOCAL, StringType, true) :: Nil
    )

    //pDF.show(2,false)

    var benef_OTR_PIVOT = SparkUtils.spark.createDataFrame(SparkUtils.spark.sparkContext.emptyRDD[Row], schema)

  //  var conta = 1;

    //Realizamos el pivotado a base de realizar UNION de la select de las diferentes columnas
    schema_Benef_otr.foreach(StructField => {



      //println("Nombre: "+StructField.name)
      if (!StructField.name.equals(Names.HST_GENERAL_ID_SSFF) && !StructField.name.equals("Total")) {
        println(StructField.dataType)
        println(StructField.metadata)
        println(StructField.name)
        println(StructField.nullable)
        val part = pDF.select(col(Names.HST_GENERAL_ID_SSFF), col(StructField.name).as(Names.GPG_OB_AMOUNT_LOCAL)).
          filter(col(StructField.name).isNotNull && col(StructField.name) =!= "0").
          withColumn(Names.GPG_OB_TYPE_EXPENSE, lit(1)).
          withColumn(Names.GPG_OB_REASON, lit(StructField.name))
        //part.show(2,false)
        val part_order = part.select(Names.HST_GENERAL_ID_SSFF, Names.GPG_OB_TYPE_EXPENSE, Names.GPG_OB_REASON, Names.GPG_OB_AMOUNT_LOCAL)
        //part_order.show(2,false)
        print(part_order.count())

        if(StructField.name.contains("prov aguinaldo cuenta ser")){
          part_order.show(200,false)
        }

//        SaveCSV.guardarDFEnCSV(part_order, "C:\\pruebas", true,conta+"_"+StructField.name.charAt(0))

        benef_OTR_PIVOT = benef_OTR_PIVOT.union(part_order)

  //      conta = conta+1


      }
    })
 //   benef_OTR_PIVOT.show()
 //   println("benef_OTR_PIVOT "+benef_OTR_PIVOT.count())
  //  println("benef_OTR_PIVOT - dropduplicates "+benef_OTR_PIVOT.count())

    benef_OTR_PIVOT
  }
  def generarGPGOtros(): Unit ={
    /*
       El nuevo fichero GPG_OTHERS se crea a partir del fichero de beneficios_determinados
       y del fichero de otros_beneficios.
       Lo que haremos será adaptar la estructura de dichos ficheros históricos a la del nuevo
       fichero GPG_OTHERS, y luego realizar un UNION entre ambos.
    */
    //Del fichero Beneficios determinados, sólo nos interesan en este caso
    //los campos de ID_SSF y OTHER_BENEFITS
    val GPG_HIST_BENEF_DET = ReadExcel.leerCSVExcel(Routes.GPG_BENEF_DET_IN_FILE, false)
      .select(col(Names.HST_GENERAL_ID_SSFF).as(Names.GENERAL_ID_SSFF),
              col(Names.HST_GPG_OTHER_BENEFITS).as(Names.GPG_OB_AMOUNT_LOCAL))
    val dfGPG = ReadExcel.leerCSVADF("GPG_final.csv",Routes.GPG_MAIN_OUT_DIR2,true,true)



    println("dfGPG"+ " - "+ dfGPG.dropDuplicates().count())
    println("GPG_HIST_BENEF_DET - " +GPG_HIST_BENEF_DET.count())

 //   dfGPG.show(2000)
  //  GPG_HIST_BENEF_DET.show(2000)


   // val expensesSheet = new Benefits
    //GPG_HIST_BENEF_DET.show(5,false)
    //println("hist benf det: "+GPG_HIST_BENEF_DET.count())
    /**
     * Pasamos a la hoja excel de otros beneficios.
     * Aquí   TYPE_EXPENSE =1 también
     * */
    //println("Se lee la hoja de otros beneficios")
    // Pasamos el fichero otros_beneficios a  DF
    val GPG_HIST_BENEF_OTR = ReadExcel.leerCSVExcel(Routes.GPG_OTHER_BENEF_IN_FILE, false).dropDuplicates()
    //println("Count otros beneficios: "+ GPG_HIST_BENEF_OTR.count())
    //GPG_HIST_BENEF_OTR.show(5,false)
    /**
     * ********* Según el cliente TYPE_EXPENSE es siempre 1
     **/
    //Del fichero Beneficios determinados, sólo nos interesan en este caso
    //los campos de ID_SSF y OTHER_BENEFITS

    val GPG_HIST_BENEF_DET_2ND = GPG_HIST_BENEF_DET.
      filter(col(Names.GPG_OB_AMOUNT_LOCAL).isNotNull && col(Names.HST_GPG_OTHER_BENEFITS).notEqual("0")).
      withColumn(Names.GPG_OB_TYPE_EXPENSE, lit("Otros beneficios")).
      withColumn(Names.GPG_OB_REASON, lit(Names.HST_GPG_OTHER_BENEFITS)).dropDuplicates()

  //  GPG_HIST_BENEF_DET_2ND.show(2000)


    //println("primera parte fichero otros")
    //println("benef det filtrado: "+GPG_HIST_BENEF_DET_2ND.count())
    //GPG_HIST_BENEF_DET_2ND.show(5,false)
    //Ordenamos la estructura que vamos a querer y creamos un DF variable al que se le puedan
    //añadir registros.

   // GPG_HIST_BENEF_DET_2ND.show(2000)


    val GPG_PIVOT = GPG_HIST_BENEF_DET_2ND.select(
      col(Names.GENERAL_ID_SSFF),
      col(Names.GPG_OB_TYPE_EXPENSE),
      col(Names.GPG_OB_REASON),
      col(Names.GPG_OB_AMOUNT_LOCAL)).dropDuplicates()


    //println("Ya se ha creado el DF variable")
   // GPG_PIVOT.show(false)


    //Realizamos la unión de los 2 DF con la estructura correcta
    //En el caso de otros_beneficios, dicha estructura se consigue con el método
    // fPivotar_Benef_Otr
    //println("Se hace la union de otros beneficios")
  // println("pivote")
 //   fPivotar_Benef_Otr(GPG_HIST_BENEF_OTR).show(2000)

    val GPG_PIVOT_1 = GPG_PIVOT.union(fPivotar_Benef_Otr(GPG_HIST_BENEF_OTR)).dropDuplicates()
  //  GPG_PIVOT_1.show(false)

    println("GPG_PIVOT "+GPG_PIVOT.count())
    println("GPG_HIST_BENEF_OTR "+fPivotar_Benef_Otr(GPG_HIST_BENEF_OTR).count())
    println(GPG_PIVOT_1.count())

    SaveCSV.guardarDFEnCSV(GPG_PIVOT_1, "C:\\Users\\galcaraz\\Documents\\pruebas", true,"pivot_1")

    //   GPG_PIVOT_1.show(2000,false)

    // Se realiza un  join con GPG_MAIN, de manera que  los campos clave coincidan
    // De la misma forma, se seleccionan los campos en el orden de salida correcto.
    //println("Se realiza un join con el principal con id global para ver tener todos los datos")
    val GPG_OTROS_OUT = GPG_PIVOT_1.
      join(dfGPG, GPG_PIVOT_1(Names.GENERAL_ID_SSFF) === dfGPG(Names.GENERAL_ID_SSFF), "leftouter").
      select(
        dfGPG.col(Names.GENERAL_MONTH),
        dfGPG.col(Names.GENERAL_YEAR),
        dfGPG.col(Names.GENERAL_COD_LEGAL_ENTITY),
        //GPG_PIVOT_1.col(Names.GENERAL_ID_SSFF),
        dfGPG.col(Names.GENERAL_ID_GLOBAL),
        dfGPG.col(Names.GENERAL_LEGAL_ENTITY),
        GPG_PIVOT_1.col(Names.GPG_OB_TYPE_EXPENSE),
        GPG_PIVOT_1.col(Names.GPG_OB_REASON),
        GPG_PIVOT_1.col(Names.GPG_OB_AMOUNT_LOCAL)
      ).filter(dfGPG(Names.GENERAL_COD_LEGAL_ENTITY).isNotNull)

    println("dfGPG"+ " - "+ dfGPG.count())

    println("DF FINAL"+ " - "+GPG_OTROS_OUT.count())
//    GPG_OTROS_OUT.show(2000)

    //GPG_OTROS_OUT.show(50,false)
   //.orderBy(GPG_ORDERED_FINAL.col(Names.GENERAL_ID_GLOBAL))

    //println("count antes formateo: "+GPG_OTROS_OUT.count())
    //val GPG_OTROS_OUT_FINAL_1 = FormatDecimalValues.formatDecimalValues(Names.GPG_OB_AMOUNT_LOCAL,GPG_OTROS_OUT_FINAL).dropDuplicates()
    //GPG_OTROS_OUT_FINAL_1.show(false)
    //Join para cambiar type expense por el texto
    //println("Se cambia el type expense por el texto haciendo un join")
    SaveCSV.guardarDFEnCSV(GPG_OTROS_OUT, Routes.GPG_OTHERS_OUT_DIR, true, Routes.GPG_OTHERS_FILENAME)
        //Se realiza otro Join para sacar el código de Entidad legal en cuestión.
//        println("tamaño join: "+GPG_OTROS_OUT_FINAL_1.count())
//        //println("join, campo español?")
//        //GPG_OTROS_OUT_FINAL.show(5,false)
//        val GPG_OTROS_OUT_FINAL_PL = GPG_OTROS_OUT_FINAL.
//          join(expensesSheet.miDF,
//            expensesSheet.miDF(Names.COD_BENEFITS) === GPG_OTROS_OUT_FINAL_1.col(Names.GPG_OB_TYPE_EXPENSE),
//            "leftouter"
//          ).select(
//          GPG_OTROS_OUT_FINAL.col(Names.GENERAL_MONTH),
//          GPG_OTROS_OUT_FINAL.col(Names.GENERAL_YEAR),
//          GPG_OTROS_OUT_FINAL.col(Names.GENERAL_COD_LEGAL_ENTITY),
//          GPG_OTROS_OUT_FINAL.col(Names.GENERAL_ID_GLOBAL),
//          GPG_OTROS_OUT_FINAL.col(Names.GENERAL_LEGAL_ENTITY),
//          expensesSheet.miDF(Names.COLUMN_BENEFIT_VALUE),
//          GPG_OTROS_OUT_FINAL.col(Names.GPG_OB_REASON),
//          GPG_OTROS_OUT_FINAL.col(Names.GPG_OB_AMOUNT_LOCAL)
//        ).withColumnRenamed(Names.COLUMN_BENEFIT_VALUE,Names.GPG_OB_TYPE_EXPENSE)
//          .withColumn(Names.GENERAL_ID_GLOBAL,
//            when(GPG_OTROS_OUT_FINAL(Names.GPG_OB_TYPE_EXPENSE) === "1",
//              lit("Otros beneficios")).
//              otherwise(GPG_OTROS_OUT_FINAL(Names.GPG_OB_TYPE_EXPENSE))).dropDuplicates()
//
//     //Finalmente, se escribe el fichero GPG_OTROS
//    GPG_OTROS_OUT_FINAL.show(false)
//     println("El df final a guardar gpg otros es este: ")
//    GPG_OTROS_OUT_FINAL_PL.show(false)



  }
}
