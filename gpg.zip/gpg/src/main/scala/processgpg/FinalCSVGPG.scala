package processgpg

import checkers.TratamientoDuplicados
import mapeo.{Benefits, Legal_entities}
import org.apache.spark.sql.functions.{col, concat, format_number, lit, trim, when}
import org.apache.spark.sql.types.StringType
import utilities.{CheckIdGlobal, Names, ReadExcel, Routes, SaveCSV}

object FinalCSVGPG {

  def generaCSVGPG(): Unit ={
    //Leemos  los ficheros históricos de GPG y GPG_BENEFICIOS DETERMINADOS, transformándolos así en DF
    val GPG_HIST_GEN_DF = ReadExcel.leerCSVExcel(Routes.GPG_MAIN_IN_FILE, false)
    //GPG_HIST_GEN_DF.show(false)
    //println("hist gen: "+GPG_HIST_GEN_DF.count())
    val GPG_HIST_BENEF_DET = ReadExcel.leerCSVExcel(Routes.GPG_BENEF_DET_IN_FILE, false)
    //    GPG_HIST_BENEF_DET.show(false)
    //println("hist benf det: "+GPG_HIST_BENEF_DET.count())
    //Realizamos un Join de los mismos ya que en el nuevo fichero GPG principal se compone de casi la todalidad
    // de estos dos DF
    val expensesSheet = new Benefits
    //expensesSheet.miDF.show(false)


    val GPG_JOIN =
      GPG_HIST_GEN_DF.join(GPG_HIST_BENEF_DET,
        GPG_HIST_GEN_DF(Names.HST_GENERAL_ID_SSFF) === GPG_HIST_BENEF_DET(Names.HST_GENERAL_ID_SSFF)
        , "leftouter" //"left_outer"
      ).
        select(

          GPG_HIST_GEN_DF.col(Names.HST_GENERAL_LEGAL_ENTITY).as(Names.GENERAL_LEGAL_ENTITY).cast(StringType),
          GPG_HIST_GEN_DF.col(Names.HST_GENERAL_ID_SSFF).as(Names.GENERAL_ID_SSFF),
          GPG_HIST_GEN_DF.col(Names.HST_GPG_ID_REGISTRATION).as(Names.GENERAL_ID_REGISTRATION),
          GPG_HIST_GEN_DF.col(Names.HST_GPG_EMAIL).as(Names.GENERAL_EMAIL),
          GPG_HIST_GEN_DF.col(Names.GPG_GID).as(Names.GPG_GID),
          GPG_HIST_GEN_DF.col(Names.HST_GPG_COD_MARKET_REFERENCE).as(Names.GPG_COD_MARKET_REFERENCE),
          GPG_HIST_GEN_DF.col(Names.HST_GPG_LOCAL_PAYMENT_CURRENCY).as(Names.GPG_LOCAL_PAYMENT_CURRENCY),
          GPG_HIST_GEN_DF.col(Names.HST_GPG_ANNUAL_BASE_SALARY_LOCAL).as(Names.GPG_ANNUAL_BASE_SALARY_LOCAL),
          GPG_HIST_GEN_DF.col(Names.HST_GPG_PCT_THEORETICAL_BONUS_LOCAL).as(Names.GPG_PCT_THEORETICAL_BONUS_LOCAL),
          GPG_HIST_GEN_DF.col(Names.HST_GPG_BONUS_TARGET_LOCAL).as(Names.GPG_BONUS_TARGET_LOCAL),
          GPG_HIST_GEN_DF.col(Names.HST_GPG_REAL_PAID_BONUS_LOCAL).as(Names.GPG_REAL_PAID_BONUS_LOCAL),
          GPG_HIST_GEN_DF.col(Names.HST_GPG_PCT_COMMISSION_TARGET_LOCAL).as(Names.GPG_PCT_COMMISSION_TARGET_LOCAL),
          GPG_HIST_GEN_DF.col(Names.HST_GPG_REAL_PAID_COMMISSIONS_LOCAL).as(Names.GPG_REAL_PAID_COMMISSIONS_LOCAL),
          GPG_HIST_BENEF_DET.col(Names.HST_GPG_SOCIAL_SECURITY_LOCAL).as(Names.GPG_SOCIAL_SECURITY_LOCAL),
          GPG_HIST_BENEF_DET.col(Names.HST_GPG_MEAL_TICKETS_LOCAL).as(Names.GPG_MEAL_TICKETS_LOCAL),
          GPG_HIST_BENEF_DET.col(Names.HST_GPG_HEALTH_INSURANCE_LOCAL).as(Names.GPG_HEALTH_INSURANCE_LOCAL),
          GPG_HIST_BENEF_DET.col(Names.HST_GPG_LIFE_INSURANCE_LOCAL).as(Names.GPG_LIFE_INSURANCE_LOCAL),
          GPG_HIST_BENEF_DET.col(Names.HST_GPG_ACCIDENT_INSURANCE_LOCAL).as(Names.GPG_ACCIDENT_INSURANCE_LOCAL),
          GPG_HIST_BENEF_DET.col(Names.HST_GPG_CAR_ALLOWANCE_LOCAL).as(Names.GPG_CAR_ALLOWANCE_LOCAL),
          GPG_HIST_BENEF_DET.col(Names.HST_GPG_EXPAT_BENEFITS_LOCAL).as(Names. GPG_EXPAT_BENEFITS_LOCAL),
          GPG_HIST_BENEF_DET.col(Names.HST_GPG_ATAM_LOCAL).as(Names.GPG_ATAM_LOCAL),
          GPG_HIST_BENEF_DET.col(Names.HST_GPG_ALBENTURE_LOCAL).as(Names.GPG_ALBENTURE_LOCAL),
          GPG_HIST_BENEF_DET.col(Names.HST_GPG_TRANSPORT_PLUS_LOCAL).as(Names.GPG_TRANSPORT_PLUS_LOCAL),
          GPG_HIST_BENEF_DET.col(Names.HST_GPG_PCF_STOCK_LOCAL).as(Names.GPG_PCF_STOCK_LOCAL),
          GPG_HIST_BENEF_DET.col(Names.HST_GPG_AVAILABILITY_PLUS_LOCAL).as(Names.GPG_AVAILABILITY_PLUS_LOCAL),
          GPG_HIST_BENEF_DET.col(Names.HST_GPG_MOVISTAR_SHARED_PAYMENT_LOCAL).as(Names.GPG_MOVISTAR_SHARED_PAYMENT_LOCAL),
          GPG_HIST_BENEF_DET.col(Names.HST_GPG_BENEFIT_PER_CHILD_LOCAL).as(Names.GPG_BENEFIT_PER_CHILD_LOCAL),
          GPG_HIST_BENEF_DET.col(Names.HST_GPG_STAFF_RELATED_COSTS_LOCAL).as(Names.GPG_STAFF_RELATED_COSTS_LOCAL),
          GPG_HIST_BENEF_DET.col(Names.HST_GPG_PCT_PENSION_PLAN_LOCAL).as(Names.GPG_PCT_PENSION_PLAN_LOCAL)
        ).withColumn(Names.GENERAL_LEGAL_ENTITY, trim(col(Names.GENERAL_LEGAL_ENTITY)))

    //println("Se hace el join de los dos primeros")
    //La clase Legal_Entities se utiliza como tabla auxiliar proviniente del PickList para sacar el código de la entidad legal
    // ya que en el fichero principal sólo tenemos la descripción de dicha entidad
    val legalEnt = new Legal_entities
    //Se realiza otro Join para sacar el código de Entidad legal en cuestión.

    val GPG_SELECT = GPG_JOIN.
      join(legalEnt.miDF,
        legalEnt.miDF(Names.HST_GENERAL_LEGAL_ENTITY) === GPG_JOIN.col(Names.GENERAL_LEGAL_ENTITY),
        "leftouter"
      ).select(
      legalEnt.miDF(Names.HST_GENERAL_COD_LEGAL_ENTITY).as(Names.GENERAL_COD_LEGAL_ENTITY).cast(StringType),
      GPG_JOIN(Names.GENERAL_LEGAL_ENTITY),
      GPG_JOIN(Names.GENERAL_ID_SSFF),
      GPG_JOIN(Names.GENERAL_ID_REGISTRATION),
      GPG_JOIN(Names.GENERAL_EMAIL),
      GPG_JOIN(Names.GPG_GID),
      GPG_JOIN(Names.GPG_COD_MARKET_REFERENCE),
      GPG_JOIN(Names.GPG_LOCAL_PAYMENT_CURRENCY),
      GPG_JOIN(Names.GPG_ANNUAL_BASE_SALARY_LOCAL),
      GPG_JOIN(Names.GPG_PCT_THEORETICAL_BONUS_LOCAL),
      GPG_JOIN(Names.GPG_BONUS_TARGET_LOCAL),
      GPG_JOIN(Names.GPG_REAL_PAID_BONUS_LOCAL),
      GPG_JOIN(Names.GPG_PCT_COMMISSION_TARGET_LOCAL),
      GPG_JOIN(Names.GPG_REAL_PAID_COMMISSIONS_LOCAL),
      GPG_JOIN(Names.GPG_SOCIAL_SECURITY_LOCAL),
      GPG_JOIN(Names.GPG_MEAL_TICKETS_LOCAL),
      GPG_JOIN(Names.GPG_HEALTH_INSURANCE_LOCAL),
      GPG_JOIN(Names.GPG_LIFE_INSURANCE_LOCAL),
      GPG_JOIN(Names.GPG_ACCIDENT_INSURANCE_LOCAL),
      GPG_JOIN(Names.GPG_CAR_ALLOWANCE_LOCAL),
      GPG_JOIN(Names.GPG_EXPAT_BENEFITS_LOCAL),
      GPG_JOIN(Names.GPG_ATAM_LOCAL),
      GPG_JOIN(Names.GPG_ALBENTURE_LOCAL),
      GPG_JOIN(Names.GPG_TRANSPORT_PLUS_LOCAL),
      GPG_JOIN(Names.GPG_PCF_STOCK_LOCAL),
      GPG_JOIN(Names.GPG_AVAILABILITY_PLUS_LOCAL),
      GPG_JOIN(Names.GPG_MOVISTAR_SHARED_PAYMENT_LOCAL),
      GPG_JOIN(Names.GPG_BENEFIT_PER_CHILD_LOCAL),
      GPG_JOIN(Names.GPG_STAFF_RELATED_COSTS_LOCAL),
      GPG_JOIN(Names.GPG_PCT_PENSION_PLAN_LOCAL)
    ).  //además se añaden 4 campos nuevos utilizando withColumn
      withColumn(Names.GENERAL_YEAR, lit(2019)).
      withColumn(Names.GENERAL_MONTH, lit(12)).
      withColumn(Names.GPG_PSP_TFSP_LOCAL, format_number(lit(0), 1)). //--> Campo nuevo con valor 0.0
      withColumn(Names.GPG_RSP_OTHERS_ILPs_LOCAL, format_number(lit(0), 1)) //--> Campo nuevo con valor 0.0
    GPG_JOIN.unpersist()
    //println("Se obtiene la legal entity del fichero")
    // GPG_SELECT.show(false)
    //println("count antes de chek id global: "+GPG_SELECT.count())
    val GPG_SELECT_2 = CheckIdGlobal.compruebaIDGlobal(GPG_SELECT,Names.GENERAL_ID_REGISTRATION)
    GPG_SELECT.unpersist()
    //println("Se calcula el campo id global ")
    // se ordenan los campos de salida
    val GPG_ORDERED = GPG_SELECT_2.select(
      col(Names.GENERAL_MONTH),
      col(Names.GENERAL_YEAR),
      col(Names.GENERAL_COD_LEGAL_ENTITY),
      col(Names.GENERAL_ID_GLOBAL),
      col(Names.GENERAL_LEGAL_ENTITY),
      col(Names.GENERAL_ID_SSFF),
      col(Names.GENERAL_ID_REGISTRATION),
      col(Names.GENERAL_EMAIL),
      col(Names.GPG_GID),
      col(Names.GPG_COD_MARKET_REFERENCE),
      col(Names.GPG_LOCAL_PAYMENT_CURRENCY),
      col(Names.GPG_ANNUAL_BASE_SALARY_LOCAL),//
      col(Names.GPG_PCT_THEORETICAL_BONUS_LOCAL),//
      col(Names.GPG_BONUS_TARGET_LOCAL),//
      col(Names.GPG_REAL_PAID_BONUS_LOCAL),//
      col(Names.GPG_PCT_COMMISSION_TARGET_LOCAL),//
      col(Names.GPG_REAL_PAID_COMMISSIONS_LOCAL),//
      col(Names.GPG_PSP_TFSP_LOCAL),//
      col(Names.GPG_RSP_OTHERS_ILPs_LOCAL),//
      col(Names.GPG_SOCIAL_SECURITY_LOCAL),//
      col(Names.GPG_MEAL_TICKETS_LOCAL),//
      col(Names.GPG_HEALTH_INSURANCE_LOCAL),//
      col(Names.GPG_LIFE_INSURANCE_LOCAL),//
      col(Names.GPG_ACCIDENT_INSURANCE_LOCAL),//
      col(Names.GPG_CAR_ALLOWANCE_LOCAL),//
      col(Names.GPG_EXPAT_BENEFITS_LOCAL),//
      col(Names.GPG_ATAM_LOCAL),//
      col(Names.GPG_ALBENTURE_LOCAL),//
      col(Names.GPG_TRANSPORT_PLUS_LOCAL),//
      col(Names.GPG_PCF_STOCK_LOCAL),//
      col(Names.GPG_AVAILABILITY_PLUS_LOCAL),//
      col(Names.GPG_MOVISTAR_SHARED_PAYMENT_LOCAL),//
      col(Names.GPG_BENEFIT_PER_CHILD_LOCAL),//
      col(Names.GPG_STAFF_RELATED_COSTS_LOCAL),//
      col(Names.GPG_PCT_PENSION_PLAN_LOCAL)//
    )
    GPG_SELECT_2.unpersist()
    //println("Se ordenan los campos de salida")
    SaveCSV.guardarDFEnCSV(TratamientoDuplicados.compruebaGeneraNuevosDuplicadosDF(GPG_ORDERED.dropDuplicates()), Routes.GPG_MAIN_OUT_DIR, true, Routes.GPG_FILENAME)
  }


}
