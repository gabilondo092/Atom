package processgpg

import checkers.TratamientoDuplicados
import mapeo.{Benefits, Legal_entities}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types._
import org.apache.spark.sql.{DataFrame, Row}
import utilities._

class Gpg {

  def fPivotar_Benef_Otr(pDF: DataFrame): DataFrame = {

    /**
     * Este método pivota todas las columnas del DF ordenándolas en dos nuevas columnas
     * REASON -> Cuyo valor es el de la antigua columna
     * AMOUNT -> Cuyo valor es el valor de la antigua columna
     * En este caso NO se pivotan 2 columnas
     * ID_SSFF-> Porque es la PK del nuevo DF
     * Total-> Porque es un valor acumulativo que no se va a ingestar (dicho valor será calculado por la aplicación)
     */

    val schema_Benef_otr = pDF.schema.toList
    // Definimos la estructura que del nuevo DF, y lo creamos  vacío
    val schema = StructType(
      StructField(Names.HST_GENERAL_ID_SSFF, StringType, true) ::
        StructField(Names.GPG_OB_TYPE_EXPENSE, StringType, true) ::
        StructField(Names.GPG_OB_REASON, StringType, true) ::
        StructField(Names.GPG_OB_AMOUNT_LOCAL, DoubleType, true) :: Nil
    )



    var benef_OTR_PIVOT = SparkUtils.spark.createDataFrame(SparkUtils.spark.sparkContext.emptyRDD[Row], schema)

    //Realizamos el pivotado a base de realizar UNION de la select de las diferentes columnas
    schema_Benef_otr.foreach(StructField => {
      if (!StructField.name.equals(Names.HST_GENERAL_ID_SSFF) && !StructField.name.equals("Total")) {
        val part = pDF.select(col(Names.HST_GENERAL_ID_SSFF), col(StructField.name).as(Names.GPG_OB_AMOUNT_LOCAL)).
          filter(col(StructField.name).isNotNull && col(StructField.name) =!= 0).
          withColumn(Names.GPG_OB_TYPE_EXPENSE, lit("Otros beneficios")).
          withColumn(Names.GPG_OB_REASON, lit(StructField.name))

        val part_order = part.select(Names.HST_GENERAL_ID_SSFF, Names.GPG_OB_TYPE_EXPENSE, Names.GPG_OB_REASON, Names.GPG_OB_AMOUNT_LOCAL)

        benef_OTR_PIVOT = benef_OTR_PIVOT.union(part_order)

      }
    })
    benef_OTR_PIVOT
  }

  def fGenerar_ficheros_GPG(): Unit = {

    //Leemos  los ficheros históricos de GPG y GPG_BENEFICIOS DETERMINADOS, transformándolos así en DF
    val GPG_HIST_GEN_DF = ReadExcel.leerCSVADF(Routes.GPG_MAIN_IN_FILE, false)
    //GPG_HIST_GEN_DF.show(false)
    println("hist gen: "+GPG_HIST_GEN_DF.count())
    val GPG_HIST_BENEF_DET = ReadExcel.leerCSVADF(Routes.GPG_BENEF_DET_IN_FILE, false)
//    GPG_HIST_BENEF_DET.show(false)
    println("hist benf det: "+GPG_HIST_BENEF_DET.count())
    //Realizamos un Join de los mismos ya que en el nuevo fichero GPG principal se compone de casi la todalidad
    // de estos dos DF
    val expensesSheet = new Benefits
    //expensesSheet.miDF.show(false)


    val GPG_JOIN =
      GPG_HIST_GEN_DF.join(GPG_HIST_BENEF_DET,
        GPG_HIST_GEN_DF(Names.HST_GENERAL_ID_SSFF) === GPG_HIST_BENEF_DET(Names.HST_GENERAL_ID_SSFF)
        , "leftouter" //"left_outer"
      ).
        select(

          GPG_HIST_GEN_DF.col(Names.HST_GENERAL_LEGAL_ENTITY).as(Names.GENERAL_LEGAL_ENTITY).cast(StringType),
          GPG_HIST_GEN_DF.col(Names.HST_GENERAL_ID_SSFF).as(Names.GENERAL_ID_SSFF),
          GPG_HIST_GEN_DF.col(Names.HST_GPG_ID_REGISTRATION).as(Names.GENERAL_ID_REGISTRATION),
          GPG_HIST_GEN_DF.col(Names.HST_GPG_EMAIL).as(Names.GENERAL_EMAIL),
          GPG_HIST_GEN_DF.col(Names. GPG_GID).as(Names.GPG_GID),
          GPG_HIST_GEN_DF.col(Names.HST_GPG_COD_MARKET_REFERENCE).as(Names.GPG_COD_MARKET_REFERENCE),
          GPG_HIST_GEN_DF.col(Names.HST_GPG_LOCAL_PAYMENT_CURRENCY).as(Names.GPG_LOCAL_PAYMENT_CURRENCY),
          GPG_HIST_GEN_DF.col(Names.HST_GPG_ANNUAL_BASE_SALARY_LOCAL).as(Names.GPG_ANNUAL_BASE_SALARY_LOCAL),
          GPG_HIST_GEN_DF.col(Names.HST_GPG_PCT_THEORETICAL_BONUS_LOCAL).as(Names.GPG_PCT_THEORETICAL_BONUS_LOCAL),
          GPG_HIST_GEN_DF.col(Names.HST_GPG_BONUS_TARGET_LOCAL).as(Names.GPG_BONUS_TARGET_LOCAL),
          GPG_HIST_GEN_DF.col(Names.HST_GPG_REAL_PAID_BONUS_LOCAL).as(Names.GPG_REAL_PAID_BONUS_LOCAL),
          GPG_HIST_GEN_DF.col(Names.HST_GPG_PCT_COMMISSION_TARGET_LOCAL).as(Names.GPG_PCT_COMMISSION_TARGET_LOCAL),
          GPG_HIST_GEN_DF.col(Names.HST_GPG_REAL_PAID_COMMISSIONS_LOCAL).as(Names.GPG_REAL_PAID_COMMISSIONS_LOCAL),
          //GPG_HIST_GEN_DF .col("número de Horas Extras"),
          //GPG_HIST_GEN_DF .col("Otros conceptos (que no sean beneficios, bono, comisiones o salario base)"),
          //GPG_HIST_GEN_DF .col("Tipo de cambio"),
          GPG_HIST_BENEF_DET.col(Names.HST_GPG_SOCIAL_SECURITY_LOCAL).as(Names.GPG_SOCIAL_SECURITY_LOCAL),
          GPG_HIST_BENEF_DET.col(Names.HST_GPG_MEAL_TICKETS_LOCAL).as(Names.GPG_MEAL_TICKETS_LOCAL),
          GPG_HIST_BENEF_DET.col(Names.HST_GPG_HEALTH_INSURANCE_LOCAL).as(Names.GPG_HEALTH_INSURANCE_LOCAL),
          GPG_HIST_BENEF_DET.col(Names.HST_GPG_LIFE_INSURANCE_LOCAL).as(Names.GPG_LIFE_INSURANCE_LOCAL),
          GPG_HIST_BENEF_DET.col(Names.HST_GPG_ACCIDENT_INSURANCE_LOCAL).as(Names.GPG_ACCIDENT_INSURANCE_LOCAL),
          GPG_HIST_BENEF_DET.col(Names.HST_GPG_CAR_ALLOWANCE_LOCAL).as(Names.GPG_CAR_ALLOWANCE_LOCAL),
          GPG_HIST_BENEF_DET.col(Names.HST_GPG_EXPAT_BENEFITS_LOCAL).as(Names. GPG_EXPAT_BENEFITS_LOCAL),
          GPG_HIST_BENEF_DET.col(Names.HST_GPG_ATAM_LOCAL).as(Names.GPG_ATAM_LOCAL),
          GPG_HIST_BENEF_DET.col(Names.HST_GPG_ALBENTURE_LOCAL).as(Names.GPG_ALBENTURE_LOCAL),
          GPG_HIST_BENEF_DET.col(Names.HST_GPG_TRANSPORT_PLUS_LOCAL).as(Names.GPG_TRANSPORT_PLUS_LOCAL),
          GPG_HIST_BENEF_DET.col(Names.HST_GPG_PCF_STOCK_LOCAL).as(Names.GPG_PCF_STOCK_LOCAL),
          GPG_HIST_BENEF_DET.col(Names.HST_GPG_AVAILABILITY_PLUS_LOCAL).as(Names.GPG_AVAILABILITY_PLUS_LOCAL),
          GPG_HIST_BENEF_DET.col(Names.HST_GPG_MOVISTAR_SHARED_PAYMENT_LOCAL).as(Names.GPG_MOVISTAR_SHARED_PAYMENT_LOCAL),
          GPG_HIST_BENEF_DET.col(Names.HST_GPG_BENEFIT_PER_CHILD_LOCAL).as(Names.GPG_BENEFIT_PER_CHILD_LOCAL),
          GPG_HIST_BENEF_DET.col(Names.HST_GPG_STAFF_RELATED_COSTS_LOCAL).as(Names.GPG_STAFF_RELATED_COSTS_LOCAL),
          //GPG_HIST_BENEF_DET.col(Names.HST_GPG_OTHER_BENEFITS),
          GPG_HIST_BENEF_DET.col(Names.HST_GPG_PCT_PENSION_PLAN_LOCAL).as(Names.GPG_PCT_PENSION_PLAN_LOCAL)
        ).withColumn(Names.GENERAL_LEGAL_ENTITY, trim(col(Names.GENERAL_LEGAL_ENTITY)))
    //GPG_HIST_GEN_DF.unpersist()
    //GPG_HIST_BENEF_DET.unpersist()
    println("Se hace el join de los dos primeros")
    //La clase Legal_Entities se utiliza como tabla auxiliar proviniente del PickList para sacar el código de la entidad legal
    // ya que en el fichero principal sólo tenemos la descripción de dicha entidad
    val legalEnt = new Legal_entities
    //Se realiza otro Join para sacar el código de Entidad legal en cuestión.

    val GPG_SELECT = GPG_JOIN.
      join(legalEnt.miDF,
        legalEnt.miDF(Names.HST_GENERAL_LEGAL_ENTITY) === GPG_JOIN.col(Names.GENERAL_LEGAL_ENTITY),
        "leftouter"
      ).select(
      legalEnt.miDF(Names.HST_GENERAL_COD_LEGAL_ENTITY).as(Names.GENERAL_COD_LEGAL_ENTITY).cast(StringType),
      GPG_JOIN(Names.GENERAL_LEGAL_ENTITY),
      GPG_JOIN(Names.GENERAL_ID_SSFF),
      GPG_JOIN(Names.GENERAL_ID_REGISTRATION),
      GPG_JOIN(Names.GENERAL_EMAIL),
      GPG_JOIN(Names.GPG_GID),
      GPG_JOIN(Names.GPG_COD_MARKET_REFERENCE),
      GPG_JOIN(Names.GPG_LOCAL_PAYMENT_CURRENCY),
      GPG_JOIN(Names.GPG_ANNUAL_BASE_SALARY_LOCAL),
      GPG_JOIN(Names.GPG_PCT_THEORETICAL_BONUS_LOCAL),
      GPG_JOIN(Names.GPG_BONUS_TARGET_LOCAL),
      GPG_JOIN(Names.GPG_REAL_PAID_BONUS_LOCAL),
      GPG_JOIN(Names.GPG_PCT_COMMISSION_TARGET_LOCAL),
      GPG_JOIN(Names.GPG_REAL_PAID_COMMISSIONS_LOCAL),
      GPG_JOIN(Names.GPG_SOCIAL_SECURITY_LOCAL),
      GPG_JOIN(Names.GPG_MEAL_TICKETS_LOCAL),
      GPG_JOIN(Names.GPG_HEALTH_INSURANCE_LOCAL),
      GPG_JOIN(Names.GPG_LIFE_INSURANCE_LOCAL),
      GPG_JOIN(Names.GPG_ACCIDENT_INSURANCE_LOCAL),
      GPG_JOIN(Names.GPG_CAR_ALLOWANCE_LOCAL),
      GPG_JOIN(Names. GPG_EXPAT_BENEFITS_LOCAL),
      GPG_JOIN(Names.GPG_ATAM_LOCAL),
      GPG_JOIN(Names.GPG_ALBENTURE_LOCAL),
      GPG_JOIN(Names.GPG_TRANSPORT_PLUS_LOCAL),
      GPG_JOIN(Names.GPG_PCF_STOCK_LOCAL),
      GPG_JOIN(Names.GPG_AVAILABILITY_PLUS_LOCAL),
      GPG_JOIN(Names.GPG_MOVISTAR_SHARED_PAYMENT_LOCAL),
      GPG_JOIN(Names.GPG_BENEFIT_PER_CHILD_LOCAL),
      GPG_JOIN(Names.GPG_STAFF_RELATED_COSTS_LOCAL),
      GPG_JOIN(Names.GPG_PCT_PENSION_PLAN_LOCAL)
    ).  //además se añaden 4 campos nuevos utilizando withColumn
      withColumn(Names.GENERAL_YEAR, lit(2019)).
      withColumn(Names.GENERAL_MONTH, lit(12)).
      withColumn(Names.GPG_PSP_TFSP_LOCAL, format_number(lit(0), 1)). //--> Campo nuevo con valor 0.0
      withColumn(Names.GPG_RSP_OTHERS_ILPs_LOCAL, format_number(lit(0), 1)) //--> Campo nuevo con valor 0.0
    GPG_JOIN.unpersist()
    println("Se obtiene la legal entity del fichero")
   // GPG_SELECT.show(false)
    val GPG_SELECT_2 = GPG_SELECT.select(
      col(Names.GENERAL_MONTH),
      col(Names.GENERAL_YEAR),
      col(Names.GENERAL_COD_LEGAL_ENTITY),
      // col(GENERAL_ID_GLOBAL),
      col(Names.GENERAL_LEGAL_ENTITY),
      col(Names.GENERAL_ID_SSFF),
      col(Names.GENERAL_ID_REGISTRATION),
      col(Names.GENERAL_EMAIL),
      col(Names. GPG_GID),
      col(Names.GPG_COD_MARKET_REFERENCE),
      col(Names.GPG_LOCAL_PAYMENT_CURRENCY),
      col(Names.GPG_ANNUAL_BASE_SALARY_LOCAL),
      col(Names.GPG_PCT_THEORETICAL_BONUS_LOCAL),
      col(Names.GPG_BONUS_TARGET_LOCAL),
      col(Names.GPG_REAL_PAID_BONUS_LOCAL),
      col(Names.GPG_PCT_COMMISSION_TARGET_LOCAL),
      col(Names.GPG_REAL_PAID_COMMISSIONS_LOCAL),
      col(Names.GPG_PSP_TFSP_LOCAL),
      col(Names.GPG_RSP_OTHERS_ILPs_LOCAL),
      col(Names.GPG_SOCIAL_SECURITY_LOCAL),
      col(Names.GPG_MEAL_TICKETS_LOCAL),
      col(Names.GPG_HEALTH_INSURANCE_LOCAL),
      col(Names.GPG_LIFE_INSURANCE_LOCAL),
      col(Names.GPG_ACCIDENT_INSURANCE_LOCAL),
      col(Names.GPG_CAR_ALLOWANCE_LOCAL),
      col(Names. GPG_EXPAT_BENEFITS_LOCAL),
      col(Names.GPG_ATAM_LOCAL),
      col(Names.GPG_ALBENTURE_LOCAL),
      col(Names.GPG_TRANSPORT_PLUS_LOCAL),
      col(Names.GPG_PCF_STOCK_LOCAL),
      col(Names.GPG_AVAILABILITY_PLUS_LOCAL),
      col(Names.GPG_MOVISTAR_SHARED_PAYMENT_LOCAL),
      col(Names.GPG_BENEFIT_PER_CHILD_LOCAL),
      col(Names.GPG_STAFF_RELATED_COSTS_LOCAL),
      col(Names.GPG_PCT_PENSION_PLAN_LOCAL)
    ).withColumn(Names.GENERAL_ID_GLOBAL,
      when(GPG_SELECT(Names.GENERAL_ID_SSFF).isNull
        .or(GPG_SELECT(Names.GENERAL_ID_SSFF) === "N/A")
        .or(GPG_SELECT(Names.GENERAL_ID_SSFF) === "0")
        .or(GPG_SELECT(Names.GENERAL_ID_SSFF) === "-")
        .or(GPG_SELECT(Names.GENERAL_ID_SSFF) === "#N/D")
        .or(GPG_SELECT(Names.GENERAL_ID_SSFF) === "pendente")
        .or(GPG_SELECT(Names.GENERAL_ID_SSFF) === "no aplica"),
        concat(GPG_SELECT(Names.GENERAL_COD_LEGAL_ENTITY), lit("_"),
          GPG_SELECT(Names.GENERAL_ID_REGISTRATION))).
        otherwise(GPG_SELECT(Names.GENERAL_ID_SSFF)))
    GPG_SELECT.unpersist()
    println("Se calcula el campo id global ")
    // se ordenan los campos de salida
    val GPG_ORDERED = GPG_SELECT_2.select(
      col(Names.GENERAL_MONTH),
      col(Names.GENERAL_YEAR),
      col(Names.GENERAL_COD_LEGAL_ENTITY),
      col(Names.GENERAL_LEGAL_ENTITY),
      col(Names.GENERAL_ID_GLOBAL),
      col(Names.GENERAL_ID_SSFF),
      col(Names.GENERAL_ID_REGISTRATION),
      col(Names.GENERAL_EMAIL),
      col(Names.GPG_GID),
      col(Names.GPG_COD_MARKET_REFERENCE),
      col(Names.GPG_LOCAL_PAYMENT_CURRENCY),
      col(Names.GPG_ANNUAL_BASE_SALARY_LOCAL),//
      col(Names.GPG_PCT_THEORETICAL_BONUS_LOCAL),//
      col(Names.GPG_BONUS_TARGET_LOCAL),//
      col(Names.GPG_REAL_PAID_BONUS_LOCAL),//
      col(Names.GPG_PCT_COMMISSION_TARGET_LOCAL),//
      col(Names.GPG_REAL_PAID_COMMISSIONS_LOCAL),//
      col(Names.GPG_PSP_TFSP_LOCAL),//
      col(Names.GPG_RSP_OTHERS_ILPs_LOCAL),//
      col(Names.GPG_SOCIAL_SECURITY_LOCAL),//
      col(Names.GPG_MEAL_TICKETS_LOCAL),//
      col(Names.GPG_HEALTH_INSURANCE_LOCAL),//
      col(Names.GPG_LIFE_INSURANCE_LOCAL),//
      col(Names.GPG_ACCIDENT_INSURANCE_LOCAL),//
      col(Names.GPG_CAR_ALLOWANCE_LOCAL),//
      col(Names.GPG_EXPAT_BENEFITS_LOCAL),//
      col(Names.GPG_ATAM_LOCAL),//
      col(Names.GPG_ALBENTURE_LOCAL),//
      col(Names.GPG_TRANSPORT_PLUS_LOCAL),//
      col(Names.GPG_PCF_STOCK_LOCAL),//
      col(Names.GPG_AVAILABILITY_PLUS_LOCAL),//
      col(Names.GPG_MOVISTAR_SHARED_PAYMENT_LOCAL),//
      col(Names.GPG_BENEFIT_PER_CHILD_LOCAL),//
      col(Names.GPG_STAFF_RELATED_COSTS_LOCAL),//
      col(Names.GPG_PCT_PENSION_PLAN_LOCAL)//
    )
    GPG_SELECT_2.unpersist()
    println("Se ordenan los campos de salida")


    val GPG_ORDERED_FINAL=FormatDecimalValues.formatDecimalValues(List(Names.GPG_ANNUAL_BASE_SALARY_LOCAL,
      Names.GPG_PCT_THEORETICAL_BONUS_LOCAL,Names.GPG_BONUS_TARGET_LOCAL,Names.GPG_REAL_PAID_BONUS_LOCAL,
      Names.GPG_PCT_COMMISSION_TARGET_LOCAL,Names.GPG_REAL_PAID_COMMISSIONS_LOCAL,Names.GPG_PSP_TFSP_LOCAL,
      Names.GPG_RSP_OTHERS_ILPs_LOCAL,Names.GPG_SOCIAL_SECURITY_LOCAL,Names.GPG_MEAL_TICKETS_LOCAL,
      Names.GPG_HEALTH_INSURANCE_LOCAL,Names.GPG_LIFE_INSURANCE_LOCAL,Names.GPG_ACCIDENT_INSURANCE_LOCAL,
      Names.GPG_CAR_ALLOWANCE_LOCAL,Names.GPG_EXPAT_BENEFITS_LOCAL,Names.GPG_ATAM_LOCAL,Names.GPG_ALBENTURE_LOCAL,
      Names.GPG_TRANSPORT_PLUS_LOCAL,Names.GPG_PCF_STOCK_LOCAL,Names.GPG_AVAILABILITY_PLUS_LOCAL,
      Names.GPG_MOVISTAR_SHARED_PAYMENT_LOCAL,Names.GPG_BENEFIT_PER_CHILD_LOCAL,Names.GPG_STAFF_RELATED_COSTS_LOCAL,
      Names.GPG_PCT_PENSION_PLAN_LOCAL),GPG_ORDERED)

   // println("El df final a guardar GPG es este: ")
    //GPG_ORDERED_FINAL.show(false)
    //Escribimos el DF en un nuevo fichero CSV

    /**
     * Ya tengo el df final tope mega guay, ahora nos toca filtrar los usuarios que aparezcan repetidos
     * 1º Filtro esos usuarios y guardo el csv sin ellos
     */

    val dfGPG = TratamientoDuplicados.compruebaGeneraNuevosDuplicadosDF(GPG_ORDERED_FINAL)
    //    //GPG_ORDERED.unpersist()
    println("Tamaño df a escribir: "+dfGPG.count())
    //SaveCSV.guardarDFEnCSV(dfGPG, Routes.GPG_MAIN_OUT_DIR, true, Routes.GPG_FILENAME)

    /** *******************************************
     *
     * Hasta aquí GPG. Ahora vamos con GPG_OTROS
     *
     * ******************************************* * */

    /*
       El nuevo fichero GPG_OTHERS se crea a partir del fichero de beneficios_determinados
       y del fichero de otros_beneficios.
       Lo que haremos será adaptar la estructura de dichos ficheros históricos a la del nuevo
       fichero GPG_OTHERS, y luego realizar un UNION entre ambos.
    */

    /**
     * ********* Según el cliente TYPE_EXPENSE es siempre 1
     **/
    //Del fichero Beneficios determinados, sólo nos interesan en este caso
    //los campos de ID_SSF y OTHER_BENEFITS

//    val GPG_HIST_BENEF_DET_2ND = GPG_HIST_BENEF_DET.
//      select(col(Names.HST_GENERAL_ID_SSFF),
//        col(Names.HST_GPG_OTHER_BENEFITS).as(Names.GPG_OB_AMOUNT_LOCAL)).
//      filter(col(Names.HST_GPG_OTHER_BENEFITS).isNotNull && col(Names.HST_GPG_OTHER_BENEFITS).notEqual("0")).
//      withColumn(Names.GPG_OB_TYPE_EXPENSE, lit("Otros beneficios")).
//      withColumn(Names.GPG_OB_REASON, lit(Names.HST_GPG_OTHER_BENEFITS)).dropDuplicates()
//  println("primera parte fichero otros")
//    //GPG_HIST_BENEF_DET_2ND.show(false)
//    //Ordenamos la estructura que vamos a querer y creamos un DF variable al que se le puedan
//    //añadir registros.
//    val GPG_PIVOT = GPG_HIST_BENEF_DET_2ND.select(
//      col(Names.HST_GENERAL_ID_SSFF),
//      col(Names.GPG_OB_TYPE_EXPENSE),
//      col(Names.GPG_OB_REASON),
//      col(Names.GPG_OB_AMOUNT_LOCAL)).dropDuplicates()
//
//    println("Ya se ha creado el DF variable")
//    //GPG_PIVOT.show(false)
//    /**
//     * Pasamos a la hoja excel de otros beneficios.
//     * Aquí   TYPE_EXPENSE =1 también
//     * */
//    println("Se lee la hoja de otros beneficios")
//    // Pasamos el fichero otros_beneficios a  DF
//    val GPG_HIST_BENEF_OTR = ReadExcel.leerCSVADF(Routes.GPG_OTHER_BENEF_IN_FILE, false).dropDuplicates()
//    //GPG_HIST_BENEF_OTR.show(false)
//
//  //Realizamos la unión de los 2 DF con la estructura correcta
//    //En el caso de otros_beneficios, dicha estructura se consigue con el método
//    // fPivotar_Benef_Otr
//
//    println("Se hace la union de otros beneficios")
//    val GPG_PIVOT_1 = GPG_PIVOT.union(fPivotar_Benef_Otr(GPG_HIST_BENEF_OTR)).dropDuplicates()
//    //val dfPruebaTodosuser= GPG_PIVOT_1.select(Names.HST_GENERAL_ID_SSFF).as("id").dropDuplicates()
//    //val dfPruebaTodosuser1 = dfGPG.select(Names.HST_GENERAL_ID_SSFF).as("id").dropDuplicates()
//    //println("Se restan los dos df con todos los usuarios total gpg - pivot 1: "+ dfGPG.except(GPG_PIVOT_1).count())
//    //println("Se restan los dos df con todos los usuarios pivot 1 - total gpg: "+ GPG_PIVOT_1.except(dfGPG).count())
//    //GPG_PIVOT_1.where(col(Names.HST_GENERAL_ID_SSFF).isNull).show()
//  // Se realiza un  join con GPG_MAIN, de manera que  los campos clave coincidan
//  // De la misma forma, se seleccionan los campos en el orden de salida correcto.
////    println("Se realiza un join con el principal con id global para ver tener todos los datos")
//    val GPG_OTROS_OUT = GPG_PIVOT_1.
//      join(dfGPG, GPG_PIVOT_1(Names.HST_GENERAL_ID_SSFF) === dfGPG(Names.GENERAL_ID_SSFF), "leftouter").
//      select(
//        dfGPG.col(Names.GENERAL_MONTH),
//        dfGPG.col(Names.GENERAL_YEAR),
//        dfGPG.col(Names.GENERAL_COD_LEGAL_ENTITY),
//        dfGPG.col(Names.GENERAL_ID_GLOBAL),
//        GPG_PIVOT_1.col(Names.HST_GENERAL_ID_SSFF),
//        dfGPG.col(Names.GENERAL_LEGAL_ENTITY),
//        GPG_PIVOT_1.col(Names.GPG_OB_TYPE_EXPENSE),
//        GPG_PIVOT_1.col(Names.GPG_OB_REASON),
//        GPG_PIVOT_1.col(Names.GPG_OB_AMOUNT_LOCAL)
//      )
//    GPG_OTROS_OUT.select(Names.GPG_OB_TYPE_EXPENSE).distinct().show(false)
////    //GPG_OTROS_OUT.show(false)
////    val GPG_OTROS_OUT_FINAL =GPG_OTROS_OUT
////          .withColumn(Names.GENERAL_ID_GLOBAL,
////            when(GPG_OTROS_OUT(Names.GPG_OB_TYPE_EXPENSE) === "1",
////              lit("Otros beneficios")).
////              otherwise(GPG_OTROS_OUT(Names.GPG_OB_TYPE_EXPENSE))).dropDuplicates().dropDuplicates()//.orderBy(GPG_ORDERED_FINAL.col(Names.GENERAL_ID_GLOBAL))
////
////    println("count antes formateo: "+GPG_OTROS_OUT.count())
//    val GPG_OTROS_OUT_FINAL_1 = FormatDecimalValues.formatDecimalValues(Names.GPG_OB_AMOUNT_LOCAL,GPG_OTROS_OUT).dropDuplicates()
////    //GPG_OTROS_OUT_FINAL.show(false)
////    //Join para cambiar type expense por el texto
////    //println("Se cambia el type expense por el texto haciendo un join")
//    SaveCSV.guardarDFEnCSV(GPG_OTROS_OUT_FINAL_1, Routes.GPG_OTHERS_OUT_DIR, true, Routes.GPG_OTHERS_FILENAME)



//    //Se realiza otro Join para sacar el código de Entidad legal en cuestión.
//    println("tamaño join: "+GPG_OTROS_OUT_FINAL.count())
//    //println("join, campo español?")
//    //GPG_OTROS_OUT_FINAL.show(5,false)
//    val GPG_OTROS_OUT_FINAL_PL = GPG_OTROS_OUT_FINAL.
//      join(expensesSheet.miDF,
//        expensesSheet.miDF(Names.COD_BENEFITS) === GPG_OTROS_OUT_FINAL.col(Names.GPG_OB_TYPE_EXPENSE),
//        "leftouter"
//      ).select(
//      GPG_OTROS_OUT_FINAL.col(Names.GENERAL_MONTH),
//      GPG_OTROS_OUT_FINAL.col(Names.GENERAL_YEAR),
//      GPG_OTROS_OUT_FINAL.col(Names.GENERAL_COD_LEGAL_ENTITY),
//      GPG_OTROS_OUT_FINAL.col(Names.GENERAL_ID_GLOBAL),
//      GPG_OTROS_OUT_FINAL.col(Names.GENERAL_LEGAL_ENTITY),
//      expensesSheet.miDF(Names.COLUMN_BENEFIT_VALUE),
//      GPG_OTROS_OUT_FINAL.col(Names.GPG_OB_REASON),
//      GPG_OTROS_OUT_FINAL.col(Names.GPG_OB_AMOUNT_LOCAL)
//    ).withColumnRenamed(Names.COLUMN_BENEFIT_VALUE,Names.GPG_OB_TYPE_EXPENSE)
//      .withColumn(Names.GENERAL_ID_GLOBAL,
//        when(GPG_OTROS_OUT_FINAL(Names.GPG_OB_TYPE_EXPENSE) === "1",
//          lit("Otros beneficios")).
//          otherwise(GPG_OTROS_OUT_FINAL(Names.GPG_OB_TYPE_EXPENSE))).dropDuplicates()

    // Finalmente, se escribe el fichero GPG_OTROS
    //GPG_OTROS_OUT_FINAL.show(false)
   // println("El df final a guardar gpg otros es este: ")
    //GPG_OTROS_OUT_FINAL_PL.show(false)


  }

}
