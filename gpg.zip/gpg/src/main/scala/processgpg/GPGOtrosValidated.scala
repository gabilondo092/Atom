package processgpg

import checkers.TratamientoDuplicados
import org.apache.spark.sql.functions.{lit, when}
import utilities.{FormatDecimalValues, Names, ReadExcel, Routes, SaveCSV}

object GPGOtrosValidated {

  def validacionesGPGOtros(): Unit ={
    val GPGFinalWithoutDup = ReadExcel.leerCSVADF(Routes.GPG_OTHERS_FILENAME,Routes.GPG_OTHERS_OUT_DIR, false)
    val GPG_OTROS_OUT_FINAL =GPGFinalWithoutDup
      .withColumn(Names.GPG_OB_TYPE_EXPENSE,
        when(GPGFinalWithoutDup(Names.GPG_OB_TYPE_EXPENSE) === "1",
          lit("Otros beneficios")).
          otherwise(GPGFinalWithoutDup(Names.GPG_OB_TYPE_EXPENSE)))
   /*
    val GPG_OTROS_OUT_FINAL_3 =GPGFinalWithoutDup
      .withColumn(Names.GPG_OB_TYPE_EXPENSE,
        when(GPGFinalWithoutDup(Names.GPG_OB_TYPE_EXPENSE) === "1",
          lit("Otros beneficios")).
          otherwise(GPGFinalWithoutDup(Names.GPG_OB_TYPE_EXPENSE)))
    */

    val GPG_OTROS_OUT_FINAL_1 = FormatDecimalValues.formatDecimalValues(Names.GPG_OB_AMOUNT_LOCAL,GPG_OTROS_OUT_FINAL)

      .dropDuplicates()
    val dfFinal = TratamientoDuplicados.compruebaGeneraNuevosDuplicadosDFOther(GPG_OTROS_OUT_FINAL_1)

    SaveCSV.guardarDFEnCSV(dfFinal.drop(Names.GENERAL_ID_SSFF), Routes.GPG_OTHERS_OUT_DIR_2, true, Routes.GPG_OTHERS_FILENAME+"_final")
  }

}
