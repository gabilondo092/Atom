package mapeo

import utilities.{ReadExcel, Utils}

class Mes {
  val mName="19_mes"
  //val mColumns: ArrayBuffer[String]
  val miDF=ReadExcel.leerExcelADF(mName,pPerisit = true)
  //val miSheet=SparkSessionLocal.leerExcelAXSFSheet(SparkSessionLocal.pathToPicklistFiles,mName)
  val miCampos= Map(0->"COD",1->"Desc")
  /**
   *
   * ESto no mola.. intenta hacerlo con Map
   *
   */

  /*def getValorPorClaveXSSF(ponKeyValue:String):String={
    SparkSessionLocal.getValorDeXSFSheet(miSheet,1,0,ponKeyValue)
  }*/
  def getValorPorClaveDF(ponKeyValue:String):String={
    Utils.getValorDeDf(miDF,"Desc","COD",ponKeyValue)
  }

}
