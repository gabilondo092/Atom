package mapeo

import utilities.{ReadExcel, Utils}

class Benefits {

  val mName="18_tipo_gasto.csv"
  //val mColumns: ArrayBuffer[String]
  val miDF=ReadExcel.leerCSVADF(mName,pPerisit = true).withColumnRenamed("Español","value")
  //val miSheet=SparkSessionLocal.leerExcelAXSFSheet(SparkSessionLocal.pathToPicklistFiles,mName)
  val miCampos= Map(0->"COD",1->"Español")
  /**
    *
    * ESto no mola.. intenta hacerlo con Map
    *
    */

  /*def getValorPorClaveXSSF(ponKeyValue:String):String={
    SparkSessionLocal.getValorDeXSFSheet(miSheet,1,0,ponKeyValue)
  }*/
  def getValorPorClaveDF(ponKeyValue:String):String={
    Utils.getValorDeDf(miDF,"Entidad Legal","COD",ponKeyValue)
  }
}
