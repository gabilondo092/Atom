package mapeo

import org.apache.spark.sql.functions.{col, trim}
import utilities.{ReadExcel, Utils}

class Legal_entities {
  val mName="13_entidad_legal.csv"
  //val mColumns: ArrayBuffer[String]
  val miDF = ReadExcel.leerCSVExcel(mName,pPerisit = true).withColumn("Entidad Legal"
    ,trim(col("Entidad Legal")))

  //val miSheet=SparkSessionLocal.leerExcelAXSFSheet(SparkSessionLocal.pathToPicklistFiles,mName)
  val miCampos= Map(0->"COD",1->"Entidad Legal")
  /**
   *
   * ESto no mola.. intenta hacerlo con Map
   *
   */

  /*def getValorPorClaveXSSF(ponKeyValue:String):String={
    SparkSessionLocal.getValorDeXSFSheet(miSheet,1,0,ponKeyValue)
  }*/
  def getValorPorClaveDF(ponKeyValue:String):String={
    Utils.getValorDeDf(miDF,"Entidad Legal","COD",ponKeyValue)
  }

}
