package pln

import checkers.{CheckNull, TratamientoDuplicados}
import org.apache.spark.sql.functions.when
import utilities.{FilteredSave, Names, ReadExcel, Routes, SaveCSV}

object HeadcountValidated {

  def validar(filen: Int) : Unit ={
    var file: String = null
    var dir: String = null
    var dirOrigen: String = null
    if(filen == 1 ) {
      file =Routes.PLN_HEADCOUNTS_FILENAME_1
      dir = Routes.PLN_HEADCOUNTS_OUT_DIR_2
      dirOrigen = Routes.PLN_HEADCOUNTS_OUT_DIR_F1
    }else if(filen == 2){
      file =Routes.PLN_HEADCOUNTS_FILENAME_2
      dir = Routes.PLN_HEADCOUNTS_OUT_DIR_3
      dirOrigen = Routes.PLN_HEADCOUNTS_OUT_DIR_F2
    }else if(filen == 3){
      file =Routes.PLN_HEADCOUNTS_FILENAME_3
      dir = Routes.PLN_HEADCOUNTS_OUT_DIR_4
      dirOrigen = Routes.PLN_HEADCOUNTS_OUT_DIR_F3
    }
    /**
     * Se tiene que ejecutar en 3 veces, la primera solo con los _OK (ojo tiene que estar la forma de guardado SaveCSV.guardarDFEnCSV(dfFinal, dir, true, file))
     * Después de la carpeta raíz se pasa el fichero a la carpeta padre ( de la carpeta FINAL a F1, F2 o F3 según corresponda) y se lanza la segunda ejecucución
     * con el guardado con los duplicados (ojo tiene que tiene que seguir estando la forma de guardado SaveCSV.guardarDFEnCSV(dfFinal, dir, true, file))
     * y la última con el guardado filtrado simplemente para que se genere por meses.
     */
    val GPGFinalWithoutDup = ReadExcel.leerCSVADF(file,dirOrigen, false)
//    val FUNCTIONAL_AREA_OK = CheckNull.checkNull(GPGFinalWithoutDup,false,Names.PLN_FUNCTIONAL_AREA)
//    val CONTRACT_TYPE_OK = CheckNull.checkNull(FUNCTIONAL_AREA_OK,false,Names.PLN_CONTRACT_TYPE)
//    val EMPLOYE_CLASS_OK = CheckNull.checkNull(CONTRACT_TYPE_OK,false,Names.PLN_EMPLOYEE_CLASS)
//    val GENDER_OK= CheckNull.checkNull(EMPLOYE_CLASS_OK,true,Names.GENERAL_GENDER)
//    val NATIONALITY_OK = CheckNull.checkNull(GENDER_OK,false,Names.PLN_NATIONALITY)
//    val GLOBAL_CATEGORY_OK = CheckNull.checkNull(NATIONALITY_OK,false,Names.PLN_GLOBAL_CATEGORY)
//    val EMPLOYE_STATUS_OK = CheckNull.checkNull(GLOBAL_CATEGORY_OK,true,Names.PLN_EMPLOYEE_STATUS)
//    val INTERNATIONAL_SHORT_TERM_ASIGNEE_OK = CheckNull.checkNull(EMPLOYE_STATUS_OK,true,Names.PLN_INTERNATIONAL_SHORT_TERM_ASSIGNEE)
//    val REDUCED_WORK_DAY_OK = CheckNull.checkNull(INTERNATIONAL_SHORT_TERM_ASIGNEE_OK,false,Names.PLN_REDUCED_WORK_DAY)
//    val DISABILITY_OK = CheckNull.checkNull(REDUCED_WORK_DAY_OK,false,Names.PLN_DISABILITY)
//    val SUBACTIVITY_OK = CheckNull.checkNull(DISABILITY_OK,false,Names.PLN_SUBACTIVITY)
//    val COD_LEGAL_ENTITY_OK = CheckNull.checkNull(SUBACTIVITY_OK, true,Names.GENERAL_COD_LEGAL_ENTITY)
//    val LOCAL_CATEGORY_OK = CheckNull.checkNull(COD_LEGAL_ENTITY_OK,false,Names.PLN_LOCAL_CATEGORY)
//    val BUSSINESS_UNIT_OK = CheckNull.checkNull(LOCAL_CATEGORY_OK,true,Names.PLN_BUSINESS_UNIT)
//    val CITY_OK = CheckNull.checkNull(BUSSINESS_UNIT_OK,false,Names.PLN_CITY)
//    val SENIORITY_OK = CITY_OK.withColumn(Names.PLN_SENIORITY_DATE,
//      when(CITY_OK(Names.PLN_SENIORITY_DATE).isNull,
//        "01/01/1900").
//        otherwise(CITY_OK(Names.PLN_SENIORITY_DATE))).dropDuplicates()
//    val COUNTRY_OK = CheckNull.checkNull(SENIORITY_OK,false,Names.PLN_COUNTRY)
//    val DIVISION_OK =  CheckNull.checkNull(COUNTRY_OK,false,Names.PLN_DIVISION)
//    val DEPARTMENT_OK = CheckNull.checkNull(DIVISION_OK,false,Names.PLN_DEPARTMENT)
//    val UNION_UNDER_AGREGMENT_OK = CheckNull.checkNull(DEPARTMENT_OK,false,Names.PLN_UNDER_UNION_AGREEMENT)
//    val STANDARD_POSITION_HOURS_OK = CheckNull.changeNullToDecimal(UNION_UNDER_AGREGMENT_OK,Names.PLN_STANDARD_POSITION_HOURS)
//    val STANDARD_WEEKLY_HOURS_OK = CheckNull.changeNullToDecimal(STANDARD_POSITION_HOURS_OK,Names.PLN_STANDARD_WEEKLY_HOURS)
//    val ACTUALY_WEEKLY_HOURS_OK = CheckNull.changeNullToDecimal(STANDARD_WEEKLY_HOURS_OK,Names.PLN_ACTUAL_WEEKLY_HOURS)
//    val HIRE_DATE_OK = ACTUALY_WEEKLY_HOURS_OK.withColumn(Names.PLN_HIRE_DATE,
//      when(ACTUALY_WEEKLY_HOURS_OK(Names.PLN_HIRE_DATE).isNull,
//        "01/01/1900").
//        otherwise(ACTUALY_WEEKLY_HOURS_OK(Names.PLN_HIRE_DATE)))
//    val BIRTHDAY_DATE_OK = HIRE_DATE_OK.withColumn(Names.PLN_BIRTH_DATE,
//      when(HIRE_DATE_OK(Names.PLN_BIRTH_DATE).isNull,
//        "01/01/1900").
//        otherwise(HIRE_DATE_OK(Names.PLN_BIRTH_DATE)))
    val dfFinal = TratamientoDuplicados.compruebaGeneraNuevosDuplicadosDF(GPGFinalWithoutDup)
//    SaveCSV.guardarDFEnCSV(dfFinal, dir, true, file)
    FilteredSave.fGuardarFiltrados(dfFinal, Names.GENERAL_MONTH, dir, file+"_final")

  }
}
