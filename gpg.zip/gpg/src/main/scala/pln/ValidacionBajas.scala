package pln

import checkers.{CheckNull, TratamientoDuplicados}
import utilities.{Names, ReadExcel, Routes, SaveCSV}

object ValidacionBajas {

  def ValidacionAltas(mes: String) = {
    val df = ReadExcel.leerCSVADF(Routes.PLN_ALTAS_FILENAME + "_" + mes + ".csv", System.getProperty("user.dir") + "\\PLN\\HEADCOUNTS\\" + mes, false)
    df.show(false)
    println("El fichero headcount tiene: " + df.count())

    /**
     * Comprobaciones y duplicados
     */
    /**
     * Ya tenemos el DF "listo" para guardar, ahora hay que hacer las comprobaciones
     * Empezamos con las comprobaciones relativas a picklist:
     * -GENDER
     * -EMPLOYE_CLASS
     * -GLOBAL_CATEGORY
     * -COD_LEGAL_ENTITY
     * -BUSSINESS_UNIT
     * -SUBACTIVITY
     */

    val GENDER_OK= CheckNull.checkNull(df,true,Names.GENERAL_GENDER)
    val EMPLOYE_CLASS_OK = CheckNull.checkNull(GENDER_OK,false,Names.PLN_EMPLOYEE_CLASS)
    val GLOBAL_CATEGORY_OK = CheckNull.checkNull(EMPLOYE_CLASS_OK,false,Names.PLN_GLOBAL_CATEGORY)
    val COD_LEGAL_ENTITY_OK = CheckNull.checkNull(GLOBAL_CATEGORY_OK, false,Names.GENERAL_COD_LEGAL_ENTITY)
    val BUSSINESS_UNIT_OK = CheckNull.checkNull(COD_LEGAL_ENTITY_OK,false,Names.PLN_BUSINESS_UNIT)
    val SUBACTIVITY_OK = CheckNull.checkNull(BUSSINESS_UNIT_OK,false,Names.PLN_SUBACTIVITY)

    val dfFinal = TratamientoDuplicados.compruebaGeneraNuevosDuplicadosDF(SUBACTIVITY_OK)
    SaveCSV.guardarDFEnCSV(dfFinal, System.getProperty("user.dir")+"\\PLN\\BAJAS\\"+mes+"\\dq",
      true, Routes.PLN_BAJAS_FILENAME+mes+".csv")
  }
}
