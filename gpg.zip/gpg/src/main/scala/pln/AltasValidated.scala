package pln

import checkers.{CheckNull, TratamientoDuplicados}
import utilities.{Names, ReadExcel, Routes, SaveCSV}

object AltasValidated {
  def validarAltas: Unit ={
    val GPGFinalWithoutDup = ReadExcel.leerCSVADF(Routes.PLN_ALTAS_FILENAME,Routes.PLN_ALTAS_OUT_DIR, false)
    //println("tamaño inicio: "+GPGFinalWithoutDup.count())
    val GENDER_OK= CheckNull.checkNull(GPGFinalWithoutDup,true,Names.GENERAL_GENDER)
    val EMPLOYE_CLASS_OK = CheckNull.checkNull(GENDER_OK,false,Names.PLN_EMPLOYEE_CLASS)
    val GLOBAL_CATEGORY_OK = CheckNull.checkNull(EMPLOYE_CLASS_OK,false,Names.PLN_GLOBAL_CATEGORY)
    //GLOBAL_CATEGORY_OK.show(false)
    val LOCAL_CATEGORY_OK = CheckNull.checkNull(GLOBAL_CATEGORY_OK,false,Names.PLN_LOCAL_CATEGORY)
    val STARTERS_LOCAL_TYPE_OK = CheckNull.checkNull(LOCAL_CATEGORY_OK,false,Names.PLN_STARTERS_LOCAL_TYPE)
    val STARTERS_GLOBAL_TYPE_OK = CheckNull.checkNull(STARTERS_LOCAL_TYPE_OK,false,Names.PLN_STARTERS_GLOBAL_TYPE)
    val COD_LEGAL_ENTITY_OK = CheckNull.checkNull(STARTERS_GLOBAL_TYPE_OK, false,Names.GENERAL_COD_LEGAL_ENTITY)
    val BUSSINESS_UNIT_OK = CheckNull.checkNull(COD_LEGAL_ENTITY_OK,true,Names.PLN_BUSINESS_UNIT)
    val SUBACTIVITY_OK = CheckNull.checkNull(BUSSINESS_UNIT_OK,false,Names.PLN_SUBACTIVITY)
    //println("tamaño antes dup: "+GPGFinalWithoutDup.count())
    val dfFinal = TratamientoDuplicados.compruebaGeneraNuevosDuplicadosDF(SUBACTIVITY_OK)
    //FilteredSave.guardarDFEnCSV(dfFinal,Names.GENERAL_MONTH, Routes.PLN_ALTAS_OUT_DIR, Routes.PLN_ALTAS_FILENAME)
    //SaveCSV.guardarDFEnCSV(dflegalentity, Routes.PLN_ALTAS_OUT_DIR, true, Routes.PLN_ALTAS_FILENAME)
    //println("tamaño guardado: "+dfFinal.count())
    SaveCSV.guardarDFEnCSV(dfFinal, Routes.PLN_ALTAS_OUT_DIR_2, true, Routes.PLN_ALTAS_FILENAME+"_final")
  }
}
