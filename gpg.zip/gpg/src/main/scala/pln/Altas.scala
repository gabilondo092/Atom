package pln

import checkers.{CheckNull, TratamientoDuplicados}
import mapeo.Legal_entities
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types._
import utilities.{CheckIdGlobal, FilteredSave, Names, ReadExcel, Routes, SaveCSV}

object Altas {

  def generarAltas() = {
    //Extraemos el valor Año del fichero HEADCOUNTS porque no aparece en la nueva estructura de los ficheros
    // históricos de altas ni bajas.



    /**
      * VAMOS CON ALTAS
      */

    //Se repiten por orden las mismas operaciones que en HEADCOUNTS
    //De la misma manera, aquí también falta un campo que no se aporta en los ficheros fuente
    // Aparece comentado.

    val HST_ALTAS_TOT_DF = ReadExcel.leerCSVADF( Routes.PLN_ALTAS_FILENAME+".csv", false)
    println("recien leido:" +HST_ALTAS_TOT_DF.count())
    //HST_ALTAS_TOT_DF.show(200, false)
    //println("tamaño fichero: "+ HST_ALTAS_TOT_DF.count())

    val PLN_HIST_ALTAS2_TOT = HST_ALTAS_TOT_DF
      .select(
        //   col(Names.GENERAL_YEAR),
        col(Names.HST_PLN_IDMONTH).cast(IntegerType).as(Names.GENERAL_MONTH),
        col(Names.HST_PLN_COD_LEGAL_ENTITY).cast(StringType).as(Names.GENERAL_COD_LEGAL_ENTITY),
        col(Names.HST_PLN_REPORTED_LEGAL_ENTITY).as(Names.GENERAL_LEGAL_ENTITY),
        col(Names.HST_GENERAL_ID_SSFF).cast(StringType).as(Names.GENERAL_ID_SSFF),
        col(Names.HST_PLN_ID_REGISTRATION).cast(StringType).as(Names.GENERAL_ID_REGISTRATION),
        col(Names.HST_PLN_ALT_BAJ_GENDER).as(Names.GENERAL_GENDER),
        col(Names.HST_PLN_ALT_BAJ_BIRTH_DATE).as(Names.PLN_BIRTH_DATE),
        col( Names.HST_PLN_ALT_STARTERS_DATE).as(Names.PLN_STARTERS_DATE),
        col(Names.HST_PLN_ALT_STARTERS_LOCAL_TYPE).as(Names.PLN_STARTERS_LOCAL_TYPE),
        col( Names.HST_PLN_ALT_STARTERS_GLOBAL_TYPE).as(Names.PLN_STARTERS_GLOBAL_TYPE),
        col( Names.HST_PLN_BUSINESS_UNIT).as(Names.PLN_BUSINESS_UNIT),
        col( Names.HST_PLN_ALT_BAJ_EMPLOYEE_CLASS).as(Names.PLN_EMPLOYEE_CLASS),
        col( Names.HST_PLN_NOMBRE_PUESTO).as(Names.PLN_LOCAL_CATEGORY),
        col( Names.HST_PLN_GLOBAL_CATEGORY).as(Names.PLN_GLOBAL_CATEGORY),
        col( Names.HST_PLN_SUBACTIVITY).as(Names.PLN_SUBACTIVITY)

      )
      //      .filter(
      //        to_date(PLN_HST_DATES(Names.PLN_HIRE_DATE)) <= (lit(loDateMaxStr))
      //          &&
      //          to_date(PLN_HST_DATES(Names.PLN_HIRE_DATE)) >= (lit(loDateMinStr))

      //      )
      .withColumn(Names.PLN_COMMENTS,lit(""))
      .withColumn(Names.GENERAL_YEAR,lit("2019"))
      //.withColumn(Names.PLN_LOCAL_CATEGORY,lit(""))

    //PLN_HIST_ALTAS2_TOT.show(200,false)
    val PLN_HIST_ALTAS_TOT_ORD=  CheckIdGlobal.compruebaIDGlobal(PLN_HIST_ALTAS2_TOT,Names.GENERAL_ID_REGISTRATION)
//    val PLN_HIST_ALTAS_TOT_ORD=  PLN_HIST_ALTAS2_TOT.
//      select(
//        Names.GENERAL_YEAR,
//        Names.GENERAL_MONTH,
//        Names.GENERAL_COD_LEGAL_ENTITY,
//        //Names.GENERAL_LEGAL_ENTITY,
//        Names.GENERAL_ID_SSFF,
//        Names.GENERAL_ID_REGISTRATION,
//        Names.GENERAL_GENDER,
//        Names.PLN_BIRTH_DATE,
//        Names.PLN_STARTERS_DATE,
//        Names.PLN_STARTERS_LOCAL_TYPE,
//        Names.PLN_STARTERS_GLOBAL_TYPE,
//        Names.PLN_BUSINESS_UNIT,
//        Names.PLN_EMPLOYEE_CLASS,
//        Names.PLN_LOCAL_CATEGORY,
//        Names.PLN_GLOBAL_CATEGORY,
//        Names.PLN_SUBACTIVITY,
//        Names.PLN_COMMENTS
//      )
//      .withColumn(Names.GENERAL_ID_GLOBAL,
//        when(
//          PLN_HIST_ALTAS2_TOT(Names.GENERAL_ID_SSFF).isNull
//          .or(PLN_HIST_ALTAS2_TOT(Names.GENERAL_ID_SSFF) === "NA")
//          .or(PLN_HIST_ALTAS2_TOT(Names.GENERAL_ID_SSFF) === "N/A")
//          .or(PLN_HIST_ALTAS2_TOT(Names.GENERAL_ID_SSFF) === "#N/A")
//          .or(PLN_HIST_ALTAS2_TOT(Names.GENERAL_ID_SSFF) === "No posee ID de SSFF")
//          .or(PLN_HIST_ALTAS2_TOT(Names.GENERAL_ID_SSFF) === "0")
//          .or(PLN_HIST_ALTAS2_TOT(Names.GENERAL_ID_SSFF) === "-")
//          .or(PLN_HIST_ALTAS2_TOT(Names.GENERAL_ID_SSFF) === "#N/D")
//          .or(PLN_HIST_ALTAS2_TOT(Names.GENERAL_ID_SSFF) === "pendente"),
//          when(
//            PLN_HIST_ALTAS2_TOT(Names.GENERAL_ID_REGISTRATION).isNull,
//            concat(lit("NULL_"), PLN_HIST_ALTAS2_TOT(Names.GENERAL_COD_LEGAL_ENTITY).cast(StringType)))
//              .otherwise(
//                concat(
//                  PLN_HIST_ALTAS2_TOT(Names.GENERAL_ID_REGISTRATION),
//                  lit("_"),
//                  PLN_HIST_ALTAS2_TOT(Names.GENERAL_COD_LEGAL_ENTITY).cast(StringType)
//                )
//              )
//          )
//          .otherwise(PLN_HIST_ALTAS2_TOT(Names.GENERAL_ID_SSFF)))
    //      .withColumn(Names.GENERAL_ID_GLOBAL,
    //      Main.generar_IDGLOBAL(
    //        PLN_HIST_ALTAS2_TOT(Names.GENERAL_ID_SSFF),
    //        PLN_HIST_ALTAS2_TOT(Names.GENERAL_COD_LEGAL_ENTITY).cast(StringType),
    //        PLN_HIST_ALTAS2_TOT(Names.GENERAL_ID_REGISTRATION)))

    // PLN_HIST_ALTAS_TOT_ORD.persist()
    val PLN_HIST_ALTAS_TOT_ORD_2=  PLN_HIST_ALTAS_TOT_ORD.
      select(
        Names.GENERAL_MONTH,
        Names.GENERAL_YEAR,
        Names.GENERAL_COD_LEGAL_ENTITY,
        Names.GENERAL_ID_GLOBAL,
        //Names.GENERAL_LEGAL_ENTITY,
        Names.GENERAL_ID_SSFF,
        Names.GENERAL_ID_REGISTRATION,
        Names.GENERAL_GENDER,
        Names.PLN_BIRTH_DATE,
        Names.PLN_STARTERS_DATE,
        Names.PLN_STARTERS_LOCAL_TYPE,
        Names.PLN_STARTERS_GLOBAL_TYPE,
        Names.PLN_BUSINESS_UNIT,
        Names.PLN_EMPLOYEE_CLASS,
        Names.PLN_LOCAL_CATEGORY,
        Names.PLN_GLOBAL_CATEGORY,
        Names.PLN_SUBACTIVITY,
        Names.PLN_COMMENTS
      )
    //PLN_HIST_ALTAS_TOT_ORD_2.show(2,false)
    val legalEnt = new Legal_entities
    //legalEnt.miDF.show(2,false)
    val dflegalentity = PLN_HIST_ALTAS_TOT_ORD_2.
      join(legalEnt.miDF,
        legalEnt.miDF(Names.HST_GENERAL_COD_LEGAL_ENTITY) === PLN_HIST_ALTAS_TOT_ORD_2.col(Names.GENERAL_COD_LEGAL_ENTITY),
        "leftouter"
      ).select(
      //legalEnt.miDF(Names.HST_GENERAL_COD_LEGAL_ENTITY).as(Names.GENERAL_COD_LEGAL_ENTITY).cast(StringType),
      PLN_HIST_ALTAS_TOT_ORD_2(Names.GENERAL_MONTH),
      PLN_HIST_ALTAS_TOT_ORD_2(Names.GENERAL_YEAR),
      PLN_HIST_ALTAS_TOT_ORD_2(Names.GENERAL_COD_LEGAL_ENTITY),
      PLN_HIST_ALTAS_TOT_ORD_2(Names.GENERAL_ID_GLOBAL),
      legalEnt.miDF(Names.HST_GENERAL_LEGAL_ENTITY).as(Names.GENERAL_LEGAL_ENTITY),
      PLN_HIST_ALTAS_TOT_ORD_2(Names.GENERAL_ID_SSFF),
      PLN_HIST_ALTAS_TOT_ORD_2(Names.GENERAL_ID_REGISTRATION),
      PLN_HIST_ALTAS_TOT_ORD_2(Names.GENERAL_GENDER),
      PLN_HIST_ALTAS_TOT_ORD_2(Names.PLN_BIRTH_DATE),
      PLN_HIST_ALTAS_TOT_ORD_2(Names.PLN_STARTERS_DATE),
      PLN_HIST_ALTAS_TOT_ORD_2(Names.PLN_STARTERS_LOCAL_TYPE),
      PLN_HIST_ALTAS_TOT_ORD_2(Names.PLN_STARTERS_GLOBAL_TYPE),
      PLN_HIST_ALTAS_TOT_ORD_2(Names.PLN_BUSINESS_UNIT),
      PLN_HIST_ALTAS_TOT_ORD_2(Names.PLN_EMPLOYEE_CLASS),
      PLN_HIST_ALTAS_TOT_ORD_2(Names.PLN_LOCAL_CATEGORY),
      PLN_HIST_ALTAS_TOT_ORD_2(Names.PLN_GLOBAL_CATEGORY),
      PLN_HIST_ALTAS_TOT_ORD_2(Names.PLN_SUBACTIVITY),
      PLN_HIST_ALTAS_TOT_ORD_2(Names.PLN_COMMENTS)
    )

    //dflegalentity.show(100,false)
    //println("tamaño sin duplicados: "+dflegalentity.dropDuplicates().count())
    /**
     * Comprobaciones y duplicados
     */
    /**
     * Ya tenemos el DF "listo" para guardar, ahora hay que hacer las comprobaciones
     * Empezamos con las comprobaciones relativas a picklist:
     * -GENDER
     * -EMPLOYE_CLASS
     * -GLOBAL_CATEGORY
     * -COD_LEGAL_ENTITY
     * -BUSSINESS_UNIT
     * -SUBACTIVITY
     */

    val GENDER_OK= CheckNull.checkNull(dflegalentity,true,Names.GENERAL_GENDER)
//    val EMPLOYE_CLASS_OK = CheckNull.checkNull(GENDER_OK,false,Names.PLN_EMPLOYEE_CLASS)
//    val GLOBAL_CATEGORY_OK = CheckNull.checkNull(EMPLOYE_CLASS_OK,false,Names.PLN_GLOBAL_CATEGORY)
//    //GLOBAL_CATEGORY_OK.show(false)
//    val LOCAL_CATEGORY_OK = CheckNull.checkNull(GLOBAL_CATEGORY_OK,false,Names.PLN_LOCAL_CATEGORY)
//    val STARTERS_LOCAL_TYPE_OK = CheckNull.checkNull(LOCAL_CATEGORY_OK,false,Names.PLN_STARTERS_LOCAL_TYPE)
//    val STARTERS_GLOBAL_TYPE_OK = CheckNull.checkNull(STARTERS_LOCAL_TYPE_OK,false,Names.PLN_STARTERS_GLOBAL_TYPE)
//    val COD_LEGAL_ENTITY_OK = CheckNull.checkNull(STARTERS_GLOBAL_TYPE_OK, false,Names.GENERAL_COD_LEGAL_ENTITY)
//    val BUSSINESS_UNIT_OK = CheckNull.checkNull(COD_LEGAL_ENTITY_OK,false,Names.PLN_BUSINESS_UNIT)
//    val SUBACTIVITY_OK = CheckNull.checkNull(BUSSINESS_UNIT_OK,false,Names.PLN_SUBACTIVITY)
//    val dfFinal = TratamientoDuplicados.compruebaGeneraNuevosDuplicadosDF(SUBACTIVITY_OK)
    //FilteredSave.guardarDFEnCSV(dfFinal,Names.GENERAL_MONTH, Routes.PLN_ALTAS_OUT_DIR, Routes.PLN_ALTAS_FILENAME)
    println("primer guardado:" +dflegalentity.count())
    SaveCSV.guardarDFEnCSV(dflegalentity, Routes.PLN_ALTAS_OUT_DIR, true, Routes.PLN_ALTAS_FILENAME)
  }

}
