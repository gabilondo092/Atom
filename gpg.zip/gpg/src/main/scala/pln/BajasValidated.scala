package pln

import checkers.{CheckNull, TratamientoDuplicados}
import utilities.{Names, ReadExcel, Routes, SaveCSV}

object BajasValidated {

  def validar: Unit ={
    val GPGFinalWithoutDup = ReadExcel.leerCSVADF(Routes.PLN_BAJAS_FILENAME,Routes.PLN_BAJAS_OUT_DIR, false)
    val GENDER_OK= CheckNull.checkNull(GPGFinalWithoutDup,true,Names.GENERAL_GENDER)
    val EMPLOYE_CLASS_OK = CheckNull.checkNull(GENDER_OK,false,Names.PLN_EMPLOYEE_CLASS)
    val GLOBAL_CATEGORY_OK = CheckNull.checkNull(EMPLOYE_CLASS_OK,false,Names.PLN_GLOBAL_CATEGORY)
    val COD_LEGAL_ENTITY_OK = CheckNull.checkNull(GLOBAL_CATEGORY_OK, false,Names.GENERAL_COD_LEGAL_ENTITY)
    val LOCAL_CATEGORY_OK = CheckNull.checkNull(COD_LEGAL_ENTITY_OK,false,Names.PLN_LOCAL_CATEGORY)
    //LOCAL_CATEGORY_OK.select(Names.PLN_LOCAL_CATEGORY).show(50000, false)
    val LEAVERS_LOCAL_TYPE_OK = CheckNull.checkNull(LOCAL_CATEGORY_OK,false,Names.PLN_LEAVERS_LOCAL_TYPE)
    val LEAVERS_GLOBAL_TYPE_OK = CheckNull.checkNull(LEAVERS_LOCAL_TYPE_OK,false,Names.PLN_LEAVERS_GLOBAL_TYPE)
    val BUSSINESS_UNIT_OK = CheckNull.checkNull(LEAVERS_GLOBAL_TYPE_OK,true,Names.PLN_BUSINESS_UNIT)
    val SUBACTIVITY_OK = CheckNull.checkNull(BUSSINESS_UNIT_OK,false,Names.PLN_SUBACTIVITY)
    val dfFinal = TratamientoDuplicados.compruebaGeneraNuevosDuplicadosDF(SUBACTIVITY_OK)
    SaveCSV.guardarDFEnCSV(dfFinal, Routes.PLN_BAJAS_OUT_DIR_2, true, Routes.PLN_BAJAS_FILENAME+"_final")
  }

}
