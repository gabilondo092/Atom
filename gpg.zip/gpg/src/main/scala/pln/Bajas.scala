package pln

import checkers.{CheckNull, TratamientoDuplicados}
import mapeo.Legal_entities
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.{IntegerType, StringType}
import utilities.{CheckIdGlobal, FilteredSave, Names, ReadExcel, Routes, SaveCSV}

object Bajas {

  def generarBajas() ={
    //Se repiten por orden las mismas operaciones que en HEADCOUNTS y ALTAS
    //De la misma manera, aquí también falta un campo que no se aporta en los ficheros fuente
    // Aparece comentado.



    val HST_BAJAS_TOT_DF = ReadExcel.leerCSVADF( Routes.PLN_BAJAS_FILENAME+".csv", false)
    println("recien leido:" +HST_BAJAS_TOT_DF.dropDuplicates().count())
    val PLN_HIST_BAJAS2_TOT = HST_BAJAS_TOT_DF
      .select(
        //   col(Names.GENERAL_YEAR),
        col(Names.HST_PLN_IDMONTH).cast(IntegerType).as(Names.GENERAL_MONTH),
        col(Names.HST_PLN_COD_LEGAL_ENTITY).cast(StringType).as(Names.GENERAL_COD_LEGAL_ENTITY),
        col(Names.HST_PLN_REPORTED_LEGAL_ENTITY).as(Names.GENERAL_LEGAL_ENTITY),
        col(Names.HST_GENERAL_ID_SSFF).cast(StringType).as(Names.GENERAL_ID_SSFF),
        col(Names.HST_PLN_ID_REGISTRATION).cast(StringType).as(Names.GENERAL_ID_REGISTRATION),
        col(Names.HST_PLN_ALT_BAJ_GENDER).as(Names.GENERAL_GENDER),
        col(Names.HST_PLN_ALT_BAJ_BIRTH_DATE).as(Names.PLN_BIRTH_DATE),
        col( Names.HST_PLN_BAJ_LEAVERS_DATE).as(Names.PLN_LEAVERS_DATE),
        col(Names.HST_PLN_BAJ_LEAVERS_LOCAL_TYPE).as(Names.PLN_LEAVERS_LOCAL_TYPE),
        col( Names.HST_PLN_BAJ_LEAVERS_GLOBAL_TYPE).as(Names.PLN_LEAVERS_GLOBAL_TYPE),
        col( Names.HST_PLN_BUSINESS_UNIT).as(Names.PLN_BUSINESS_UNIT),
        col( Names.HST_PLN_ALT_BAJ_EMPLOYEE_CLASS).as(Names.PLN_EMPLOYEE_CLASS),
        //col( Names.PLN_LOCAL_CATEGORY).as(Names.PLN_LOCAL_CATEGORY),
        col( Names.HST_PLN_GLOBAL_CATEGORY).as(Names.PLN_GLOBAL_CATEGORY),
        col( Names.HST_PLN_SUBACTIVITY).as(Names.PLN_SUBACTIVITY)


      )
      //      .filter(
      //        to_date(PLN_HST_DATES(Names.PLN_LEAVERS_DATE)) <= (lit(loDateMaxStr))
      //          &&
      //          to_date(PLN_HST_DATES(Names.PLN_LEAVERS_DATE)) >= (lit(loDateMinStr))

      //      )
      .withColumn(Names.PLN_COMMENTS,lit(""))
      .withColumn(Names.GENERAL_YEAR,lit("2019"))
      .withColumn(Names.PLN_LOCAL_CATEGORY,lit("Desconocido"))

    val PLN_HIST_BAJAS_TOT_ORD=  CheckIdGlobal.compruebaIDGlobal(PLN_HIST_BAJAS2_TOT,Names.GENERAL_ID_REGISTRATION)
    println("recien vistos los id ssff: " +PLN_HIST_BAJAS_TOT_ORD.count())
//    val PLN_HIST_BAJAS_TOT_ORD= PLN_HIST_BAJAS2_TOT
//      .withColumn(Names.GENERAL_ID_GLOBAL,
//        when(
//          PLN_HIST_BAJAS2_TOT(Names.GENERAL_ID_SSFF).isNull
//            .or(PLN_HIST_BAJAS2_TOT(Names.GENERAL_ID_SSFF) === "NA")
//            .or(PLN_HIST_BAJAS2_TOT(Names.GENERAL_ID_SSFF) === "N/A")
//            .or(PLN_HIST_BAJAS2_TOT(Names.GENERAL_ID_SSFF) === "#N/A")
//            .or(PLN_HIST_BAJAS2_TOT(Names.GENERAL_ID_SSFF) === "No posee ID de SSFF")
//            .or(PLN_HIST_BAJAS2_TOT(Names.GENERAL_ID_SSFF) === "0")
//            .or(PLN_HIST_BAJAS2_TOT(Names.GENERAL_ID_SSFF) === "-")
//            .or(PLN_HIST_BAJAS2_TOT(Names.GENERAL_ID_SSFF) === "#N/D")
//            .or(PLN_HIST_BAJAS2_TOT(Names.GENERAL_ID_SSFF) === "pendente"),
//          when(
//            PLN_HIST_BAJAS2_TOT(Names.GENERAL_ID_REGISTRATION).isNull,
//            concat(lit("ID_NA_0000000")))
//            .otherwise(
//              concat(
//                PLN_HIST_BAJAS2_TOT(Names.GENERAL_ID_REGISTRATION),
//                lit("_"),
//                PLN_HIST_BAJAS2_TOT(Names.GENERAL_COD_LEGAL_ENTITY).cast(StringType)
//              )
//            )
//        )
//          .otherwise(PLN_HIST_BAJAS2_TOT(Names.GENERAL_ID_SSFF)))
    //      .withColumn(Names.GENERAL_ID_GLOBAL,
    //        when(PLN_HIST_BAJAS2_TOT(Names.GENERAL_ID_SSFF).isNull,
    //          concat( PLN_HIST_BAJAS2_TOT(Names.GENERAL_ID_REGISTRATION), lit("_"),
    //            PLN_HIST_BAJAS2_TOT(Names.GENERAL_COD_LEGAL_ENTITY).cast(StringType))).
    //          otherwise(PLN_HIST_BAJAS2_TOT(Names.GENERAL_ID_SSFF)))


    //      .withColumn(Names.GENERAL_ID_GLOBAL,
    //      Main.generar_IDGLOBAL(
    //        PLN_HIST_BAJAS2_TOT(Names.GENERAL_ID_SSFF),
    //          PLN_HIST_BAJAS2_TOT(Names.GENERAL_COD_LEGAL_ENTITY).cast(StringType),
    //        PLN_HIST_BAJAS2_TOT(Names.GENERAL_ID_REGISTRATION)))

    //PLN_HIST_BAJAS_TOT_ORD.persist()
    val PLN_HIST_BAJAS_TOT_ORD_2=  PLN_HIST_BAJAS_TOT_ORD.
      select(
        Names.GENERAL_MONTH,
        Names.GENERAL_YEAR,
        Names.GENERAL_COD_LEGAL_ENTITY,
        Names.GENERAL_ID_GLOBAL,
        //Names.GENERAL_LEGAL_ENTITY,
        Names.GENERAL_ID_SSFF,
        Names.GENERAL_ID_REGISTRATION,
        Names.GENERAL_GENDER,
        Names.PLN_BIRTH_DATE,
        Names.PLN_LEAVERS_DATE,
        Names.PLN_LEAVERS_LOCAL_TYPE,
        Names.PLN_LEAVERS_GLOBAL_TYPE,
        Names.PLN_BUSINESS_UNIT,
        Names.PLN_EMPLOYEE_CLASS,
        Names.PLN_LOCAL_CATEGORY,
        Names.PLN_GLOBAL_CATEGORY,
        Names.PLN_SUBACTIVITY,
        Names.PLN_COMMENTS
      )
    println("recien ordenado:" +PLN_HIST_BAJAS_TOT_ORD_2.count())
    val legalEnt = new Legal_entities
    //legalEnt.miDF.show(2,false)
    val dflegalentity = PLN_HIST_BAJAS_TOT_ORD_2.
      join(legalEnt.miDF,
        legalEnt.miDF(Names.HST_GENERAL_COD_LEGAL_ENTITY) === PLN_HIST_BAJAS_TOT_ORD_2.col(Names.GENERAL_COD_LEGAL_ENTITY),
        "leftouter"
      ).select(
      //legalEnt.miDF(Names.HST_GENERAL_COD_LEGAL_ENTITY).as(Names.GENERAL_COD_LEGAL_ENTITY).cast(StringType),
      PLN_HIST_BAJAS_TOT_ORD_2(Names.GENERAL_MONTH),
      PLN_HIST_BAJAS_TOT_ORD_2(Names.GENERAL_YEAR),
      PLN_HIST_BAJAS_TOT_ORD_2(Names.GENERAL_COD_LEGAL_ENTITY),
      PLN_HIST_BAJAS_TOT_ORD_2(Names.GENERAL_ID_GLOBAL),
      legalEnt.miDF(Names.HST_GENERAL_LEGAL_ENTITY).as(Names.GENERAL_LEGAL_ENTITY),
      PLN_HIST_BAJAS_TOT_ORD_2(Names.GENERAL_ID_SSFF),
      PLN_HIST_BAJAS_TOT_ORD_2(Names.GENERAL_ID_REGISTRATION),
      PLN_HIST_BAJAS_TOT_ORD_2(Names.GENERAL_GENDER),
      PLN_HIST_BAJAS_TOT_ORD_2(Names.PLN_BIRTH_DATE),
      PLN_HIST_BAJAS_TOT_ORD_2(Names.PLN_LEAVERS_DATE),
      PLN_HIST_BAJAS_TOT_ORD_2(Names.PLN_LEAVERS_LOCAL_TYPE),
      PLN_HIST_BAJAS_TOT_ORD_2(Names.PLN_LEAVERS_GLOBAL_TYPE),
      PLN_HIST_BAJAS_TOT_ORD_2(Names.PLN_BUSINESS_UNIT),
      PLN_HIST_BAJAS_TOT_ORD_2(Names.PLN_EMPLOYEE_CLASS),
      PLN_HIST_BAJAS_TOT_ORD_2(Names.PLN_LOCAL_CATEGORY),
      PLN_HIST_BAJAS_TOT_ORD_2(Names.PLN_GLOBAL_CATEGORY),
      PLN_HIST_BAJAS_TOT_ORD_2(Names.PLN_SUBACTIVITY),
      PLN_HIST_BAJAS_TOT_ORD_2(Names.PLN_COMMENTS)
    )

    println("primer guardado:" +dflegalentity.count())
    SaveCSV.guardarDFEnCSV(dflegalentity, Routes.PLN_BAJAS_OUT_DIR,true, Routes.PLN_BAJAS_FILENAME)
//    //PLN_HIST_BAJAS_TOT_ORD.unpersist()
  }


}
