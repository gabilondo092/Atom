package pln

import checkers.{CheckNull, TratamientoDuplicados}
import org.apache.spark.sql.functions.when
import utilities.{Names, ReadExcel, Routes, SaveCSV}

object ValidationPicklistHeadCount {

  def validatePicklist(mes:String,filen: Int) = {
    var file: String = null
    if(filen == 1 ) {
      file =Routes.PLN_HEADCOUNTS_FILENAME_1
    }else if(filen == 2){
      file =Routes.PLN_HEADCOUNTS_FILENAME_2
    }else if(filen == 3){
      file =Routes.PLN_HEADCOUNTS_FILENAME_3
    }
    val dfHeadcount = ReadExcel.leerCSVADF(file+"_"+mes+".csv",System.getProperty("user.dir")+"\\PLN\\HEADCOUNTS\\"+mes,false)
      //dfHeadcount.show(false)
      //println("El fichero headcount tiene: "+dfHeadcount.count())
//    /**
//     * Ya tenemos el DF "listo" para guardar, ahora hay que hacer las comprobaciones
//     * Empezamos con las comprobaciones relativas a picklist:
//     * -FUNCTIONAL_AREA
//     * -CONTRACT_TYPE
//     * -EMPLOYE_CLASS
//     * -GENDER
//     * -NATIONALITY
//     * -COUNTRY
//     * -GLOBAL_CATEGORY
//     * -EMPLOYE_STATUS
//     * -INTERNATIONAL_SHORT_TERM_ASIGNEE
//     * -REDUCED_WORK_DAY
//     * -DISABILITY
//     * -SUBACTIVITY
//     * -COD_LEGAL_ENTITY
//     * -BUSSINESS_UNIT
//     */
//
//    /*
//     -FUNCTIONAL_AREA
//     */
//
//          println("comienzan las validaciones")
//        val FUNCTIONAL_AREA_OK = CheckNull.checkNull(dfHeadcount,false,Names.PLN_FUNCTIONAL_AREA)
//    dfHeadcount.unpersist()
//      println("area funcional ok")
//        /*
//           -CONTRACT_TYPE
//           */
//
//        val CONTRACT_TYPE_OK = CheckNull.checkNull(FUNCTIONAL_AREA_OK,false,Names.PLN_CONTRACT_TYPE)
//        FUNCTIONAL_AREA_OK.unpersist()
//      println("tipo de contrato ok")
//        /*
//           -EMPLOYE_CLASS
//           */
//        val EMPLOYE_CLASS_OK = CheckNull.checkNull(CONTRACT_TYPE_OK,false,Names.PLN_EMPLOYEE_CLASS)
//        CONTRACT_TYPE_OK.unpersist()
//      println("employe class ok")
//        /*
//        GENDER --> Vamos a ver los distintos valores que hay para gender, 3 F/M/null
//        si null -> 0
//         */
//        val GENDER_OK= CheckNull.checkNull(EMPLOYE_CLASS_OK,true,Names.GENERAL_GENDER)
//        EMPLOYE_CLASS_OK.unpersist()
//      println("genero ok")
//        /*
//        -NATIONALITY
//         */
//          val NATIONALITY_OK = CheckNull.checkNull(GENDER_OK,false,Names.PLN_NATIONALITY)
//        GENDER_OK.unpersist()
//      println("nacionalidad ok")
//        /* -GLOBAL_CATEGORY
//         */
//        val GLOBAL_CATEGORY_OK = CheckNull.checkNull(NATIONALITY_OK,false,Names.PLN_GLOBAL_CATEGORY)
//        NATIONALITY_OK.unpersist()
//      println("categoría global ok")
//        /*
//        * -EMPLOYE_STATUS
//         */
//        val EMPLOYE_STATUS_OK = CheckNull.checkNull(GLOBAL_CATEGORY_OK,false,Names.PLN_EMPLOYEE_STATUS)
//        GLOBAL_CATEGORY_OK.unpersist()
//      println("estado empleado ok")
//        /*
//         * -INTERNATIONAL_SHORT_TERM_ASIGNEE
//         */
//
//        val INTERNATIONAL_SHORT_TERM_ASIGNEE_OK = CheckNull.checkNull(EMPLOYE_STATUS_OK,true,Names.PLN_INTERNATIONAL_SHORT_TERM_ASSIGNEE)
//        EMPLOYE_STATUS_OK.unpersist()
//      println("rotante ok")
//    /*
//        * -REDUCED_WORK_DAY
//       */
//
//        val REDUCED_WORK_DAY_OK = CheckNull.checkNull(INTERNATIONAL_SHORT_TERM_ASIGNEE_OK,false,Names.PLN_REDUCED_WORK_DAY)
//        INTERNATIONAL_SHORT_TERM_ASIGNEE_OK.unpersist()
//      println("trabajo reducido ok")
//
//        /* * -DISABILITY
//        */
//        val DISABILITY_OK = CheckNull.checkNull(REDUCED_WORK_DAY_OK,false,Names.PLN_DISABILITY)
//        REDUCED_WORK_DAY_OK.unpersist()
//      println("discapacidad ok")
//        /*
//
//        * -SUBACTIVITY
//         */
//
//        val SUBACTIVITY_OK = CheckNull.checkNull(DISABILITY_OK,false,Names.PLN_SUBACTIVITY)
//        DISABILITY_OK.unpersist()
//      println("subactividad ok")
//        /*
//        COD_LEGAL_ENTITY
//         */
//        val COD_LEGAL_ENTITY_OK = CheckNull.checkNull(SUBACTIVITY_OK, false,Names.GENERAL_COD_LEGAL_ENTITY)
//        SUBACTIVITY_OK.unpersist()
//      println("legal entity ok")
//        /*
//        * -BUSSINESS_UNIT
//        */
//        val BUSSINESS_UNIT_OK = CheckNull.checkNull(COD_LEGAL_ENTITY_OK,false,Names.PLN_BUSINESS_UNIT)
      //println("business unit ok")

//  println("Procesando mes "+mes)
//
//    print("seniority")
//    val SENIORITY_OK = dfHeadcount.withColumn(Names.PLN_SENIORITY_DATE,
//      when(dfHeadcount(Names.PLN_SENIORITY_DATE).isNull,
//        "01/01/1900").
//        otherwise(dfHeadcount(Names.PLN_SENIORITY_DATE))).dropDuplicates()
//
//
//
//
//
   // println("country")
    //val COUNTRY_OK = CheckNull.checkNull(dfHeadcount,false,Names.PLN_COUNTRY)
  //  println("city")
//    val CITY_OK = CheckNull.checkNull(COUNTRY_OK,false,Names.PLN_CITY)
//
//    println("division")
//
//    val DIVISION_OK =  CheckNull.checkNull(CITY_OK,false,Names.PLN_DIVISION)
//    println("department")
//    val DEPARTMENT_OK = CheckNull.checkNull(DIVISION_OK,false,Names.PLN_DEPARTMENT)
//    print("local_category")
//    val LOCAL_CATEGORY_OK = CheckNull.checkNull(DEPARTMENT_OK,false,Names.PLN_LOCAL_CATEGORY)
//    println("union_under_Agrement")
//    val UNION_UNDER_AGREGMENT_OK = CheckNull.checkNull(LOCAL_CATEGORY_OK,false,Names.PLN_UNDER_UNION_AGREEMENT)
//   println("standar_position_hours")
//
//
//        val STANDARD_POSITION_HOURS_OK = CheckNull.changeNullToDecimal(UNION_UNDER_AGREGMENT_OK,Names.PLN_STANDARD_POSITION_HOURS)
//   print("standar_weekly_hours")
//    val STANDARD_WEEKLY_HOURS_OK = CheckNull.changeNullToDecimal(STANDARD_POSITION_HOURS_OK,Names.PLN_STANDARD_WEEKLY_HOURS)
//
//
//    val GLOBAL_CATEGORY_OK = CheckNull.checkNull(STANDARD_WEEKLY_HOURS_OK,false,Names.PLN_GLOBAL_CATEGORY)
//    SaveCSV.guardarDFEnCSV(GLOBAL_CATEGORY_OK.select(Names.PLN_GLOBAL_CATEGORY).distinct(), Routes.PLN_ALTAS_PICKLIST_OUT+"\\"+Names.PLN_GLOBAL_CATEGORY, true, "ALTAS_PICKLIST_"+Names.PLN_GLOBAL_CATEGORY)
//
//
//    println("Se procede a guardar el df")

       //val ACTUALY_WEEKLY_HOURS_OK = CheckNull.changeNullToDecimal(dfHeadcount,Names.PLN_ACTUAL_WEEKLY_HOURS)




       val dfFinal = TratamientoDuplicados.compruebaGeneraNuevosDuplicadosDF(dfHeadcount)
//        ACTUALY_WEEKLY_HOURS_OK.unpersist()
        SaveCSV.guardarDFEnCSV(dfFinal, System.getProperty("user.dir")+"\\PLN\\HEADCOUNTS\\"+mes+"\\dq",
            true, file+"_"+mes)
  }
}
