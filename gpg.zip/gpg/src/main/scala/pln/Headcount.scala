package pln


import checkers.CheckNull
import mapeo.Legal_entities
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.{IntegerType, StringType}
import utilities.{CheckIdGlobal, FilteredSave, Names, ReadExcel, Routes, SaveCSV}
object Headcount {


  var loYear: Integer = 0
  def generarHeadcount(filen: Int)={
    var file: String = null
    var dir: String = null
    if(filen == 1 ) {
      file =Routes.PLN_HEADCOUNTS_FILENAME_1
      dir = Routes.PLN_HEADCOUNTS_OUT_DIR_F1
    }else if(filen == 2){
      file =Routes.PLN_HEADCOUNTS_FILENAME_2
      dir = Routes.PLN_HEADCOUNTS_OUT_DIR_F2
    }else if(filen == 3){
      file =Routes.PLN_HEADCOUNTS_FILENAME_3
      dir = Routes.PLN_HEADCOUNTS_OUT_DIR_F3
    }
    //Convierto el fichero fuente en un DF
    val HST_HEADCOUNTS_TOT_DF = ReadExcel.leerCSVADF(file+".csv",false)
    //println("count fichero leido: "+ HST_HEADCOUNTS_TOT_DF.dropDuplicates().count())
    //HST_HEADCOUNTS_TOT_DF.show(200,false)
    //Se realizano los cambios de formato necesarios y se añaden campos constantes
    val HST_HEADCOUNTS2_TOT_DF = HST_HEADCOUNTS_TOT_DF.select(

      col(Names.HST_PLN_HEADCOUNTS_YEAR).cast(StringType).as(Names.GENERAL_YEAR),
      col(Names.HST_PLN_IDMONTH).cast(IntegerType).as(Names.GENERAL_MONTH),   // ->analizando los históricos se observa que IDMes es el código numérico del mes.. que es lo que se busca
      col(Names.HST_GENERAL_ID_SSFF).cast(StringType).as(Names.GENERAL_ID_SSFF),
      col(Names.HST_PLN_ID_REGISTRATION).cast(StringType).as(Names.GENERAL_ID_REGISTRATION),
      col(Names.HST_PLN_HEADCOUNTS_GENDER).as(Names.GENERAL_GENDER),
      col(Names.HST_PLN_NATIONALITY).as(Names.PLN_NATIONALITY),
      col(Names.HST_PLN_HEADCOUNTS_BIRTH_DATE).as(Names.PLN_BIRTH_DATE),
      //to_date(col(Names.HST_PLN_HEADCOUNTS_BIRTH_DATE),"MM/dd/yyyy").as(Names.PLN_BIRTH_DATE),
      col(Names.HST_PLN_SENIORITY_DATE).as(Names.PLN_SENIORITY_DATE),
      col(Names.HST_PLN_HEADCOUNTS_HIRE_DATE).as(Names.PLN_HIRE_DATE),
      //      col(Names.HST_PLN_HEADCOUNTS_BIRTH_DATE).as(Names.PLN_BIRTH_DATE),
      //      col(Names.HST_PLN_SENIORITY_DATE).as(Names.PLN_SENIORITY_DATE),
      //      col(Names.HST_PLN_HEADCOUNTS_HIRE_DATE).as(Names.PLN_HIRE_DATE),
      col(Names.HST_PLN_COUNTRY).as(Names.PLN_COUNTRY),
      col(Names.HST_PLN_CITY).as(Names.PLN_CITY),
      col(Names.HST_PLN_COD_LEGAL_ENTITY).cast(StringType).as(Names.GENERAL_COD_LEGAL_ENTITY),
      col(Names.HST_PLN_LEGAL_ENTITY).as(Names.GENERAL_LEGAL_ENTITY),
      col(Names.HST_PLN_BUSINESS_UNIT).as(Names.PLN_BUSINESS_UNIT),
      col(Names.HST_PLN_DIVISION).as(Names.PLN_DIVISION),
      col(Names.HST_PLN_DEPARTMENT).as(Names.PLN_DEPARTMENT),
      col(Names.HST_PLN_EMPLOYEE_STATUS).as(Names.PLN_EMPLOYEE_STATUS),
      col(Names.HST_PLN_HEADCOUNTS_EMPLOYEE_CLASS).as(Names.PLN_EMPLOYEE_CLASS),
      col(Names.HST_PLN_GLOBAL_CATEGORY).as(Names.PLN_GLOBAL_CATEGORY),
      col(Names.HST_PLN_COLLECTIVE_AGREEMENT).as(Names.PLN_COLLECTIVE_AGREEMENT),
      col(Names.HST_PLN_UNDER_UNION_AGREEMENT).as(Names.PLN_UNDER_UNION_AGREEMENT),
      col(Names.HST_PLN_FUNCTIONAL_AREA).as(Names.PLN_FUNCTIONAL_AREA),
      col(Names.HST_PLN_SUBACTIVITY).as(Names.PLN_SUBACTIVITY),
      col(Names.HST_PLN_HEADCOUNTS_FTE).as(Names.PLN_FTE),
      col(Names.HST_PLN_HEADCOUNTS_REDUCED_WORK_DAY).as(Names.PLN_REDUCED_WORK_DAY),
      col(Names.HST_PLN_HEADCOUNTS_CONTRACT_TYPE).as(Names.PLN_CONTRACT_TYPE),
      col(Names.HST_PLN_HEADCOUNTS_STANDARD_POSITION_HOURS).as(Names.PLN_STANDARD_POSITION_HOURS),
      col(Names.HST_PLN_HEADCOUNTS_STANDARD_WEEKLY_HOURS).as(Names.PLN_STANDARD_WEEKLY_HOURS),
      col(Names.HST_PLN_HEADCOUNTS_ACTUAL_WEEKLY_HOURS).as(Names.PLN_ACTUAL_WEEKLY_HOURS),
      col(Names.HST_PLN_HEACOUNTS_DISABILITY).as(Names.PLN_DISABILITY),
      col(Names.HST_PLN_HEADCOUNTS_INTERNATIONAL_SHORT_TERM_ASSIGNEE).as(Names.PLN_INTERNATIONAL_SHORT_TERM_ASSIGNEE),
      col(Names.HST_PLN_EMAIL).as(Names.GENERAL_EMAIL)//,
      // col(Names.HST_PLN_LOCAL_CATEGORY).as(Names.PLN_LOCAL_CATEGORY),  // OJO!!.. este campo no está en la nueva estructura del HISTÓRICO de HEADCOUNTS
      //col(Names.HST_PLN_EMPLOYEE_TYPE).as(Names.PLN_EMPLOYEE_TYPE),
      // col(Names.HST_PLN_REGION).as(Names.PLN_REGION),
      // col(Names.HST_PLN_EWORK).as(Names.PLN_EWORK),
    ).withColumn(Names.PLN_COMMENTS, lit(""))
      .withColumn(Names.PLN_LOCAL_CATEGORY,lit("Desconocido"))
    //      .withColumn(Names.GENERAL_ID_GLOBAL,
    //        Main.generar_IDGLOBAL(
    //          HST_HEADCOUNTS_TOT_DF(Names.HST_GENERAL_ID_SSFF),
    //        HST_HEADCOUNTS_TOT_DF(Names.HST_PLN_COD_LEGAL_ENTITY).cast(StringType),
    //        HST_HEADCOUNTS_TOT_DF(Names.HST_PLN_ID_REGISTRATION)))

    /**
     * Ahora necesitamos que los valores de picklist se relacionen correctamente con las picklist
     */


    //Ahora se añade el campo ID_Global, que necesita un cálculo.
    //En GPG se realizaba mediante una UDF, sin embargo aquí se debe realizar con una query
    //ya que las UDF's fallan a la hora de dividir el DF en otros DF más pequeños
    //HST_HEADCOUNTS2_TOT_DF.filter(HST_HEADCOUNTS2_TOT_DF(Names.GENERAL_ID_SSFF).isNull).show(false)
    val HST_HEADCOUNTS_TOT_ORDERED=HST_HEADCOUNTS2_TOT_DF
      .select(
        Names.GENERAL_MONTH,
        Names.GENERAL_YEAR,
        Names.GENERAL_COD_LEGAL_ENTITY,
        Names.GENERAL_LEGAL_ENTITY,
        Names.GENERAL_ID_SSFF,
        Names.GENERAL_ID_REGISTRATION,
        Names.GENERAL_GENDER,
        Names.PLN_NATIONALITY,
        Names.PLN_COUNTRY,
        Names.PLN_CITY,
        Names.PLN_BIRTH_DATE,
        Names.PLN_SENIORITY_DATE,
        Names.PLN_HIRE_DATE,
        Names.PLN_BUSINESS_UNIT,
        Names.PLN_EMPLOYEE_STATUS,
        Names.PLN_DIVISION,
        Names.PLN_DEPARTMENT,
        Names.PLN_EMPLOYEE_CLASS,
        Names.PLN_LOCAL_CATEGORY,
        Names.PLN_GLOBAL_CATEGORY,
        Names.PLN_COLLECTIVE_AGREEMENT,
        Names.PLN_UNDER_UNION_AGREEMENT,
        Names.PLN_FUNCTIONAL_AREA,
        Names.PLN_SUBACTIVITY,
        Names.PLN_FTE,
        Names.PLN_REDUCED_WORK_DAY,
        Names.PLN_CONTRACT_TYPE,
        Names.PLN_STANDARD_POSITION_HOURS,
        Names.PLN_STANDARD_WEEKLY_HOURS,
        Names.PLN_ACTUAL_WEEKLY_HOURS,
        Names.PLN_DISABILITY,
        Names.PLN_INTERNATIONAL_SHORT_TERM_ASSIGNEE,
        Names.GENERAL_EMAIL,
        //   Names.PLN_EWORK,     --> No aparecen estos campo en la nueva estructura de HEADCOUNTS
        //   Names.PLN_EMPLOYEE_TYPE,
        //   Names.PLN_REGION,
        Names.PLN_COMMENTS

      )
      .withColumn(Names.PLN_EWORK, lit("0"))
      .withColumn(Names.PLN_EMPLOYEE_TYPE, lit("Desconocido"))
      .withColumn(Names.PLN_REGION, lit(""))
//      .withColumn(Names.GENERAL_ID_GLOBAL,
//        when(
//          HST_HEADCOUNTS2_TOT_DF(Names.GENERAL_ID_SSFF).isNull
//            .or(HST_HEADCOUNTS2_TOT_DF(Names.GENERAL_ID_SSFF) === "NA")
//            .or(HST_HEADCOUNTS2_TOT_DF(Names.GENERAL_ID_SSFF) === "N/A")
//            .or(HST_HEADCOUNTS2_TOT_DF(Names.GENERAL_ID_SSFF) === "#N/A")
//            .or(HST_HEADCOUNTS2_TOT_DF(Names.GENERAL_ID_SSFF) === "No posee ID de SSFF")
//            .or(HST_HEADCOUNTS2_TOT_DF(Names.GENERAL_ID_SSFF) === "0")
//            .or(HST_HEADCOUNTS2_TOT_DF(Names.GENERAL_ID_SSFF) === "-")
//            .or(HST_HEADCOUNTS2_TOT_DF(Names.GENERAL_ID_SSFF) === "#N/D")
//            .or(HST_HEADCOUNTS2_TOT_DF(Names.GENERAL_ID_SSFF) === "pendente"),
//          when(
//            HST_HEADCOUNTS2_TOT_DF(Names.GENERAL_ID_REGISTRATION).isNull,
//            concat(lit("ID_NA_0000000")))
//            .otherwise(
//              concat(
//                HST_HEADCOUNTS2_TOT_DF(Names.GENERAL_ID_REGISTRATION),
//                lit("_"),
//                HST_HEADCOUNTS2_TOT_DF(Names.GENERAL_COD_LEGAL_ENTITY).cast(StringType)
//              )
//            )
//        )
//          .otherwise(HST_HEADCOUNTS2_TOT_DF(Names.GENERAL_ID_SSFF)))

    val PLN_HIST_BAJAS_TOT_ORD_2=  CheckIdGlobal.compruebaIDGlobal(HST_HEADCOUNTS_TOT_ORDERED,Names.GENERAL_ID_REGISTRATION)
    //HST_HEADCOUNTS2_TOT_DF.filter(HST_HEADCOUNTS2_TOT_DF(Names.GENERAL_ID_SSFF).isNull).show(false)
    //Se ordenan los campos conforme a la salida requerida
    val legalEnt = new Legal_entities
    //legalEnt.miDF.show(2,false)
    //println("df legal entity: "+legalEnt.miDF.count())
    val dflegalentity = PLN_HIST_BAJAS_TOT_ORD_2.
      join(legalEnt.miDF,
        legalEnt.miDF(Names.HST_GENERAL_COD_LEGAL_ENTITY) === PLN_HIST_BAJAS_TOT_ORD_2.col(Names.GENERAL_COD_LEGAL_ENTITY),
        "leftouter"
      ).select(
      //legalEnt.miDF(Names.HST_GENERAL_COD_LEGAL_ENTITY).as(Names.GENERAL_COD_LEGAL_ENTITY).cast(StringType),
      PLN_HIST_BAJAS_TOT_ORD_2(Names.GENERAL_MONTH),
      PLN_HIST_BAJAS_TOT_ORD_2(Names.GENERAL_YEAR),
      PLN_HIST_BAJAS_TOT_ORD_2(Names.GENERAL_COD_LEGAL_ENTITY),
      PLN_HIST_BAJAS_TOT_ORD_2(Names.GENERAL_ID_GLOBAL),
      legalEnt.miDF(Names.HST_GENERAL_LEGAL_ENTITY).as(Names.GENERAL_LEGAL_ENTITY),
      PLN_HIST_BAJAS_TOT_ORD_2(Names.GENERAL_ID_SSFF),
      PLN_HIST_BAJAS_TOT_ORD_2(Names.GENERAL_ID_REGISTRATION),
      PLN_HIST_BAJAS_TOT_ORD_2(Names.GENERAL_GENDER),
      PLN_HIST_BAJAS_TOT_ORD_2(Names.PLN_NATIONALITY),
      PLN_HIST_BAJAS_TOT_ORD_2(Names.PLN_BIRTH_DATE),
      PLN_HIST_BAJAS_TOT_ORD_2(Names.PLN_SENIORITY_DATE),
      PLN_HIST_BAJAS_TOT_ORD_2(Names.PLN_HIRE_DATE),
      PLN_HIST_BAJAS_TOT_ORD_2(Names.PLN_COUNTRY),
      PLN_HIST_BAJAS_TOT_ORD_2(Names.PLN_CITY),
      PLN_HIST_BAJAS_TOT_ORD_2(Names.PLN_BUSINESS_UNIT),
      PLN_HIST_BAJAS_TOT_ORD_2(Names.PLN_EMPLOYEE_STATUS),
      PLN_HIST_BAJAS_TOT_ORD_2(Names.PLN_DIVISION),
      PLN_HIST_BAJAS_TOT_ORD_2(Names.PLN_DEPARTMENT),
      PLN_HIST_BAJAS_TOT_ORD_2(Names.PLN_EMPLOYEE_CLASS),
      PLN_HIST_BAJAS_TOT_ORD_2(Names.PLN_LOCAL_CATEGORY),
      PLN_HIST_BAJAS_TOT_ORD_2(Names.PLN_GLOBAL_CATEGORY),
      PLN_HIST_BAJAS_TOT_ORD_2(Names.PLN_COLLECTIVE_AGREEMENT),
      PLN_HIST_BAJAS_TOT_ORD_2(Names.PLN_UNDER_UNION_AGREEMENT),
      PLN_HIST_BAJAS_TOT_ORD_2(Names.PLN_FUNCTIONAL_AREA),
      PLN_HIST_BAJAS_TOT_ORD_2(Names.PLN_SUBACTIVITY),
      PLN_HIST_BAJAS_TOT_ORD_2(Names.PLN_FTE),
      PLN_HIST_BAJAS_TOT_ORD_2(Names.PLN_REDUCED_WORK_DAY),
      PLN_HIST_BAJAS_TOT_ORD_2(Names.PLN_CONTRACT_TYPE),
      PLN_HIST_BAJAS_TOT_ORD_2(Names.PLN_STANDARD_POSITION_HOURS),
      PLN_HIST_BAJAS_TOT_ORD_2(Names.PLN_STANDARD_WEEKLY_HOURS),
      PLN_HIST_BAJAS_TOT_ORD_2(Names.PLN_ACTUAL_WEEKLY_HOURS),
      PLN_HIST_BAJAS_TOT_ORD_2(Names.PLN_DISABILITY),
      PLN_HIST_BAJAS_TOT_ORD_2(Names.PLN_INTERNATIONAL_SHORT_TERM_ASSIGNEE),
      PLN_HIST_BAJAS_TOT_ORD_2(Names.GENERAL_EMAIL),
      PLN_HIST_BAJAS_TOT_ORD_2(Names.PLN_EWORK),
      PLN_HIST_BAJAS_TOT_ORD_2(Names.PLN_EMPLOYEE_TYPE),
      PLN_HIST_BAJAS_TOT_ORD_2(Names.PLN_REGION),
      PLN_HIST_BAJAS_TOT_ORD_2(Names.PLN_COMMENTS)
    ).dropDuplicates()

    //OJO!! aquí faltan campos porque en la nueva estructura de los históricos de HEADCOUNTS no existen
//    val HST_HEADCOUNTS_TOT_ORDERED2= HST_HEADCOUNTS_TOT_ORDERED.
//      select(
//        Names.GENERAL_MONTH,
//        Names.GENERAL_YEAR,
//        Names.GENERAL_COD_LEGAL_ENTITY,
//        Names.GENERAL_ID_GLOBAL,
//        Names.GENERAL_LEGAL_ENTITY,
//        Names.GENERAL_ID_SSFF,
//        Names.GENERAL_ID_REGISTRATION,
//        Names.GENERAL_GENDER,
//        Names.PLN_NATIONALITY,
//        Names.PLN_BIRTH_DATE,
//        Names.PLN_SENIORITY_DATE,
//        Names.PLN_HIRE_DATE,
//        Names.PLN_COUNTRY,
//        Names.PLN_CITY,
//        Names.PLN_BUSINESS_UNIT,
//        Names.PLN_EMPLOYEE_STATUS,
//        Names.PLN_DIVISION,
//        Names.PLN_DEPARTMENT,
//        Names.PLN_EMPLOYEE_CLASS,
//        Names.PLN_LOCAL_CATEGORY,
//        Names.PLN_GLOBAL_CATEGORY,
//        Names.PLN_COLLECTIVE_AGREEMENT,
//        Names.PLN_UNDER_UNION_AGREEMENT,
//        Names.PLN_FUNCTIONAL_AREA,
//        Names.PLN_SUBACTIVITY,
//        Names.PLN_FTE,
//        Names.PLN_REDUCED_WORK_DAY,
//        Names.PLN_CONTRACT_TYPE,
//        Names.PLN_STANDARD_POSITION_HOURS,
//        Names.PLN_STANDARD_WEEKLY_HOURS,
//        Names.PLN_ACTUAL_WEEKLY_HOURS,
//        Names.PLN_DISABILITY,
//        Names.PLN_INTERNATIONAL_SHORT_TERM_ASSIGNEE,
//        Names.GENERAL_EMAIL,
//        Names.PLN_EWORK, //    --> No aparecen estos campo en la nueva estructura de HEADCOUNTS
//        Names.PLN_EMPLOYEE_TYPE,
//        Names.PLN_REGION,
//        Names.PLN_COMMENTS
//
//      ).dropDuplicates()
    //      .withColumn(Names.GENERAL_ID_GLOBAL,Main.generar_IDGLOBAL(
    //      HST_HEADCOUNTS_TOT_ORDERED(Names.GENERAL_ID_SSFF),
    //      HST_HEADCOUNTS_TOT_ORDERED(Names.GENERAL_COD_LEGAL_ENTITY).cast(StringType),
    //      HST_HEADCOUNTS_TOT_ORDERED(Names.GENERAL_ID_REGISTRATION)
    //    ))

    //HST_HEADCOUNTS_TOT_ORDERED2.persist()
    /**
     * Ya tenemos el DF "listo" para guardar, ahora hay que hacer las comprobaciones
     * Empezamos con las comprobaciones relativas a picklist:
     * -FUNCTIONAL_AREA
     * -CONTRACT_TYPE
     * -EMPLOYE_CLASS
     * -GENDER
     * -NATIONALITY
     * -COUNTRY
     * -GLOBAL_CATEGORY
     * -EMPLOYE_STATUS
     * -INTERNATIONAL_SHORT_TERM_ASIGNEE
     * -REDUCED_WORK_DAY
     * -DISABILITY
     * -SUBACTIVITY
     * -COD_LEGAL_ENTITY
     * -BUSSINESS_UNIT
     **/

      /*
       -FUNCTIONAL_AREA
       */

//println("comienzan las validaciones")
//    val FUNCTIONAL_AREA_OK = CheckNull.checkNull(dflegalentity,false,Names.PLN_FUNCTIONAL_AREA)
//    dflegalentity.unpersist()
//    /*HST_HEADCOUNTS_TOT_ORDERED2.withColumn(Names.PLN_FUNCTIONAL_AREA,
//          when(HST_HEADCOUNTS_TOT_ORDERED2(Names.PLN_FUNCTIONAL_AREA).isNull,
//           "Desconocido").
//            otherwise(HST_HEADCOUNTS_TOT_ORDERED2(Names.PLN_FUNCTIONAL_AREA))).dropDuplicates()*/
//
//    /*
//       -CONTRACT_TYPE
//       */
//
//    val CONTRACT_TYPE_OK = CheckNull.checkNull(FUNCTIONAL_AREA_OK,false,Names.PLN_CONTRACT_TYPE)
//    FUNCTIONAL_AREA_OK.unpersist()
//    /*FUNCTIONAL_AREA_OK.withColumn(Names.PLN_CONTRACT_TYPE,
//      when(FUNCTIONAL_AREA_OK(Names.PLN_CONTRACT_TYPE).isNull,
//        "Desconocido").
//        otherwise(FUNCTIONAL_AREA_OK(Names.PLN_CONTRACT_TYPE))).dropDuplicates()*/
//
//    /*
//       -EMPLOYE_CLASS
//       */
//    val EMPLOYE_CLASS_OK = CheckNull.checkNull(CONTRACT_TYPE_OK,false,Names.PLN_EMPLOYEE_CLASS)
//    CONTRACT_TYPE_OK.unpersist()
//
//    /*CONTRACT_TYPE_OK.withColumn(Names.PLN_EMPLOYEE_CLASS,
//      when(CONTRACT_TYPE_OK(Names.PLN_EMPLOYEE_CLASS).isNull,
//        "Desconocido").
//        otherwise(CONTRACT_TYPE_OK(Names.PLN_EMPLOYEE_CLASS))).dropDuplicates()*/
//
//    /*
//    GENDER --> Vamos a ver los distintos valores que hay para gender, 3 F/M/null
//    si null -> 0
//     */
//    val GENDER_OK= CheckNull.checkNull(EMPLOYE_CLASS_OK,true,Names.GENERAL_GENDER)
//    EMPLOYE_CLASS_OK.unpersist()
//
//    /*EMPLOYE_CLASS_OK
//      .withColumn(Names.GENERAL_GENDER,
//      when(EMPLOYE_CLASS_OK(Names.GENERAL_GENDER).isNull,
//        "0").
//        otherwise(EMPLOYE_CLASS_OK(Names.GENERAL_GENDER))).dropDuplicates()*/
//    /*
//    -NATIONALITY
//     */
//    val NATIONALITY_OK = CheckNull.checkNull(GENDER_OK,false,Names.PLN_NATIONALITY)
//    GENDER_OK.unpersist()
//
//
//    /*GENDER_OK.withColumn(Names.PLN_NATIONALITY,
//      when(GENDER_OK(Names.PLN_NATIONALITY).isNull,
//        "Desconocido").
//        otherwise(GENDER_OK(Names.PLN_NATIONALITY))).dropDuplicates()*/
//
//    /* -GLOBAL_CATEGORY
//     */
//    val GLOBAL_CATEGORY_OK = CheckNull.checkNull(NATIONALITY_OK,false,Names.PLN_GLOBAL_CATEGORY)
//    NATIONALITY_OK.unpersist()
//
//
//    /*NATIONALITY_OK.withColumn(Names.PLN_GLOBAL_CATEGORY,
//      when(NATIONALITY_OK(Names.PLN_GLOBAL_CATEGORY).isNull,
//        "Desconocido").
//        otherwise(NATIONALITY_OK(Names.PLN_GLOBAL_CATEGORY))).dropDuplicates()*/
//    /*
//    * -EMPLOYE_STATUS
//     */
//    val EMPLOYE_STATUS_OK = CheckNull.checkNull(GLOBAL_CATEGORY_OK,true,Names.PLN_EMPLOYEE_STATUS)
//    GLOBAL_CATEGORY_OK.unpersist()
//
//    /*GLOBAL_CATEGORY_OK.withColumn(Names.PLN_EMPLOYEE_STATUS,
//      when(GLOBAL_CATEGORY_OK(Names.PLN_EMPLOYEE_STATUS).isNull,
//        "Desconocido").
//        otherwise(GLOBAL_CATEGORY_OK(Names.PLN_EMPLOYEE_STATUS))).dropDuplicates()*/
//
//    /*
//     * -INTERNATIONAL_SHORT_TERM_ASIGNEE
//     */
//
//    val INTERNATIONAL_SHORT_TERM_ASIGNEE_OK = CheckNull.checkNull(EMPLOYE_STATUS_OK,true,Names.PLN_INTERNATIONAL_SHORT_TERM_ASSIGNEE)
//    EMPLOYE_STATUS_OK.unpersist()
//
//    /*EMPLOYE_STATUS_OK.withColumn(Names.PLN_INTERNATIONAL_SHORT_TERM_ASSIGNEE,
//      when(EMPLOYE_STATUS_OK(Names.PLN_INTERNATIONAL_SHORT_TERM_ASSIGNEE).isNull,
//        "0").
//        otherwise(EMPLOYE_STATUS_OK(Names.PLN_INTERNATIONAL_SHORT_TERM_ASSIGNEE))).dropDuplicates()*/
//
//    //HST_HEADCOUNTS_TOT_GENDER_OK.select(Names.GENERAL_GENDER).dropDuplicates().show(30,false)
//  /*
//          INTERNATIONAL_SHORT_TERM_ASIGNEE
//  */
//    //HST_HEADCOUNTS_TOT_GENDER_OK//.select(Names.PLN_INTERNATIONAL_SHORT_TERM_ASSIGNEE).dropDuplicates().show
//
//
///*
//    * -REDUCED_WORK_DAY
//   */
//
//    val REDUCED_WORK_DAY_OK = CheckNull.checkNull(INTERNATIONAL_SHORT_TERM_ASIGNEE_OK,false,Names.PLN_REDUCED_WORK_DAY)
//    INTERNATIONAL_SHORT_TERM_ASIGNEE_OK.unpersist()
//
//    /*INTERNATIONAL_SHORT_TERM_ASIGNEE_OK.withColumn(Names.PLN_REDUCED_WORK_DAY,
//      when(INTERNATIONAL_SHORT_TERM_ASIGNEE_OK(Names.PLN_REDUCED_WORK_DAY).isNull,
//        "Desconocido").
//        otherwise(INTERNATIONAL_SHORT_TERM_ASIGNEE_OK(Names.PLN_REDUCED_WORK_DAY))).dropDuplicates()*/
//
//    /* * -DISABILITY
//    */
//    val DISABILITY_OK = CheckNull.checkNull(REDUCED_WORK_DAY_OK,false,Names.PLN_DISABILITY)
//    REDUCED_WORK_DAY_OK.unpersist()
//
//
//    /*REDUCED_WORK_DAY_OK.withColumn(Names.PLN_DISABILITY,
//      when(REDUCED_WORK_DAY_OK(Names.PLN_DISABILITY).isNull,
//        "Desconocido").
//        otherwise(REDUCED_WORK_DAY_OK(Names.PLN_DISABILITY))).dropDuplicates()*/
//    /*
//
//    * -SUBACTIVITY
//     */
//
//    val SUBACTIVITY_OK = CheckNull.checkNull(DISABILITY_OK,false,Names.PLN_SUBACTIVITY)
//    DISABILITY_OK.unpersist()
//
//    /*DISABILITY_OK.withColumn(Names.PLN_SUBACTIVITY,
//
//      when(DISABILITY_OK(Names.PLN_SUBACTIVITY).isNull,
//        "Desconocido").
//        otherwise(DISABILITY_OK(Names.PLN_SUBACTIVITY))).dropDuplicates()*/
//    /*
//    COD_LEGAL_ENTITY
//    */
//    //HST_HEADCOUNTS_TOT_ROTANTE_OK.select(Names.GENERAL_COD_LEGAL_ENTITY).dropDuplicates().show
//    val COD_LEGAL_ENTITY_OK = CheckNull.checkNull(SUBACTIVITY_OK, true,Names.GENERAL_COD_LEGAL_ENTITY)
//    SUBACTIVITY_OK.unpersist()
//
//    val LOCAL_CATEGORY_OK = CheckNull.checkNull(COD_LEGAL_ENTITY_OK,false,Names.PLN_LOCAL_CATEGORY)
//    /*
//    * -BUSSINESS_UNIT
//    */
//    val BUSSINESS_UNIT_OK = CheckNull.checkNull(LOCAL_CATEGORY_OK,true,Names.PLN_BUSINESS_UNIT)
//    //HST_HEADCOUNTS_TOT_ORDERED2.unpersist()
//
//    val CITY_OK = CheckNull.checkNull(BUSSINESS_UNIT_OK,false,Names.PLN_CITY)
//    //print("seniority")
//    val SENIORITY_OK = CITY_OK.withColumn(Names.PLN_SENIORITY_DATE,
//      when(CITY_OK(Names.PLN_SENIORITY_DATE).isNull,
//        "01/01/1900").
//        otherwise(CITY_OK(Names.PLN_SENIORITY_DATE))).dropDuplicates()
//
//
//
//
//
//    //println("country")
//    val COUNTRY_OK = CheckNull.checkNull(SENIORITY_OK,false,Names.PLN_COUNTRY)
//
//
//    //println("division")
//
//    val DIVISION_OK =  CheckNull.checkNull(COUNTRY_OK,false,Names.PLN_DIVISION)
//    //println("department")
//    val DEPARTMENT_OK = CheckNull.checkNull(DIVISION_OK,false,Names.PLN_DEPARTMENT)
//    //print("local_category")
//
//    val UNION_UNDER_AGREGMENT_OK = CheckNull.checkNull(DEPARTMENT_OK,false,Names.PLN_UNDER_UNION_AGREEMENT)
//    //println("standar_position_hours")
//
//
//    val STANDARD_POSITION_HOURS_OK = CheckNull.changeNullToDecimal(UNION_UNDER_AGREGMENT_OK,Names.PLN_STANDARD_POSITION_HOURS)
//    //print("standar_weekly_hours")
//    val STANDARD_WEEKLY_HOURS_OK = CheckNull.changeNullToDecimal(STANDARD_POSITION_HOURS_OK,Names.PLN_STANDARD_WEEKLY_HOURS)
//
//
//
//    //println("ahora los duplicados")
//    //Hay que sacar los valores duplicados para la pk ID_GLOBAL, COD_LEGAL_ENTITY, MONTH, YEAR
//    //val dfFinal = TratamientoDuplicados.compruebaGeneraNuevosDuplicadosDF(BUSSINESS_UNIT_OK)
    //println("Fichero guardado numero de registros: "+ dflegalentity.count())
    SaveCSV.guardarDFEnCSV(dflegalentity, dir, true, file)




  }


}
