package log

import org.apache.log4j.Logger

/**
 * Objeto que realiza la lógica de escribir en fichero de LOG. En función de los parámetros que reciba escribirá de
 * tipo DEBUG, INFO, o ERROR.
 */
object ControlLog {

  def logDebug(clase: String)(mensaje: String): Unit = {
    //Variable de tipo log donde creamos nuestro log y le damos un nombre
    val logger: Logger = Logger.getLogger(clase)

    log(m => logger.debug(m), mensaje)
  }

  def logInfo(clase: String)(mensaje: String): Unit = {
    //Variable de tipo log donde creamos nuestro log y le damos un nombre
    val logger: Logger = Logger.getLogger(clase)

    log(m => logger.info(m), mensaje)
  }

  def logWarn(clase: String)(mensaje: String): Unit = {
    //Variable de tipo log donde creamos nuestro log y le damos un nombre
    val logger: Logger = Logger.getLogger(clase)

    log(m => logger.warn(m), mensaje)
  }

  def logError(clase: String)(mensaje: String): Unit = {
    //Variable de tipo log donde creamos nuestro log y le damos un nombre
    val logger: Logger = Logger.getLogger(clase)

    log(m => logger.error(m), mensaje)
  }

  private def log(statusInfo: String => Unit, mensaje: String): Unit = {
    statusInfo(mensaje)
  }
}
