package utilities
import org.yaml.snakeyaml.Yaml
import org.yaml.snakeyaml.constructor.Constructor

import java.io.{File, FileInputStream}

import entities.TablasValidar

object YamlParser {

  def getTablesYaml()= {
    val input = new FileInputStream((getClass.getResource("/YAML_validaciones_prueba.yaml").getPath))//new File("/home/onhr_master/SFSF/PRUEBA/validador_sh/YAML_validaciones_prueba.yaml"))//
    //val input = new FileInputStream("C:\\Workspaces\\validador registros\\comprobacionRegistros\\src\\main\\resources\\YAML_validaciones_prueba.yaml")
    val yaml = new Yaml(new Constructor(classOf[TablasValidar]))
    val e = yaml.load(input).asInstanceOf[TablasValidar]
    println(e)
    e
  }
}

