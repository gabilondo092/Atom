package utilities

import java.io.InputStream
import com.fasterxml.jackson.databind.ObjectMapper
import com.fasterxml.jackson.dataformat.yaml.YAMLFactory


object Utils {
  /**
   * ########################  Start IMPURE Functions  ###############################################################
   */

  /**
   * ImpureFunction privada genérica encargada de leer el archivo de propiedades YAML.
   *
   * //@param pathProperties   String con la ruta donde se alberga el fichero YAML
   *///@return                 T clase genérica con las propiedades almacenadas en un Object.
   //*/
//  private def getProperties[T](classProperty: Class[T], pathProperties: String): T  = {
//    val fichero_propiedades: InputStream = this.getClass.getResourceAsStream(pathProperties)
//    val mapper = new ObjectMapper(new YAMLFactory())
//
//    mapper.readValue(fichero_propiedades, classProperty)
//  }
//
//  /**
//   * ImpureFunction encargada de leer el archivo de propiedades YAML de sensibilidad.
//   *
//   * @return   YamlProperty con el contenido estructurado de las propiedades YAML de sensibilidad.
//   */
//  def getSensitiveProperties: YamlProperties  = getProperties(classOf[YamlProperties], Variables.Paths.SENSITIVE_PROPERTIES)
//  /**
//   * ########################  End IMPURE Functions  #################################################################
//   */

}