package utilities

object Variables {
  object Paths {
    val SENSITIVE_PROPERTIES: String = "/YAML_validaciones.yaml"
  }

  /*object Config {
    lazy val property: ConfigProperty = Utilities.getConfigProperties
  }*/

}