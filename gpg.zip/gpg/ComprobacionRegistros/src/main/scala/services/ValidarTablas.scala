package services

import bbdd.utilities.GetDataframe
import entities.Tabla
import org.apache.hadoop.fs.FileSystem
import org.apache.spark.sql.{DataFrame, SparkSession}
import utilities.SparkUtils

import scala.collection.JavaConverters._
object ValidarTablas {

  def comprobar(tabla: Tabla, spark: SparkSession, fs:FileSystem): Unit = {
    println("Empezamos a validar la tabla: " + tabla)
    val table = tabla.name
    val keys: Array[String] = tabla.keys.asScala.toArray
    val keysF3 : Array[String] = tabla.keysF3.asScala.toArray

    tabla.toString

    //Dataframe F2


    val sourceDf: DataFrame = GetDataframe.getDataframeMySQL(table, "onhr_val")
    //sourceDf.show(false)
    println(sourceDf.count())
    println("Ahora intentamos obtener la tabla de fase 3")

 /*
    val tableF3 = GetDataframe.getTableOfHive(table, spark)
    //tableF3.show(false)
    //println(tableF3.count())
    //Una vez que tenemos los df completos los filtramos y cruzamos las keys
    val dfF3Keys = tableF3.select(keys.head, keys.tail: _*).dropDuplicates()
    //Obtenemos de F3 las keys en un df
    println("cantidad de keys en F3: " + dfF3Keys.count())
    val df2Keys = sourceDf.select(keys.head, keys.tail: _*).dropDuplicates()
    println("cantidad de keys en F2: " + df2Keys.count())
    val keysMissingDf2 = df2Keys.except(dfF3Keys)
    println("keys faltantes: " + keysMissingDf2.count())
    if (keysMissingDf2.count() > 0) {
      //ahora restamos las keys si son distintas

      //keysMissingDf2.show(false)
      val dfFiltrado = sourceDf.join(keysMissingDf2,Seq(keysMissingDf2.columns:_*),"inner")
      println("registros filtrados: "+dfFiltrado.count())
      //dfFiltrado.show(false)
      SparkUtils.writeCsvTable(table,fs,dfFiltrado)
      // método recursivo que obtiene el dataframe final ya filtrado
      //val dfFinal = filterFieldsOfDataFrame(keysMissingDf2.columns.toList, sourceDf, keysMissingDf2).dropDuplicates()

      //println("El volumen del DFfinal es " + dfFinal.count())

    } else {
      println("Las tablas estan bien")
      SparkUtils.writeTableOk(table,fs)
    }

     */
  }


}
