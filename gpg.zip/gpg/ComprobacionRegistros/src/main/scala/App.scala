

import entities.TablasValidar
import log.ControlLog
import org.apache.hadoop.fs.FileSystem
import org.apache.hadoop.fs.permission.{FsAction, FsPermission}
import services.ValidarTablas
import utilities.{SparkUtils, YamlParser}

import scala.collection.JavaConverters._

object App extends App {
  val clase = this.getClass.getCanonicalName.split("\\$").last

  def logInfo = ControlLog.logInfo(clase)(_)
  def logDebug = ControlLog.logDebug(clase)(_)
  def logError = ControlLog.logError(clase)(_)
  val spark = SparkUtils.spark
  val conf = spark.sparkContext.hadoopConfiguration
  val fs : FileSystem = org.apache.hadoop.fs.FileSystem.get(conf)
  try {
    println("Inicio de la ejecucion del comprobador")
    logInfo("Inicio de la ejecucion del comprobador")
    val tablasValidar: TablasValidar = YamlParser.getTablesYaml()

    tablasValidar.tablasValidar.asScala.map(ValidarTablas.comprobar(_, spark,fs))

  } finally {
    SparkUtils.cerrarContexto()
    println("Fin de la ejecucion del comprobador")
  }





}
