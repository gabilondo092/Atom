package bbdd.utilities

import java.sql.{Connection, DriverManager, Statement}

class MySQLConnection {
  private val url = "jdbc:mysql://10.93.27.247:3306/onhr_val?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC"
  private val driver = "com.mysql.cj.jdbc.Driver"
  private val username = "onhr_master"
  private val password = "U9w83lY6GjVPe96BiAaub2APhN6CceFF"
  private var connection:Connection = null
  def connect(): Connection ={

    if (connection==null){
      try {
        Class.forName(driver)
        connection = DriverManager.getConnection(url, username, password)
      } catch {
        case e: Exception => e.printStackTrace
      }
    }
    connection
  }
  def disconnect() = {
    connection.close
  }

  def createStatement(): Statement ={
    connection.createStatement
  }
}

