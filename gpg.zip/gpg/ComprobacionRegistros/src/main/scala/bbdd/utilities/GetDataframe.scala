package bbdd.utilities

import java.util.TimeZone

import org.apache.spark.sql.{DataFrame, SparkSession}
import utilities.SparkUtils

object GetDataframe {

  //val url = "jdbc:mysql://10.93.27.247:3306/onhr_val?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC"
  val driver = "com.mysql.cj.jdbc.Driver"
  val username = "onhr_master"
  val password = "U9w83lY6GjVPe96BiAaub2APhN6CceFF"

  def getDataframeMySQL(table: String, schema: String): DataFrame = {
    val url = s"jdbc:mysql://10.93.27.247:3306/$schema?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone="+TimeZone.getDefault().getID()
    SparkUtils.spark.read.format("jdbc")
      .option("driver", driver)
      .option("url", url)
      .option("dbtable", table)
      .option("user", username)
      .option("password", password)
      .load()
  }

  def getTableOfHive( table: String, spark: SparkSession): DataFrame = {
    println("Se procede a obtener de Hive la tabla \"" + table + "\".")
    spark.sql("select * from onhr_global." + table)
  }
}
