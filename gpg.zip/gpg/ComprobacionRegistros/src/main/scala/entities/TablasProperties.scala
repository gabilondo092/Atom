package entities

import java.util

import scala.beans.BeanProperty


class TablasProperties(@BeanProperty TablasValidar: util.ArrayList[Tabla]) {
  val Tablas: util.ArrayList[Tabla] = TablasValidar
}

