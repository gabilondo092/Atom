package entities

import scala.beans.BeanProperty

class TablasValidar {
  @BeanProperty var tablasValidar = new java.util.ArrayList[Tabla]()
  override def toString: String = s"tablasValidar: $tablasValidar"
}