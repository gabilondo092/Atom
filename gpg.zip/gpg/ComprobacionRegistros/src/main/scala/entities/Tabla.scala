package entities

import scala.beans.BeanProperty


class Tabla {
  @BeanProperty var name = ""
  @BeanProperty var keys = new java.util.ArrayList[String]()
  @BeanProperty var keysF3 = new java.util.ArrayList[String]()
  override def toString: String = s"name: $name, keys: $keys, keys_F3: $keysF3"
}
