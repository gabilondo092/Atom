package com.redes.models

import org.apache.spark.sql.types._
import com.redes.models.Variables._

object RedesStructs {

  val schemaExpedientes: StructType = StructType(Seq(
    StructField(Expediente.ID, StringType, nullable = true),
    StructField(Expediente.NUMERO_DOCUMENTO, StringType, nullable = true),
    StructField(Expediente.NUM_EXPEDIENTE, StringType, nullable = true),
    StructField(Expediente.FASE, StringType, nullable = true),
    StructField(Expediente.RAZON_SOCIAL, StringType, nullable = true),
    StructField(Expediente.CCAA, StringType, nullable = true),
    StructField(Expediente.FECHA_ENTRADA, StringType, nullable = true),
    StructField(Expediente.AEAT, IntegerType, nullable = true),
    StructField(Expediente.SS, IntegerType, nullable = true),
    StructField(Expediente.CONVOCATORIA, StringType, nullable = true),
    StructField(Expediente.TIPO_DOCUMENTO, StringType, nullable = true)
  ))

  val schemaIterpreteGeneral: StructType = StructType(Seq(
    StructField(InterpreteGeneral.ID_ROBOT, StringType, nullable = true),
    StructField(InterpreteGeneral.CODIGO_CERTIFICADO, StringType, nullable = true),
    StructField(InterpreteGeneral.FASE, StringType, nullable = true),
    StructField(InterpreteGeneral.CAMPOS_CONSULTA, StringType, nullable = true),
    StructField(InterpreteGeneral.AEAT, StringType, nullable = true),
    StructField(InterpreteGeneral.SS, StringType, nullable = true)))


  val schemaProcedimiento: StructType = StructType(Seq(
    StructField(Procedimiento.CODIGO_PROCEDIMIENTO, StringType, nullable = true),
    StructField(Procedimiento.NOMBRE_PROCEDIMIENTO, StringType, nullable = true),
    StructField(Expediente.CONVOCATORIA, StringType, nullable = true)))
}