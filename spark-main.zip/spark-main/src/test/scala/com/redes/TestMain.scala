package com.redes

import com.redes.RedesUtils._
import com.redes.models.Variables.{Expediente, Estado_expediente}
import org.apache.spark.sql.functions.{size,array, array_contains, array_intersect, col, concat, lit, regexp_replace, when}
import org.scalatest.FunSuite
import org.apache.spark.sql.{Column, DataFrame, Row, SaveMode, SparkSession, functions}

class TestMain extends FunSuite  with TestBase {

  test("Proceso IDA")
  {
    val rddExpediente = _sparkSql.sparkContext.parallelize(Seq(
      Row("1","0000000L","1","T","PYME1","Madrid","2021-12-27 03:24:30.458",1, 1, "Conv1", "NIF"),
      Row("2","0000001L","2","T","PYME2","Madrid","2021-12-27 04:24:30.458",null, 1, "Conv1", "NIF"),
      Row("3","0000002L","3","OTRO","PYME2","Madrid","2021-12-27 04:24:30.458",null, 1, "Conv1", "NIF")
    ))

    val rddInterpreteGeneral = _sparkSql.sparkContext.parallelize(Seq(
      Row("5", "SVDCCAACPASWS01", "T", "codigo_comunidad_autonoma=16, codigo_provincia =00 (miramos en todas) ", "0", "0"),
      Row("8", "SVDIGAEINHABILITACIONWS01", "T", null, "1", "0")/*,
  Row("9", "iae_gen", "T", "ejercicio=ejercicio (campo entrada AAAA),epigrafe_iae_in =cod_epigrafe_iae(campo entrada)", "0", "0")*/
    ))

    val rddProcedimiento = _sparkSql.sparkContext.parallelize(Seq(
      Row("1", "Procedimiento1","Conv1"),
      Row("2", "Procedimiento2","Conv2"),
      Row("3", "Procedimiento3","Conv3")
    ))

    val dfExpediente =_sparkSql.createDataFrame(rddExpediente, models.RedesStructs.schemaExpedientes)
    val dfInterpreteGeneral =_sparkSql.createDataFrame(rddInterpreteGeneral, models.RedesStructs.schemaIterpreteGeneral)
    val dfProcedimiento =_sparkSql.createDataFrame(rddProcedimiento, models.RedesStructs.schemaProcedimiento)
    dfExpediente.show()
    dfInterpreteGeneral.show()
    dfProcedimiento.show()

    val caminoida = CaminoIda.CaminoIda(conf)
    val df_final = caminoida
      .generaCaminoIda(dfExpediente,dfInterpreteGeneral,dfProcedimiento)
    val json = df_final._2.withColumn(Estado_expediente.PATH, concat(lit("tramitar/"),
      regexp_replace(col(Expediente.NUM_EXPEDIENTE),"/","") , lit("_") , dataTimestamp , lit("_R_in.json")))
    json.show()

    val estadoExpediente = json.withColumn(Estado_expediente.ESTADO,lit("003"))
      .withColumn(Estado_expediente.TS_JSON_SGAD,lit(dataTimestampseg))
      .withColumn(Estado_expediente.UBI_JSON_SGAD,col(Estado_expediente.PATH))
      .withColumn(Estado_expediente.TS_JSON_REDES,lit(dataTimestampseg))
      .withColumn(Estado_expediente.UBI_JSON_REDES,col(Estado_expediente.PATH))
      .select(Expediente.ID,Expediente.NUM_EXPEDIENTE,Estado_expediente.ESTADO,Estado_expediente.TS_JSON_SGAD,
        Estado_expediente.UBI_JSON_SGAD, Estado_expediente.TS_JSON_REDES, Estado_expediente.UBI_JSON_REDES)

    estadoExpediente.show()

    val salidaCsv = json.withColumn("FECHA",lit("2021-11-29"))
      .withColumnRenamed(Expediente.NUM_EXPEDIENTE,"EXPEDIENTE")
      .select(Expediente.ID,"EXPEDIENTE","FECHA","PATH")
    salidaCsv.show()

  }

  test("Función observaciones")
  {
    val entrada = _sparkSql.read.schema(com.redes.models.Schemas.schemaResultadoRobot)
      .json("src/test/resources/jsonPrueba*")
      .withColumn("id_robot",lit(8))

    val camino = CaminoVuelta.CaminoVuelta(conf)
    val resultado = camino.funResultado(entrada,"2021-12-29")
    resultado.show()
    val observacion = camino.funObsevacion(resultado)
    observacion.show(false)
  }
}
