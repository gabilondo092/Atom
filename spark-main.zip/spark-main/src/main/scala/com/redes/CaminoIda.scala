package com.redes

import com.redes.RedesUtils._
import com.redes.models.Variables.{InterpreteGeneral, _}
import org.apache.spark.SparkConf
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SaveMode, SparkSession, functions}
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import org.apache.hadoop.fs._


class CaminoIda(properties: Map[String,String])(implicit spark: SparkSession) {
  //Parametros de entrada
  lazy val schemaExpedientes: String = properties("schema.expedientes")
  lazy val inputExpedientes: String = properties("input.expedientes")
  lazy val schemaInterprete: String = properties("schema.interprete")
  lazy val inputInterprete: String = properties("input.interprete")
  lazy val schemaProcedimiento: String = properties("schema.procedimiento")
  lazy val inputProcedimiento: String = properties("input.procedimiento")

  lazy val schemaEstadoExpedienteRob: String = properties("schema.estadoexpedienterob")
  lazy val outputEstadoExpedienteRob: String = properties("output.estadoexpedienterob")
  lazy val schemaEstadoExpediente: String = properties("schema.estadoexpediente")
  lazy val outputEstadoExpediente: String = properties("output.estadoexpediente")

  lazy val outputBucketJson:String = properties("output.bucketjson")
  lazy val outputBucketCsv:String = properties("output.bucketcsv")


  lazy val datosComunes = struct(col(Expediente.ID).alias("id"),
    col(Expediente.NUM_EXPEDIENTE).alias("num_expediente"),
    col(Expediente.TIPO_DOCUMENTO).alias("tipo_documento"),
    col(Expediente.NUMERO_DOCUMENTO).alias("numero_documento"),
    col(Procedimiento.CODIGO_PROCEDIMIENTO).alias("codigo_procedimiento"),
    col(Procedimiento.NOMBRE_PROCEDIMIENTO).alias("nombre_procedimiento"))

  lazy val consultaRobot = Map(
    "8" -> struct(col(InterpreteGeneral.CODIGO_CERTIFICADO).alias("codigo_certificado"), lit(null).alias("codigo_comunidad_autonoma"), lit(null).alias("codigo_provincia")),
    "5" -> struct(col(InterpreteGeneral.CODIGO_CERTIFICADO).alias("codigo_certificado"), lit("16").alias("codigo_comunidad_autonoma"), lit("00").alias("codigo_provincia")),
    "6" -> struct(lit(null).alias("codigo_certificado"), lit(null).alias("codigo_comunidad_autonoma"), lit(null).alias("codigo_provincia"))
  )

  var datadate:String = null
  val executionTime:String = DateTimeFormatter.ofPattern("yyyyMMddHHmm").format(LocalDateTime.now)

  def generaCaminoIda(expedientes: DataFrame, interprete: DataFrame, procedimiento: DataFrame): Tuple2[DataFrame, DataFrame] = {

    /*val robotsColumn = interprete
      .dropDuplicates(InterpreteGeneral.ID_ROBOT)
      .select(col(InterpreteGeneral.ID_ROBOT))
      .collect()
      .map(x => col(x.get(0).toString))
      .toList

    val aplicaRobotsFilter: Column = robotsColumn.map( _ === lit(true)).reduce(_ or _)*/

    val aplicaRobot = expedientes
      .withColumn("robot8", when(col(Expediente.FASE) === lit(TRAMITADO) and col(Expediente.AEAT).isNotNull, lit(true)).otherwise(lit(false)))
      .withColumn("robot5", when(col(Expediente.FASE) === lit(TRAMITADO), lit(true)).otherwise(lit(false)))

    val estadoExpedienteRobot = aplicaRobot
      //.filter(aplicaRobotsFilter)
      .selectExpr(Expediente.NUM_EXPEDIENTE, Expediente.CCAA, Expediente.FECHA_ENTRADA, Expediente.NUMERO_DOCUMENTO, Expediente.RAZON_SOCIAL,
        Expediente.TIPO_DOCUMENTO, Expediente.CONVOCATORIA, Expediente.ID, "stack(2,'robot5',robot5,'robot8',robot8)")
      .withColumnRenamed("col0", InterpreteGeneral.ID_ROBOT)
      .withColumnRenamed("col1", "aplica")
      .filter(col("aplica")=== lit(true))
      .withColumn(InterpreteGeneral.ID_ROBOT, substring(col(InterpreteGeneral.ID_ROBOT), -1,1))

    estadoExpedienteRobot.show()

    val interpreteMod = interprete
      .select(InterpreteGeneral.ID_ROBOT, InterpreteGeneral.CODIGO_CERTIFICADO,InterpreteGeneral.CAMPOS_CONSULTA)

    interpreteMod.show()


    val camposProcedimiento = estadoExpedienteRobot
      .join(procedimiento, Seq(Expediente.CONVOCATORIA), "left")
      .join(interpreteMod,Seq(InterpreteGeneral.ID_ROBOT),"left")


    camposProcedimiento.show()


   val df = camposProcedimiento
     .withColumn(Salida_json.DATOS_CONSULTA, when(col(InterpreteGeneral.ID_ROBOT)===lit("8"), consultaRobot("8"))
      .otherwise(when(col(InterpreteGeneral.ID_ROBOT) === lit("5"), consultaRobot("5"))
        .otherwise(when(col(InterpreteGeneral.ID_ROBOT) === lit("6"), consultaRobot("6"))
          .otherwise(null))))
     .withColumn(Salida_json.DATOS_COMUNES, datosComunes)
     .select(Expediente.ID,Expediente.NUM_EXPEDIENTE, Salida_json.DATOS_COMUNES, Salida_json.DATOS_CONSULTA)

    df.show(false)

    val dfSalida = df.groupBy(Expediente.NUM_EXPEDIENTE)
      .agg(first(Expediente.ID).as(Expediente.ID),first(Salida_json.DATOS_COMUNES).as(Salida_json.DATOS_COMUNES), collect_list(Salida_json.DATOS_CONSULTA).as(Salida_json.DATOS_CONSULTA))

    dfSalida.show(false)

    (estadoExpedienteRobot, dfSalida)
  }


  def escribeJson(salida:DataFrame):Unit ={
    //val path = "/tmp/salida.json"
    val path = getPathJson()
    //val path = "/home/hadoop/salida/"
    salida
      .select(Expediente.NUM_EXPEDIENTE,Salida_json.DATOS_COMUNES,Salida_json.DATOS_CONSULTA)
      .write.partitionBy(Expediente.NUM_EXPEDIENTE).format("json").option("header","true").mode("Overwrite")
      .save(path)
  }

  def escribeCsv(salida:DataFrame):Unit ={
    //val path = "/tmp/indice/"+datadate
    val path =  outputBucketCsv +"/indice/"+datadate
    //val path = "/home/hadoop/salida"
    salida.coalesce(1).write.mode("overwrite")
      .format("com.databricks.spark.csv").option("header", "true")
      .csv(path)

    RedesUtils.renameFileSystem( new Path(path+"/part*.csv"), new Path(path+"/indice"+executionTime+".csv") )
  }

  def getPathJson(): String ={
    return outputBucketJson+ "TRAMITAR/"+datadate+"/"
  }

  def execution(date:String): Unit = {
    datadate = date
    val expedientes = spark.table(s"$schemaExpedientes.$inputExpedientes")

    val interprete = spark.table(s"$schemaInterprete.$inputInterprete")

    val procedimiento = spark.table(s"$schemaProcedimiento.$inputProcedimiento")

    val caminoIda = generaCaminoIda(expedientes, interprete, procedimiento)

    val estadoExpedienteRobot = caminoIda._1.select(Expediente.NUM_EXPEDIENTE,InterpreteGeneral.ID_ROBOT)
    estadoExpedienteRobot.show()

    val calculaJson = caminoIda._2.withColumn(Estado_expediente.PATH, concat(lit(getPathJson()),
      lit(Expediente.NUM_EXPEDIENTE), lit("="),col(Expediente.NUM_EXPEDIENTE),lit("/")))
    calculaJson.persist()
    calculaJson.show()

    //TODO En las ubicaciones en el caso de tener dos backets diferentes habrá que crear un PATH para cada uno de ellos e insertar el correspondiente
    val estadoExpediente = calculaJson.withColumn(Estado_expediente.ESTADO,lit(Estados.CONSULTA))
      .withColumn(Estado_expediente.TS_JSON_SGAD,lit(dataTimestampseg))
      .withColumn(Estado_expediente.UBI_JSON_SGAD,col(Estado_expediente.PATH))
      .withColumn(Estado_expediente.TS_JSON_REDES,lit(dataTimestampseg))
      .withColumn(Estado_expediente.UBI_JSON_REDES,col(Estado_expediente.PATH))
      .select(Expediente.ID,Expediente.NUM_EXPEDIENTE,Estado_expediente.ESTADO,Estado_expediente.TS_JSON_SGAD,
        Estado_expediente.UBI_JSON_SGAD, Estado_expediente.TS_JSON_REDES, Estado_expediente.UBI_JSON_REDES)

    val salidaCsv = calculaJson.withColumn(Indices_csv.FECHA,lit(date))
      .withColumnRenamed(Expediente.NUM_EXPEDIENTE,Indices_csv.EXPEDIENTE)
      .select(Expediente.ID,Indices_csv.EXPEDIENTE,Indices_csv.FECHA,Estado_expediente.PATH)


    //Llamada a la escritura del JSON
     escribeJson(calculaJson)

    //Insercción de la tabla de pares expediente-robot
     insertIntoTable(s"$schemaEstadoExpedienteRob.$outputEstadoExpedienteRob", estadoExpedienteRobot, SaveMode.Overwrite)

    //Inserción de la tabla de estado-expediente
     insertIntoTable(s"$schemaEstadoExpediente.$outputEstadoExpediente", estadoExpediente, SaveMode.Overwrite)

    //LLamada a la escritura del CSV
     escribeCsv(salidaCsv)

  }
}

object CaminoIda {
  def CaminoIda(conf: SparkConf): CaminoIda = {
    val properties = conf.getAllWithPrefix(s"spark.redes.caminoida.")
    implicit val spark: SparkSession = createSparkSession(properties)
    new CaminoIda(properties.toMap)
  }
}
