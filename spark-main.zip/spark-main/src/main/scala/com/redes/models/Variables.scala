package com.redes.models

import org.apache.spark.sql.Column
import org.apache.spark.sql.functions.{current_timestamp, date_format, lit}

object Variables {
  //Generales
  val TRAMITADO = "T"
  val SUBSANACION = "S"
  object Salida_json{
    val DATOS_CONSULTA = "Datos_consulta"
    val DATOS_COMUNES = "Datos_comunes"
  }
  object Estado_expediente{
    val ESTADO = "estado"
    val TS_JSON_SGAD = "ts_json_sgad"
    val UBI_JSON_SGAD = "ubi_ts_json_sgad"
    val TS_JSON_REDES= "ts_json_redes"
    val UBI_JSON_REDES = "ubi_ts_json_redes"
    val PATH = "PATH"
  }
  object Indices_csv{
    val  FECHA= "FECHA"
    val EXPEDIENTE = "EXPEDIENTE"
  }


  object Expediente {
    val ID = "id"
    val NUMERO_DOCUMENTO = "numero_documento"
    val NUM_EXPEDIENTE = "num_expediente"
    val FASE = "fase"
    val RAZON_SOCIAL = "razon_social"
    val CCAA = "ccaa"
    val FECHA_ENTRADA = "fecha_entrada"
    val AEAT = "check_aeat"
    val SS = "check_ss"
    val CONVOCATORIA = "convocatoria"
    val TIPO_DOCUMENTO = "tipo_documento"
    val EJERCICIO = "ejercicio"
  }

  object InterpreteGeneral {
    val ID_ROBOT = "id_robot"
    val CODIGO_CERTIFICADO = "codigo_certificado"
    val FASE = "fase"
    val CAMPOS_CONSULTA = "campos_consulta"
    val AEAT = "aeat"
    val SS = "ss"
  }

  object Procedimiento {
    val CODIGO_PROCEDIMIENTO = "codigo_procedimiento"
    val NOMBRE_PROCEDIMIENTO = "nombre_procedimiento"
    val CONVOCATORIA = "convocatoria"
  }

  object  Estados {
    val PENDIENTE = "001"
    val CONSULTA = "002"
    val RESPUESTA = "003"
    val PROCESADO = "004"
  }

  object  Entrada_json {
    val INTERPRETACION = "interpretacion"
    val CODIGOSJUSTICIA = "codigosJusticia"
  }
}