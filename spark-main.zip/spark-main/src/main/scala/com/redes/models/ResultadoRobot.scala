package com.redes.models

object ResultadoRobot {

  case class ResultadoRobot(
                             Datos_comunes:List[Datos_comunes],
                             Datos_consulta:List[Datos_consulta]
                           )

  case class Datos_comunes(codigo_procedimiento:String,
                           id:String,
                           nombre_procedimiento:String,
                           num_expediente:String,
                           numero_documento:String,
                           tipo_documento:String
                          )

  case class Datos_consulta(Datos_especificos: List[Datos_especificos],
                            codigo_certificado: String,
                            codigo_estado:String,
                            codigo_scsp:String,
                            interpretacion_ov:String,
                            peticion_pdf:String,
                            resultado:String,
                            time_stamp:String)

  case class Datos_especificos(codigo_clase_inhabilitacion:String,
                               codigo_organo_inhabilitador:String,
                               descripcion_clase_inhabilitacion:String,
                               descripcion_organo_inhabilitador:String,
                               discriminador_inhabilitacion:String,
                               fecha_fin_inhabilitacion:String,
                               fecha_inicio_inhabilitacion:String)
}