package com.redes.models

import com.redes.models.ResultadoRobot.ResultadoRobot
import org.apache.spark.sql.catalyst.ScalaReflection
import org.apache.spark.sql.types.StructType

object Schemas {
  lazy val schemaResultadoRobot = ScalaReflection.schemaFor[ResultadoRobot].dataType.asInstanceOf[StructType]
}
