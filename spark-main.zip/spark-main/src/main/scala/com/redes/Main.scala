package com.redes

import com.redes.RedesUtils._
import org.apache.spark.SparkConf

import scala.util.Try

object Main {
def main(args:Array[String]): Unit = {
    if (args.length != 2)
        throw new IllegalArgumentException("Numero de argumentos erroneos, se esperaban 2: TIPO_EJEC (CAMINOIDA, CAMINOVUELTA), FECHA")

    if (Try{fmt_yyyyMMdd parseDateTime args(1)}.isFailure)
        throw new IllegalArgumentException("El formato de la fecha es inválido, debe ser yyyyMMdd")


    val ejec:: date:: Nil = args.toList

    val dateCorrectFormat = yyyymmddDateToDashed(date)

    val sparkConf = new SparkConf()

    ejec match {
        case "CAMINOIDA" =>
            val ida = CaminoIda.CaminoIda(sparkConf)
            ida.execution(dateCorrectFormat)

        case "CAMINOVUELTA" =>
            val vuelta = CaminoVuelta.CaminoVuelta(sparkConf)
            vuelta.execution(dateCorrectFormat)

        case _ =>
            val msg = s"ERROR: Tipo de ejecucion debe ser CAMINOIDA o CAMINOVUELTA pero se ha recibido $ejec."
            throw new IllegalArgumentException(msg)
    }

  }
}
