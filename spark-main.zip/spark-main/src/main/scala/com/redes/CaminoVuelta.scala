package com.redes

import com.redes.RedesUtils._
import com.redes.models.Variables.{InterpreteGeneral, _}
import org.apache.spark.SparkConf
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{Column, DataFrame, Row, SaveMode, SparkSession}


class CaminoVuelta(properties: Map[String,String])(implicit spark: SparkSession) {
  //Parametros de entrada
  lazy val schemaEstadoExpediente: String = properties("schema.estadoexpediente")
  lazy val inputEstadoExpediente: String = properties("input.estadoexpediente")

  lazy val schemaEstadoExpedienteRob: String = properties("schema.estadoexpedienterob")
  lazy val inputEstadoExpedienteRob: String = properties("input.estadoexpedienterob")

  lazy val schemaInterprete: String = properties("schema.interprete")
  lazy val inputInterprete: String = properties("input.interprete")

  lazy val schemaInterResponsabilidad: String = properties("schema.interresp")
  lazy val inputInterResponsabilidad: String = properties("input.interresp")

  lazy val inputBucketJson: String = properties("input.bucketjson")

  lazy val schemaObservExterno: String = properties("schema.observexterno")
  lazy val outputObservExterno: String = properties("output.observexterno")


  lazy val datosConsulta = col("Datos_consulta").getItem(0)
  lazy val datosEspecificos = datosConsulta.getField("Datos_especificos")

  lazy val datosComunes = col("Datos_comunes").getItem(0).getField("num_expediente")


  /*
  lazy val schemaExpedientes: String = properties("schema.expedientes")
  lazy val inputExpedientes: String = properties("input.expedientes")
  lazy val schemaInterprete: String = properties("schema.interprete")
  lazy val inputInterprete: String = properties("input.interprete")
  lazy val schemaProcedimiento: String = properties("schema.procedimiento")
  lazy val inputProcedimiento: String = properties("input.procedimiento")

*/
  //TODO AÑADIR LOS CÓDIGOS QUE APLIQUEN AL MINISTERIO DE JUSTICIA PARA LA VALIDACIÓN DEL ROBOT 8
  lazy val codigosjust = lit(Array("MJ0000001","MJ0000002"))

  lazy val logicasResult: Map[String, Tuple2[Column, Column]] = Map(
    "8.1" -> (col(Entrada_json.INTERPRETACION) === "OK",struct(lit("OK").as("resultado"),lit("1").as("causa"))),
    "8.2" -> (col(Entrada_json.INTERPRETACION) === "error soporte",struct(lit("Error soporte").as("resultado"),lit("1").as("causa"))),
    "8.3" -> (col(Entrada_json.INTERPRETACION) === "KO" and
      contieneCodigo(datosEspecificos.getField("codigo_organo_inhabilitador"),col("codigosJusticia")) ,
      struct(lit("Informacion de condena encontrada").as("resultado"),lit("8.2").as("causa"))),
    "8.4" -> (col(Entrada_json.INTERPRETACION) === "KO" and
      !contieneCodigo(datosEspecificos.getField("codigo_organo_inhabilitador"),col("codigosJusticia")),
      struct(lit("Informacion de inhabilitaciones encontrada").as("resultado"),lit("8.1").as("causa"))),
    "defecto" -> (null,struct(lit("No encontrada").as("resultado"),lit("No encontrada").as("causa")))
  )

  lazy val logicasObserv: Map[String,Tuple2[Column,Column]] = Map(
    "8.1" -> (col("resultados.resultado")=== lit("OK"),lit("Sin observaciones")),
    "8.2" -> (null, lit("Pendiente de desarrollar")),
    "defecto" -> (null,lit("No es robot 8"))
  )

  def modelizaVuelta(estadoExpediente: DataFrame, entrada: DataFrame, expedienteRobot:DataFrame,interprete:DataFrame,responsabilidad:DataFrame,date:String):Tuple2[DataFrame,DataFrame] = {
    estadoExpediente.show()
    expedienteRobot.show()
    val enTramite = estadoExpediente.join(entrada, col(Expediente.NUM_EXPEDIENTE) === datosComunes, "inner")
    enTramite.persist()
    enTramite.show()
    val recuperaRobot = enTramite.join(expedienteRobot, Seq(Expediente.NUM_EXPEDIENTE), "left")
    recuperaRobot.show()
    val resultado = funResultado(recuperaRobot,date)

    val observaciones = funObsevacion(resultado)

    val recuperaResp = observaciones.join(interprete,Seq(InterpreteGeneral.ID_ROBOT),"left")
      .join(responsabilidad,Seq("responsabilidad"),"left")
      .select("area","id_robot","resultado","causa","fecha","observaciones","id")
      .withColumnRenamed("area","sistema_externo")

    val enTramiteFinal = enTramite
      .withColumn(Estado_expediente.ESTADO,lit(Estados.RESPUESTA))
      .select(Expediente.ID,Expediente.NUM_EXPEDIENTE,Estado_expediente.ESTADO,Estado_expediente.TS_JSON_SGAD,
        Estado_expediente.UBI_JSON_SGAD, Estado_expediente.TS_JSON_REDES, Estado_expediente.UBI_JSON_REDES)

    (recuperaResp,enTramiteFinal)

  }

  def funResultado(recuperaRobot:DataFrame,date:String):DataFrame = {
    val resultado_causa = recuperaRobot.withColumn("fecha", lit(date))
      .withColumn("id", col("Datos_comunes").getItem(0).getField("id"))
      .withColumn(Entrada_json.INTERPRETACION, datosConsulta.getField("interpretacion_ov"))
      .withColumn("codigosJusticia", codigosjust)
      .withColumn("resultados", when(col(InterpreteGeneral.ID_ROBOT) === "8",
        when(logicasResult("8.1")._1, logicasResult("8.1")._2)
          .when(logicasResult("8.2")._1, logicasResult("8.2")._2)
          .when(logicasResult("8.3")._1, logicasResult("8.3")._2)
          .when(logicasResult("8.4")._1, logicasResult("8.4")._2)
          .otherwise(logicasResult("defecto")._2))
        .otherwise(logicasResult("defecto")._2))

    resultado_causa
  }


  def funObsevacion(resultado:DataFrame): DataFrame ={
    //TODO FALTA DARLE UNA VUELTA PARE ENCONTRAR LA SOLUCIÓN, TENEMOS UNA PRIMERA APROXIMACIÓN AL RESULTADO ESPERADO EN EL CASO 8.2, NO CUADRAN POR SER TIPO STRUCT Y NECESITAMOS LLEVARLO A UN STRING
/*
    concat(arrays_zip(array_repeat(lit("descripcion_organo_inhabilitador:"),size(datosEspecificos.getField("descripcion_organo_inhabilitador")))
      ,datosEspecificos.getField("descripcion_organo_inhabilitador"),
      datosEspecificos.getField("fecha_inicio_inhabilitacion"),
      array_repeat(lit("a"),size(datosEspecificos.getField("descripcion_organo_inhabilitador"))),
      datosEspecificos.getField("fecha_fin_inhabilitacion"))))

     */

      val observaciones = resultado
      .withColumn("observaciones",when(col(InterpreteGeneral.ID_ROBOT) === "8",
        when(logicasObserv("8.1")._1,logicasObserv("8.1")._2)
          .otherwise(logicasObserv("8.2")._2))
      .otherwise(logicasObserv("defecto")._2))
      .select("id_robot","fecha","id","resultados.resultado","resultados.causa","observaciones")
    observaciones
  }

  def execution(date: String): Unit = {

    val estadoExpediente = spark.table(s"$schemaEstadoExpediente.$inputEstadoExpediente")
      .filter(col(Estado_expediente.ESTADO) === Estados.CONSULTA)

    //Se leen los json de entrada
    val entrada = spark.read.schema(com.redes.models.Schemas.schemaResultadoRobot)
      .json(inputBucketJson + "/tramitado/*/" + date)
    entrada.show(false)

    //Para aquellos que se recupera el json se buscan los robots que aplican
    val expedienteRobot = spark.table(s"$schemaEstadoExpedienteRob.$inputEstadoExpedienteRob")

    //  .withColumn("codigo_organo",col("Datos_generales.Datos_Especificos.codigo_organo_inhabilitador"))
    val interprete = spark.table(s"$schemaInterprete.$inputInterprete")

    val responsabilidad = spark.table(s"$schemaInterResponsabilidad.$inputInterResponsabilidad")

    val observExterno = modelizaVuelta(estadoExpediente,entrada,expedienteRobot,interprete,responsabilidad,date)

    //Insercción de la tabla de
    insertIntoTable(s"$schemaObservExterno.$outputObservExterno", observExterno._1, SaveMode.Overwrite)

    //TODO VER LA MANERA DE ACTUALIZAR LOS VALORES DE LA TABLA PARA ACTUALIZAR EL ESTADO
    insertIntoTable(s"$schemaEstadoExpediente.$inputEstadoExpediente",observExterno._2,SaveMode.Append)

  }

}

object CaminoVuelta {
  def CaminoVuelta(conf: SparkConf): CaminoVuelta = {
    val properties = conf.getAllWithPrefix(s"spark.redes.caminovuelta.")
    implicit val spark: SparkSession = createSparkSession(properties)
    new CaminoVuelta(properties.toMap)
  }
}
