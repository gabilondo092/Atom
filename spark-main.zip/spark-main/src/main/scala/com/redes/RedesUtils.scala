package com.redes

import org.apache.spark.sql.functions.{array_intersect, current_timestamp, date_format, lit, size}
import org.apache.spark.sql.{Column, DataFrame, SaveMode, SparkSession}
import org.joda.time.format.{DateTimeFormat, DateTimeFormatter}
import org.apache.hadoop.fs._



object RedesUtils{

  implicit class When[A](a: A) {
    def when(f: Boolean)(g: A => A)(h: A => A): A = if (f) g(a) else h(a)
  }

  def createSparkSession(confs: Array[(String, String)] = Array.empty): SparkSession = {
    val key = "spark_prop."
    val sparkConfs = confs.filter(_._1 startsWith key).map(prop => (prop._1.substring(key.length), prop._2))
    SparkSession.builder
      .config("hive.exec.dynamic.partition", value = true)
      .config("hive.exec.dynamic.partition.mode", "nonstrict")
      .config("hive.exec.max.dynamic.partitions", 2048)
      .when(!sparkConfs.isEmpty)(ssb => sparkConfs.foldLeft(ssb)((acm, prop) => acm.config(prop._1, prop._2)))(ssb => ssb)
      .enableHiveSupport
      .getOrCreate
  }

  def insertIntoTable(destination: String, df: DataFrame, mode: SaveMode,
                      partitions: Int, partCols: Option[Seq[Column]] = None): Unit =
    df
      .when(partCols.isEmpty)(_.repartition(partitions))(_.repartition(partitions, partCols.get:_*))
      .write
      .mode(mode)
      .insertInto(destination)

  def insertIntoTable(destination: String ,df: DataFrame, mode: SaveMode): Unit =
    insertIntoTable(destination, df, mode, 1)


  val fmt_yyyyMMdd: DateTimeFormatter = DateTimeFormat forPattern "yyyyMMdd"
  val fmt_yyyy_MM_dd: DateTimeFormatter = DateTimeFormat forPattern "yyyy-MM-dd"
  def yyyymmddDateToDashed(dateyyyymmdd: String): String = fmt_yyyy_MM_dd print(fmt_yyyyMMdd parseDateTime dateyyyymmdd)

  def dataTimestamp : Column = lit(date_format(current_timestamp(), "yyyyMMddHHmm")).cast("string")

  def dataTimestampseg : Column = lit(date_format(current_timestamp(), "yyyyMMddHHmmss")).cast("string")

  def renameFileSystem(src: Path, dest:Path)(implicit spark: SparkSession): Boolean ={

    val conf = spark.sparkContext.hadoopConfiguration
    val fs = src.getFileSystem(conf)
    val files = fs.globStatus(src)

    if (files.length==1){
      fs.rename(files(0).getPath, dest)
      true
    } else if (files.length>1){
      System.out.println("Warning: More than 1 file to rename")
      fs.rename(files(0).getPath, dest)
      true
    }else {
      System.out.println("Error: No file to rename")
      false
    }
  }

  def contieneCodigo(col1:Column,col2:Column):Column={
    size(array_intersect(col1,col2))=!= 0
  }

}
