#!/bin/bash
_script="$(readlink -f ${BASH_SOURCE[0]})"
_base="$(dirname $_script)"

date="00000000"
mode="CAMINOIDA"

if [ $# -eq 2 ]; then
    	mode="$1"
    	date="$2"
else
	echo "Error in args inserted ->  1 arg-> CAMINOIDA/CAMINOVUELTA , 2 arg-> date(yyyymmdd)"
	exit 1
fi


echo "Running application with this config"

cat << EOF
spark-submit \
	--class com.redes.Main \
    	--properties-file properties.conf \
    	--master yarn \
    	--deploy-mode cluster \
     	spark_PKDDataLake-0.1-SNAPSHOT.jar $mode $date
EOF

cat properties.conf

spark-submit \
	--class com.redes.Main \
    	--properties-file properties.conf \
    	--master yarn \
    	--deploy-mode cluster \
     	spark_PKDDataLake-0.1-SNAPSHOT.jar $mode $date



RESULT=$?
if [ ${RESULT} -ne 0 ]; then
    echo "Error en la llamada al script de spark: $RESULT"
    exit $RESULT
fi
echo "Finished ok !"
exit 0
