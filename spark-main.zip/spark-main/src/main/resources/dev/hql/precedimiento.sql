create table if not exists l0.procedimiento (codigo_procedimiento string, nombre_procedimiento string, convocatoria string) ROW FORMAT DELIMITED FIELDS TERMINATED BY ',' STORED AS TEXTFILE LOCATION '/home/hadoop/l0/procedimiento';

INSERT INTO TABLE l0.procedimiento VALUES ("1", "Procedimiento1","Conv1");
INSERT INTO TABLE l0.procedimiento VALUES ("2", "Procedimiento2","Conv2");
INSERT INTO TABLE l0.procedimiento VALUES ("3", "Procedimiento3","Conv3");

