create table if not exists l0.interprete (id_robot string, codigo_certificado string, fase string, responsabilidad string, campos_consulta string, aeat string, ss string) ROW FORMAT DELIMITED FIELDS TERMINATED BY ',' STORED AS TEXTFILE LOCATION '/home/hadoop/l0/interprete';

INSERT INTO TABLE l0.interprete VALUES ("8", "SVDIGAEINHABILITACIONWS01", "T","001", "","1", "0");
INSERT INTO TABLE l0.interprete VALUES ("5", "SVDCCAACPASWS01", "T", "001","codigo_comunidad_autonoma=16, codigo_provincia =00 (miramos en todas) ", "0", "0");