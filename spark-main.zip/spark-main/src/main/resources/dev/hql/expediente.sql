create table if not exists l0.expediente (id string, numero_documento string, num_expediente string, fase string, razon_social string, ccaa string, fecha_entrada string, check_aeat int, check_ss int, convocatoria string, tipo_documento string) ROW FORMAT DELIMITED FIELDS TERMINATED BY ',' STORED AS TEXTFILE LOCATION '/home/hadoop/l0/expediente';

INSERT INTO TABLE l0.expediente VALUES ('1','0000000L','1','T','PYME1','Madrid','2021-12-27 03:24:30.458',1,1, 'Conv1', 'NIF');
INSERT INTO TABLE l0.expediente VALUES ("2","0000001L","2","T","PYME2","Madrid","2021-12-27 04:24:30.458",null, 1, "Conv1", "NIF");
INSERT INTO TABLE l0.expediente VALUES ("3","0000002L","3","OTRO","PYME2","Madrid","2021-12-27 04:24:30.458",null, 1, "Conv1", "NIF");
INSERT INTO TABLE l0.expediente VALUES ("4","0000002L","4","T","PYME2","Madrid","2021-12-27 04:24:30.458",1, 1, "Conv1", "NIF");