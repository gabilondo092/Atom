create table if not exists l0.interprete_responsabilidad (responsabilidad string, area string, bucketPRE string, bucketPRO string) ROW FORMAT DELIMITED FIELDS TERMINATED BY ',' STORED AS TEXTFILE LOCATION '/home/hadoop/l0/interprete_responsabilidad';

INSERT INTO TABLE l0.interprete_responsabilidad VALUES ("001", "SGAD","", "");
INSERT INTO TABLE l0.interprete_responsabilidad VALUES ("002", "NTTDATA", "", "");