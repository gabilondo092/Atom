create table if not exists l0.observaciones_externo (area string, id_robot string, resultado string, causa string, fecha string, observaciones string, id string) ROW FORMAT DELIMITED FIELDS TERMINATED BY ',' STORED AS TEXTFILE LOCATION '/home/hadoop/l0/observaciones_externo';

