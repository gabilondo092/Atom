#!/bin/bash
# Global Environment variables.
export APP_NAME=${project.name}
