#!/bin/bash

nom_fich="SFSF_REC_JOB_REQUISITIO N_20190911T040225.csv.pgp"

nombre_tabla=`echo $nom_fich | grep -i "SFSF_.*\.csv.pgp" | tr -s " " | cut -d" " -f9 | sed 's/_[[:digit:]]\+T[[:digit:]]\+.csv.pgp//'| sed 's/^SFSF_//'| tr '[:lower:]' '[:upper:]'`

echo $nom_fich
echo $nombre_tabla

