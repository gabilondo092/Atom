#!/bin/bash

#. $HOME/SFSF/cfg/backupVariables.cfg


#Recibe un número negativo y obtiene la fecha apartir del parámetro, descontando los días a la fecha actual
getFecha() {
if [ $1 -lt 0 ];then
	
	
    fecha_ultimo_directorio=$(date +%Y%m%d --date=''$1' day')
#	echo $fecha_ultimo_directorio
		
fi
}

## Recibe un parámetro con la fecha en formato AAAAmmDD y devuelve el día de la semana al que pertenece
obtenDia() {
export dia_anterior=$(date +%A -d $1)
}

retrasaDias() {


		diasAtras=$((diasAtras - 1))
		getFecha $diasAtras
		obtenDia $fecha_ultimo_directorio
		if [ $dia_anterior = 'Saturday' ]
		then
			diasAtras=$((diasAtras - 1))
			echo "Ignorando el día anterior a la fecha: "$fecha_ultimo_directorio", Fue domingo"
		elif [ $dia_anterior = 'Sunday' ]
		then
			diasAtras=$((diasAtras - 2))
			echo "Ignorando el día anterior a la fecha: "$fecha_ultimo_directorio", Fue Sabado"
		
		fi			
		
			
			getFecha $diasAtras
			obtenDia $fecha_ultimo_directorio
        echo "Buscando "$diasAtras" días atras -> " $fecha_ultimo_directorio
	#	echo 'obtenemos el día anterior '$fecha_ultimo_directorio

}


function contiene() {
    local n=$#
    local value=${!n}
    for ((i=1;i < $#;i++)) {
        if [ "${!i}" == "${value}" ]; then
            echo "y"
            return 0
        fi
    }
    echo "n"
    return 1
}




function extraeNombreTabla_2() {
#echo "extrayendo nombre $1"
export nombre_tabla=$1
# Borra el directorio al que pertenece, en caso de que este informado
nombre_tabla="${nombre_tabla##*/}"
#echo "eliminando directorio"
# Borra la extension del fichero
nombre_tabla="${nombre_tabla%%.*}"
#echo "eliminando extension extension"
# Guarda la poscion del primero 2 que encuentre
posicionCaracter="${nombre_tabla%%2*}"
posicionCaracter=${#posicionCaracter}

#echo $nombre_tabla

# borra la parte numérica de la tabla (en caso de que el nombre del a tabla contenga un 2 esto funcionara mal)
nombre_tabla=${nombre_tabla:0:$(( posicionCaracter - 1 ))}

}

function extraeNombreTabla() {

export nombre_tabla=`echo $1 | grep -i "SFSF_.*\.csv.pgp" | tr -s " " | cut -d" " -f9 | sed 's/_[[:digit:]]\+T[[:digit:]]\+.csv.pgp//'| sed 's/^SFSF_//'| tr '[:lower:]' '[:upper:]'`
 
}






#####Main#######

FECHA_ACTUAL=$(date +%Y%m%d)
DIA=$(date +%A)
existeDirectorioAnterior=0
diasAtras=-1
rutaBck="/mnt/c/Users/gabil/Desktop/pruebas_back/PruebasScriptBCK/bck"  #/opt/software/onhr_master_sw/SFSF/pruebasGabi/PruebasScriptBCK/bck"
numeroDirectorios=$(ls /mnt/c/Users/gabil/Desktop/pruebas_back/PruebasScriptBCK/bck| wc -l)
echo "hay $numeroDirectorios directorios"
export fecha_ultimo_directorio=$(date +%Y%m%d --date=''$diasAtras' day')
busquedas=0
condicion=0

# modificar rutaBck por variable de entorno

#tablas_contingencia=('EP_ROCKET_PEOPLE_LANGUAGES' 'EP_ROCKET_PEOPLE_HARD' 'EP_BKG_COURSES' 'EC_PAY_COMPONENT_GROUP' 'REC_JOB_REQUISITION' 'EC_LOCATION' 'EC_JOB_CLASSIFICATION' 'EC_EWORK' 'REC_JOB_APPLICATION' 'REC_JOB_APPLICATION')  #('EC_COMPENSATION' 'EC_BKG_COURSES' 'EC_POSITION' 'EC_ALTERNATIVE_COST_DISTRIBUTION' 'EC_BKG_AWARDS' 'EC_BKG_AWARDS')

tablas_contigencia="${$1[@]}"

echo "SE PROCEDE A LA BUSQUEDA DE ${#tablas_contigencia[@]} LAS SIGUIENTES TABLAS: " ${tablas_contingencia[@]}

echo $numeroDirectorios
echo $DIA
echo $FECHA_ACTUAL
#echo $fecha_ultimo_directorio

# comprueba que exista el directorio de hoy 
if [ -d $rutaBck/$FECHA_ACTUAL ]; 
then
	
	
	
	
	# si es lunes obtendremos la fecha de hace 3 días
	if [ $DIA = 'Monday' ]
	then
		echo 'Hoy es lunes, se procede a buscar en el directorio del viernes pasado'
		
		diasAtras=-3
		#fecha_ultimo_directorio=$(date +%Y%m%d --date='-3 day')
	fi
	
    getFecha $diasAtras
	#fecha_ultimo_directorio=$(date +%Y%m%d --date=''$diasAtras' day')
	
	# comprueba que exista el directorio anterior
	
	while [ $condicion -ne 1 ];
	do
	
	if [ -d $rutaBck/$fecha_ultimo_directorio ]
	then
		echo "#####################################################################"
		echo "Buscando en el directorio "$fecha_ultimo_directorio 
		# buscamos las tablas que necesitamos	
			
			##############
			
			 #declare -a listaPrueba=('ep' 'rec' 'ey');
			
			ls $rutaBck/$fecha_ultimo_directorio | awk -F\. '{print $1}' > tablas.txt
			ls $rutaBck/$fecha_ultimo_directorio > nombre_tablas.txt
			
			
			echo "####### tablas en el directorio " $fecha_ultimo_directorio " ######## "
			cat tablas.txt
			echo "###############"
            
			
			indicesFicherosACopiar=()
		    indicesListaABorrar=()
			
			contadorLista=0
			
            for e in "${tablas_contingencia[@]}"
            do
           	contadorFicheros=0	         
            tabla_encontrada=0
			## si el directorio al que accedemos estubera vacio por cualquier motivo, no va a listar
			if [ $(cat tablas.txt | wc -l) -ne 0 ]
			then
			
			## sustitur bucle, por copiar la tabla directamente del directorio , en caso de que exista(si es viable)
		#		for t in $(cat tablas.txt)
		       for fil in $(cat nombre_tablas.txt)
				do
				echo "#######fichero numero: $contadorFicheros #######"
				
				echo "Nombre fichero -> $fil"
				#nombreFichero=$(sed -n $(( contadorFicheros + 1 ))p  nombre_tablas.txt)
				
				# comprobar si el array contiene los elementos
                    if [ $(contiene "${indicesFicherosACopiar[@]}" $contadorFicheros) == "n" ]; 
                    then   
						echo "Extrayendo el nombre de la tabla al fichero $fil"
						extraeNombreTabla $fil		
						
						echo "Comparando elemento de lista: $e y fichero $nombre_tabla"
						
						if [ $nombre_tabla = $e ]
						then
                            
					       	   				
							   echo "Se ha encontrado la tabla: "$e" en el directorio "$fecha_ultimo_directorio
							   #unset tablas_contingencia[$contadorLista]
							   # elimina la tabla de la lista
                               tablas_contingencia=(${tablas_contingencia[@]:0:$contadorLista} ${tablas_contingencia[@]:$(($contadorLista + 1))})							
                               tabla_encontrada=1
							
							echo "copiar fichero "$nombreFichero
							cp $rutaBck/$fecha_ultimo_directorio/$fil $rutaBck/$FECHA_ACTUAL
							if [ $? -eq 1 ]
							then
							echo "la tabla $nombreFichero no se ha podido copiar"
							fi
                            indicesFicherosACopiar=("{indicesFicherosACopiar[@]}" $contadorFicheros)
							#indicesListaABorrar=("indicesListaABorrar[@]") 
							
							break		
							  
			
					    fi
						
					 else 		
            	        echo "El fichero $nombreFichero ya se ha copiado ... se pasa al siguietne fichero"
		         	 fi   
					 						
            		contadorFicheros=$(( contadorFicheros + 1 ))
               	done				
				
				
				
				# si no ha encontrado la tabla aumenta el contador
				if [ $tabla_encontrada -eq 0 ]
				then				
            	contadorLista=$((contadorLista + 1))
				fi
			fi	
            done
			retrasaDias
			
          echo "las siguientes tablas no se han encontrado en el directorio "$fecha_ultimo_directorio ": " ${tablas_contingencia[@]}
			
			###############
            
		
		
		#si no estan seguimos buscando y girando el bucle
		
	else
	    
		# en caso de que el direcorio del supuesto día anterior no exista
		# restamos otro dia, a no ser que sea sabado o domingo(nunca sera sabado) que obtendría el del viernes
		echo 'no existe el directorio '$fecha_ultimo_directorio
		retrasaDias		
	
	
	fi
	
	## comprueba que no busque mas de lo necesario
	## si supera el límite de busquedas, sale del bucle sin obtener resultados positivos
	## si no incrementa el contador de busquedas
	numTablas=${#tablas_contingencia[@]}
	echo "quedan " $numTablas " tablas"
	if [ $busquedas -gt $numeroDirectorios ]
	then
		echo "Se han realizado $busquedas busquedas"
		condicion=1
	echo "Se han buscado en todos los directorios y no se han encontrado las tablas: "${tablas_contingencia[@]}
	elif [ $numTablas -eq 0 ]
	then
	echo "Se han encontrado todas las tablas"
	condicion=1
	
	
	fi
	busquedas=$((busquedas+1))	
	
	done
	
	
	
else
	echo 'El directorio de hoy no existe'
	pwd
fi





