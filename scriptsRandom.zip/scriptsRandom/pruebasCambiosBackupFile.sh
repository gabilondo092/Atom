#!/bin/bash
function contiene() {
    local n=$#
    local value=${!n}
    for ((i=1;i < $#;i++)) {
        if [ "${!i}" == "${value}" ]; then
            echo "y"
            return 0
        fi
    }
    echo "n"
    return 1
}

function ComprobacionTablasDiarias
{    
    tablas_por_subir_string=""
	export tablas_por_subir=()
	for tabla_planificada in `cat /mnt/c/Users/gabil/Desktop/pruebas_back/PruebasScriptBCK/tablas_planificadas.cfg` #`cat /home/onhr_master/SFSF/cfg/tablas_planificadas.cfg `
    do
	    partes=1
        tabla_descargada=false
		contador=0
			echo $tabla_planificada || grep ','
		if [[ $tabla_planificada == *,* ]] # [ `echo $tabla_planificada || grep ','` ] 
		then
			partes="$(cut -d',' -f2 <<<$tabla_planificada)"
			tabla_planificada="$(cut -d',' -f1 <<<$tabla_planificada)"
			echo "La tabla $tabla_planificada esta dividida en $partes partes";			
		fi
		
		
		echo "Tabla planificada $tabla_planificada"
       
	   for tabla in `ls -l /mnt/c/Users/gabil/Desktop/pruebas_back/PruebasScriptBCK/SFTP_PRE | grep -i "SFSF_.*\.csv.pgp" | tr -s " " | cut -d" " -f9 | sed 's/_[[:digit:]]\+T[[:digit:]]\+.csv.pgp//'| sed 's/^SFSF_//'| tr '[:lower:]' '[:upper:]'`
        do   
		echo "	  Tabla dentro del sftp $tabla"
            if [ $tabla_planificada = $tabla ]
            then
			      
				if [ $partes -eq 1 ]
				then
				     echo "tabla $tabla encontrada"
					 tabla_descargada=true
					 break
				else
					contador=$(( contador + 1 )) 
					if [ $contador -eq $partes ]
					then	
						echo "se han encontrado las $partes partes de la tabla $tabla"
						tabla_descargada=true
						break				    
						
					fi
				fi	
            fi
        done
        if [ $tabla_descargada = false ]
        then
            if [ $partes -eq 1 ]
			then	
				echo "Hay que resubir la tabla $tabla_planificada"
				tablas_por_subir=("${tablas_por_subir[@]}" "$tabla_planificada")
				tablas_por_subir_string="$tablas_por_subir_string $tabla_planificada"
			else
			    
				partesPorSubir=$(( partes - contador ))
				string="$partesPorSubir partes"
				if [ $partesPorSubir -eq 1 ]
				then
					string="1 parte"	
					tablas_por_subir=("${tablas_por_subir[@]}" "$tabla_planificada")
					tablas_por_subir_string="$tablas_por_subir_string" "$tabla_planificada"
				
				else
					echo "Hay que resubir $string de la tabla $tabla_planificada"
					# añade el nombre de la tabla en el array tantas veces como partes faltan por subir
					for i in `seq 1 $partesPorSubir`;
					do
						tablas_por_subir=("${tablas_por_subir[@]} $tabla_planificada")
						tablas_por_subir_string="$tablas_por_subir_string $tabla_planificada"
					done  
				fi		
								
			fi	
			
			
			
        fi
        
    done
	
	echo "${tablas_por_subir[@]}"
	echo "${#tablas_por_subir[@]}"
	if [ "${#tablas_por_subir[@]}" -ne 0 ]
	then
	echo "Se procede a la busqueda de las tablas de contingencia"
	echo $
	./backUp.sh "${tablas_por_subir[@]}" #$tablas_por_subir_string 
	else
	echo "Se han encontrado todas las tablas"
	fi
	
	
	
	
}

### MAIN #	

ComprobacionTablasDiarias