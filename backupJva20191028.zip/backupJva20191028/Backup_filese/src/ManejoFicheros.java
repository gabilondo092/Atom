import java.util.Calendar;
import java.util.GregorianCalendar;

public class ManejoFicheros {
	
	ArrayList<String> listaTablasPlanificadas
	
	public static void main(String args[]) {
		
		
	}
	
	public static void leeFicheros(String ruta){
		
		
		
		
	}
	

}
