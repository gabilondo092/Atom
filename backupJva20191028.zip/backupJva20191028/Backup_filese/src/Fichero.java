
public class Fichero {

	 String nombre;
	 int partes;
	 int partesQueFaltan;
	
	public Fichero(String nombre, int partes) {
		
		this.nombre=nombre;
		this.partes=partes;
		partesQueFaltan=partes;
		
				
	}
	
	
}
