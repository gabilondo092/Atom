import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Calendar;

public class Main {
	static String rutaListFija = "C:\\Users\\gabil\\Desktop\\automatizador_bck\\cfg\\tablas.txt";
	static ArrayList<Fichero> tablasPlanificadas = new ArrayList<Fichero>(); 	
	static ArrayList<String> tablasPorSubirDeUnaParte = new ArrayList<String>();
	static ArrayList<String> tablasPorSubirDeMasDeUnaParte = new ArrayList<String>();
	public static void main(String[] args) {
		
		String rutaSftp ="C:\\Users\\gabil\\Desktop\\automatizador_bck\\SFTP\\onhr\\";
		String rutaBck="C:\\Users\\gabil\\Desktop\\automatizador_bck\\bck";
		
		File directorioSftp = new File(rutaSftp);
		int cuentaDiasAtras=0;
		
		
		
		iniciaListaTablasPlanificadas();
		
		
		
		System.out.println(directorioSftp.isDirectory());
		
	          if(directorioSftp.isDirectory()) {
	        	  

	       		// lista los ficheros del sftp;
	        	  File listaSftp [] = directorioSftp.listFiles();
	        	  System.out.println("lista de tablas que han llegado al SFTP");
	        	  int cuentaFicheros = 1;
	        	  for(File f : listaSftp) {
	        		  String nombreOriginalFichero=f.getName();
	        		  
	        		  System.out.println(cuentaFicheros+" - "+nombreOriginalFichero);
        		  
	        		
    	        		  
    		  // COMPRUEBA QUE EL TIPO DE FICHERO SEA CSV.PGP
	        		  
	        		  if(validaExtension(nombreOriginalFichero)) {
	        			  
        			  
	        			  
	        			  // vomprobar tras realizar todas las validaciones
	        			  // si por muchisima casualidad alg�n fichero ha llegado vac�o (
	        			  if(f.length()==0) {
	        				  
	        				  System.out.println("Warn: El fichero "+nombreOriginalFichero+" esta vac�o");
        				   
	        				  // �borrar del sftp y buscar del dia anterior?			  
	        			  }
	        			  
	        			  
	        			 
	        			 String nombreTabla = validaFecha(nombreOriginalFichero);
	        			  
	        			  // una vez hechas las validaciones sobre los ficheros del sftp, se realiza la comparaci�n con las tablas planificadas
	        			  
	        			  
        				  /**
        				   *  Conforme se comprueba la existencia de las tablas planificadas en el sftp,
        				   *  se van restando las partesQueFaltan a los ficheros de la lista
        				   */
	        			  for(Fichero tablaPlanificada : tablasPlanificadas) {
	        				  
	        				
	        				  // si ya sabemos que han llegado todas las partes de ese fichero, se ignora
	        			//	  if(tablaPlanificada.partesQueFaltan>0) {
	        					  
	        					  // compara el nombre de las tablas
	        					  if(tablaPlanificada.nombre.toUpperCase().equals(nombreTabla.toUpperCase())) {
	        						  
	        						  // decrementa las parte que faltan, una vez llegue a cero, ignorara esta tabla
	        						  tablaPlanificada.partesQueFaltan--;
	        						  
	        					  
	        				//	  }
	        					  
	        					  }
	        					  
	        				  
	        				  
	        				  }	        				  	 	        			  		  
	        		  }
	        		cuentaFicheros++;  
	        	  }
	        	  
	        	  
	          }else {
	        	  
	        	  System.out.println("La ruta del SFTP no es un diretorio");
	        	  
	          }
	
		
		
	
	          resumenTablasPorLlegar();
	          
	        //  tablasPorSubirDeMasDeUnaParte
		
	}
	
	        public static boolean validaExtension(String nombreFichero) {
	        	
	        	String extension = extraeExtension(nombreFichero);
	        	System.out.println(extension);
	        	
	        
	        	if(extension.equals(".csv.pgp")) {
	        		System.out.println("Extensi�n v�lida");
	        		return true;
	        	}
	        	else {
	        		System.out.println("La extensi�n "+extension+" no es v�lida");
	        	}
	        
	        return false;
	        	
	        
	        }
           
	        /**
	         * Extrae la fecha del nombre, y valida la fecha mediante un mensaje en caso de que de error
	         */
	        public static String validaFecha(String nombreFichero) {
	        	
	        	
	        		String nombreTabla= extraeNombre(nombreFichero);
	        		
	        		if(nombreTabla.length()>0) {
            		String fecha=nombreFichero.substring(nombreTabla.length()+1);
            		
	        		System.out.println(nombreTabla);
	        		System.out.println(fecha);
	        		
	        		}else {
	        			
		        		System.out.println("Warn: La tabla "+nombreFichero+" tiene la fecha incorrecta");
	        		}
	        		        		
	        		return nombreTabla;
	        	
	        	
	        }
	        
	        
	        public static String extraeNombre(String nombreFichero) {
	        	
	        	String nombreTabla ="";
	        	int indiceFecha = nombreFichero.indexOf("_2");
	        	

		        	if(indiceFecha>=0) {
		        	
		        	    nombreTabla= nombreFichero.substring(0,indiceFecha);
		        	}
	        	return nombreTabla;
	        	
	        }
	        
	        
	        public static void extraeFechaYNombre(String nombreFichero) {

	        	int indiceFecha = nombreFichero.indexOf("_2");
	        	
	        	
	        }
	        
	        

	        public static String getFecha() {
	        	
	        	Calendar fecha =Calendar.getInstance(); //obtiene la fecha de hoy
	        	fecha.add(Calendar.MONTH, +3); //el -3 indica que se le restaran 3 dias
	            
	            int anio = fecha.get(Calendar.YEAR);
	            int mes = fecha.get(Calendar.MONTH);
	            int dia = fecha.get(Calendar.DAY_OF_MONTH);
	            int hora = fecha.get(Calendar.HOUR_OF_DAY);
	            int minuto = fecha.get(Calendar.MINUTE);
	            int segundo = fecha.get(Calendar.SECOND);
       	            
	        	return anio+mes+dia+"";
	        	
	        }
	        
	        public static String extraeExtension(String nombre) {
	        	
	        	String extension ="";
	        	int indiceExtension=nombre.indexOf(".");
	        	if(indiceExtension>=0) {
	        		
	        		extension = nombre.substring(indiceExtension);
	        	}
	        	return extension;
	        }
	        
	        
	        // lee el fichero de tablas diarias
	        public static void iniciaListaTablasPlanificadas() {
	        	
	        	System.out.println("Inicializando lista tablas planificadas...");
	        	File archivo = new File (rutaListFija);
	        	FileReader fr;
				try {
					
					fr = new FileReader (archivo);
					BufferedReader br = new BufferedReader(fr);
					try {
						
						String linea = br.readLine();
						int cuenta=0;
						 while((linea=br.readLine())!=null) {
					            System.out.println(linea);	       
					            String partes [] = splitLinea(linea);
					            // valida las l�neas de la lista fija
					           
					            // una parte es el nombre y la otra es n�mero de partes de ese fichero
					            if(partes.length==2) {
					            	
					            	
					            	// valida que la 2� parte sea un n�mero entero
					            	if(isNumeric(partes[1])) {
					            		
					            		
					            		int partesFichero=Integer.parseInt(partes[1]);
					            		
					            		// una vez hechas las validaciones , se crea el objeto Fichero y se almacena
					            		// en la lista de tablas planificadas
					            		
					            		tablasPlanificadas.add(new Fichero(partes[0],partesFichero));
					            		
					            		
					            	}
					            	else {
					            		System.out.println("Warn: hay un error en la definici�n de las partes de la tabla "+partes[0]+" el el fichero: "+rutaListFija);
					            	}
					            	
					            	
					            }else {
					            	System.out.println("Warn: hay errores el el fichero: "+rutaListFija+" "+partes[0]+" "+cuenta);
					            	
					            }
					            cuenta++; 
					      }
						
						
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				} catch (FileNotFoundException e) {
					
					e.printStackTrace();
				}
	        		        	   	        		        	
	        }
	        
	        // devuelve las partes separadas por ;
	        // lo valida el m�todo que inicializa la lista
	        public static String [] splitLinea (String linea){
	        	
	        	String partes []= new String[1];
	        	if(linea.contains(";")) {
	        		
	        		partes = linea.split(";");	        		
	        		
	        	}
	        	return partes;
	        	
	        }
	        
	        /**
	         * 
	         * @param String cadena
	         * @return true si la cadena es un num�rico, false si contiene cualquier caracter no num�rico
	         */
	        public static boolean isNumeric(String cadena){
	        	try {
	        		Integer.parseInt(cadena);
	        		return true;
	        	} catch (NumberFormatException nfe){
	        		return false;
	        	}
	        }
	        
	        
	        // en validaciones
	        public static void resumenTablasPorLlegar() {
	        	
	        	for(Fichero tablaPlanificada : tablasPlanificadas) {
	        		
	        		if(tablaPlanificada.partesQueFaltan==0){
	        			System.out.println(tablaPlanificada.nombre+" -> Han llegado todas sus partes");
	        		}
	        		else {
	        			if(tablaPlanificada.partesQueFaltan<0) {
	        				
	        				System.out.println(tablaPlanificada.nombre+" -> Ha llegado "+(tablaPlanificada.partesQueFaltan*-1)+" tablas mas de las esperadas");
	        			}
	        			else {
		        			if(tablaPlanificada.partesQueFaltan>0) {
		        				
		        				System.out.println(tablaPlanificada.nombre+" -> faltan "+tablaPlanificada.partesQueFaltan+" parte");
		        				
		        				// seg�n el n�mero de partes de las que se compone la tabla a buscar la meteremos en una lista u otra
		        				
		        				if(tablaPlanificada.partes==1) {
		        					
		        					tablasPorSubirDeUnaParte.add(tablaPlanificada.nombre);
		        					
		        				}else {
		        					if(tablaPlanificada.partes>1) {
		        						tablasPorSubirDeMasDeUnaParte.add(tablaPlanificada.nombre);
		        					}
		        				}		        			
		        				
		        			}
		        		}
	        		}
	        		
	        		
	        		
	        	}
	        	
	        	
	        }
	        
	        
	        
	        public static void RecuperaTablaDeMasDeUnaParte() {
	        	
	        	// si hay tablas de mas de una parte
	        	if(tablasPorSubirDeMasDeUnaParte.size()>0) {
	        		
	        		// crea carpeta delete
	        
	        		
	        		// borrar esas tablas del sftp
	        		
	        		
	        		
	        	}
	        	
	        }
}
