package resuelve.sudokus;

import java.util.ArrayList;

/**
 * clase que implementa una matriz
 * @author Gabi
 */
public class Matriz {

    private Casilla casillas[];
// listas que guardan valores de la regla eliminaCandidatosEnUnaSolaFila
// se utiliza para no volver a usar la misma regla con el mismo valor  y asi evitar que haga operaciones inecesarias
    private ArrayList<Integer> buscadosEnFilas;
    private ArrayList<Integer> buscadosEnColumnas;

// CONTRUCTOR COPIA
    public Matriz(Matriz copia) {
        copiaCasillas(copia.getCasillas());
        buscadosEnFilas = new ArrayList<Integer>();
        buscadosEnColumnas = new ArrayList<Integer>();
        copiaBuscadosEnFilas(buscadosEnFilas);
        copiaBuscadosEnColumnas(buscadosEnColumnas);
    }

// CONTRUCTOR A PARTIR DE UN ARRAY DE CASILLAS
    public Matriz(Casilla[] c) {
        casillas = c;
        buscadosEnFilas = new ArrayList<Integer>();
        buscadosEnColumnas = new ArrayList<Integer>();
    }

// DEVUELV LA COPIA DEL LA LISTA PASADA COMO PARÁMETRO
    public ArrayList<Integer> copiaArray(ArrayList<Integer> ar) {
        ArrayList<Integer> copia = new ArrayList<Integer>();

        for (int i : ar) {
          
            copia.add(ar.get(i));
        }
        return copia;

    }
// DEVUELVE LA LISTA DE VALORES POSITIVOS PARA LA REGLA CANDIDATOS SOLOS EN LINEA

    public ArrayList<Integer> getBuscadosEnColumnas() {
        return buscadosEnColumnas;
    }
// CAMBIA LA LISTA DE VALORES POSITIVOS PARA LA REGLA CANDIDATOS SOLOS EN LINEA

    public void setBuscadosEnColumnas(ArrayList<Integer> buscadosEnColumnas) {
        this.buscadosEnColumnas = buscadosEnColumnas;
    }

// DEVUELVE LA LISTA DE VALORES POSITIVOS PARA LA REGLA CANDIDATOS SOLOS EN LINEA
    public ArrayList<Integer> getBuscadosEnFilas() {
        return buscadosEnFilas;
    }
// CAMBIA LA LISTA DE VALORES POSITIVOS PARA LA REGLA CANDIDATOS SOLOS EN LINEA

    public void setBuscadosEnFilas(ArrayList<Integer> buscadosEnFilas) {
        this.buscadosEnFilas = buscadosEnFilas;
    }
// DEVUELVE LAS CASILLAS DE LA MATRIZ

    public Casilla[] getCasillas() {
        return casillas;
    }

// CAMBIA LAS CASILLAS DE LA MATRIZ
    public void setCasillas(Casilla[] casillas) {
        this.casillas = casillas;
    }

// IMPRIME LA MATRIZ
    public void imprimeMatriz() {
        for (int i = 0; i < casillas.length; i++) {
            System.out.println(casillas[i].getValor());
        }
    }

// DIVIDE LA MATRIZ EN FILAS
    public Casilla[][] divideEnFilas() {
        int cont = 0;
        Casilla[][] filas = new Casilla[3][3];
        for (int i = 0; i < casillas.length; i++) {
            if (i < 3) {
                filas[0][cont] = casillas[i];
            }
            if (i > 2 && i <= 5) {
                filas[1][cont] = casillas[i];
            }
            if (i >= 5) {
                filas[2][cont] = casillas[i];
            }

            cont++;
            if (cont == 3) {
                cont = 0;
            }
        }
        return filas;
    }

// DIVIDE LA MATRIZ EN COLUMNAS
    public Casilla[][] divideEnColumnas() {
        int cont = 0;
        Casilla[][] filas = new Casilla[3][3];
        for (int i = 0; i < casillas.length; i++) {
            if (i < 3) {
                filas[cont][0] = casillas[i];
            }
            if (i > 2 && i <= 5) {
                filas[cont][1] = casillas[i];
            }
            if (i >= 5) {
                filas[cont][2] = casillas[i];
            }

            cont++;
            if (cont == 3) {
                cont = 0;
            }
        }
        return filas;
    }

// DEVUELVE TRUE SI EL VALOR PASADO COMO PARÁMETRO HA SALIDO
    public boolean haSalido(int v) {
        for (int i = 0; i < casillas.length; i++) {
            if (v == casillas[i].getValor()) {
                return true;
            }
        }
        return false;
    }

    public boolean estaBuscadosEnColumna(int v) {
        for (int i = 0; i < buscadosEnFilas.size(); i++) {
            if (buscadosEnColumnas.get(i) == v) {
                return true;
            }

        }
        return false;
    }

    public boolean estaEnBuscadosEnFila(int v) {
        for (int i = 0; i < buscadosEnFilas.size(); i++) {
            if (buscadosEnFilas.get(i) == v) {
                return true;
            }

        }

        buscadosEnFilas.add(v);
        return false;
    }

    // COPIA LA LISTA PASADA COMO PARAMETRO
    public void copiaBuscadosEnFilas(ArrayList<Integer> pCopiaBuscadosEnFilas) {
        for (int i = 0; i < pCopiaBuscadosEnFilas.size(); i++) {
            buscadosEnFilas.add(pCopiaBuscadosEnFilas.get(i));
        }
    }

    // COPIA LA LISTA PASADA COMO PARAMETRO
    public void copiaBuscadosEnColumnas(ArrayList<Integer> pCopiaBuscadosEnColumnas) {
        for (int i = 0; i < pCopiaBuscadosEnColumnas.size(); i++) {
            buscadosEnColumnas.add(pCopiaBuscadosEnColumnas.get(i));
        }
    }

    // DEVUELVE UN ARRAY DE ENTEROS CON LAS CASILLAS CON MENOS CANDIDATOS
    public int[] buscaCasillasConMenosCandidatos() {
        int numCandidatos = 9;
        int casilla = 0;
        for (int i = 0; i < casillas.length; i++) {
            int numCandidatosAux = 0;
            if (casillas[i].getValor() == 0) {
                int candidatos[] = casillas[i].getCandidatos();
                for (int y = 0; y < casillas[i].getCandidatos().length; y++) {
                    if (candidatos[y] > 0) {
                        numCandidatosAux++;
                    }
                }

                if (numCandidatosAux < numCandidatos) {

                    numCandidatos = numCandidatosAux;
                    casilla = i;
                }
            }
        }
        
        return new int[]{casilla, numCandidatos};
    }

    // copia el array casillas
    public void copiaCasillas(Casilla[] copia) {
        casillas = new Casilla[copia.length];
        for (int i = 0; i < copia.length; i++) {
            casillas[i] = new Casilla(copia[i]);
        }
    }

    // DEVUELVE LA CUENTA DE CASILLAS COMPLETAS
    public int casillasCompletas() {
        int cuenta = 0;
        for (Casilla c : casillas) {
            if (c.getValor() > 0) {
                cuenta++;
            }
        }
        return cuenta;
    }

    // devuelve el numero de candidatos que tiene la casilla con menos candidato
    public int cuentaMinimaDeCandidatos() {
        int cuenta = 9;
        for (int i = 0; i < casillas.length; i++) {
            if (casillas[i].getValor() == 0) {
                ArrayList<Integer> lista = casillas[i].getCandidatosUnicamente();

                for (int c : lista) {

                }
                if (lista.size() < cuenta) {
                    cuenta = lista.size();

                }
            }
        }

        return cuenta;
    }

    // DEVUELVE UNA LISTA DE VALORES QUE HAN SALIDO EN LA MATRIZ
    public ArrayList<Integer> getValoresSalidos() {

        ArrayList<Integer> salidos = new ArrayList<Integer>();
        for (int i = 0; i < casillas.length; i++) {
            if (casillas[i].getValor() > 0) {
                salidos.add(casillas[i].getValor());
            }
        }
        return salidos;
    }

    // DEVUELVE TRUE SI TODOS LOS CANDIDATOS SON CERO
    public boolean deformacionDeCandidatos() {

        for (int i = 0; i < casillas.length; i++) {
            if (casillas[i].deformacionDeCandidatos()) {
                return true;
            }
        }
        return false;
    }

    // IMPRIME LA MATRIZ
    public void imprime() {
        for (int i = 0; i < casillas.length; i++) {
            System.out.println("Casilla " + i + "\n\n");
            casillas[i].imprime();
            System.out.println("\n");
        }
        System.out.println("\n\n");
    }

}
