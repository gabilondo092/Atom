package resuelve.sudokus;

import java.util.ArrayList;

/**
 * Clase que impmenta una casilla del sudoku
 * @author Gabi
 */
public class Casilla {

    // si valor = 0, significa que es desconocido 
    private int valor;
    private int posicion;
    private int[] candidatos;
    public boolean probadaBackTracking = false;

    public Casilla(int v, int p) {
        valor = v;
        posicion = p;
        inicioCandidatos();

    }

    public Casilla(int v) {
        valor = v;
        posicion = 0;
        inicioCandidatos();

    }

    // constructor copia
    public Casilla(Casilla copia) {
        valor = copia.getValor();
        posicion = copia.getPosicion();
        // copia los candidatos en el array candidatos
        copiaCandidatos(copia.getCandidatos());
        probadaBackTracking = copia.probadaBackTracking;

    }

    public Casilla() {
        valor = 0;
        posicion = 0;
        inicioCandidatos();
    }

    public int getValor() {
        return valor;
    }

    // cambia el valor de la casilla por el del parámetro introducido
    // y elimina el resto de candidatos
    public void setValor(int valor) {
        if (valor > 0) {
            this.valor = valor;
            eliminaTodosCandidatos(valor);
       

        }
    }

    // cambia el valor de la casilla por el del parámetro
    public void setValor2(int valor) {
        if (valor > 0) {
            this.valor = valor;
        }
    }
    
    public void setValor3(int valor){
        this.valor = valor;
    }

    // copia los candidatos de otra casilla
    public void copiaCandidatos(int[] cand) {
        candidatos = new int[cand.length];
        for (int i = 0; i < cand.length; i++) {
            candidatos[i] = cand[i];
        }

    }
 // cambia el valor del array candidatos a cero menos el del parámetro
    public void eliminaTodosCandidatos(int valor) {
        for (int i = 0; i < candidatos.length; i++) {
            if (candidatos[i] != valor) {
                candidatos[i] = 0;
            }
        }
    }

    // elimina el candidato pasado por parámetro de la casilla
    public void eliminaCandidato(int valor) {
        if (valor > 0) {
            candidatos[valor - 1] = 0;
        }
    }

    // devuelve el único candidato que queda disponible de la casilla
    // si hay mas de un candidato devuelve -1
    public int soloHayUnCandidato() {
        int ceros = 0;
        int candidato = -1;
        for (int i = 0; i < candidatos.length; i++) {
            if (candidatos[i] == 0) {
                ceros++;
            } else {
                candidato = candidatos[i];
            }
        }
        if (ceros == 8) {
            return candidato;
        }
        return -1;
    }

    // comprueba si solo hay un candidato y si es así cambia el valor por el del candidato
    public void asignarUnicoCandidato() {
        if (soloHayUnCandidato() != -1) {
            setValor2(soloHayUnCandidato());
        }
    }

    // devuelve la posicion
    public int getPosicion() {
        return posicion;
    }

    // cambia la posicion
    public void setPosicion(int posicion) {
        if (posicion > 0) {
            this.posicion = posicion;
        }
    }

    // devuelve los candidatos
    public int[] getCandidatos() {
        return candidatos;
    }

    // inicia el array de candidatos asignandoles el valor de su siguiente posicion en el array
    private void inicioCandidatos() {
        candidatos = new int[9];

        if (valor == 0) {
            for (int i = 0; i < 9; i++) {
                candidatos[i] = i + 1;
            }
        } else {
            candidatos[valor - 1] = valor;
        }

    }

    public void imprimePosiblesValores() {
        for (int p : candidatos) {
            System.out.println(p);
        }
    }
    // devuelfve el numero de candidato mayor que cero en la casilla
    public int numeroCandidatos() {
        int num = 0;
        for (int i = 0; i < candidatos.length; i++) {
            if (candidatos[i] > 0) {
                num++;
            }
        }
        return num;
    }

    // devuelve una lista con los candidatos de la casilla
    public ArrayList<Integer> getCandidatosUnicamente() {
        ArrayList<Integer> cand = new ArrayList<Integer>();
        for (int c : candidatos) {
            if (c > 0) {
                cand.add(c);
            }
        }
        return cand;
    }
  // imprime los atributos de la clase
    public void imprime() {
        System.out.println("Nombre casilla: " + this);
        System.out.println("Casilla en posición: " + posicion + "\nValor: " + valor + "\nCandidatos:");
        System.out.println("Nombre array candidatos " + candidatos);
        for (int i = 0; i < candidatos.length; i++) {
            System.out.print("|" + candidatos[i] + "|");
        }
        System.out.println();
    }

    // comprueba si todos los candidatos son 0 o valores repetidos
    public boolean deformacionDeCandidatos() {
        int cuentaCeros = 0;
        for (int i = 0; i < candidatos.length; i++) {
            if (candidatos[i] == 0) {
                cuentaCeros++;
            }
        }
        if (cuentaCeros == 9) {
            return true;
        }
        return false;

    }
    // si la casilla tiene el candidato pasado como parametro = true

    public boolean estaElCandidato(int candidato) {
        for (int c : candidatos) {
            if (c > 0) {
                if (c == candidato) {
                    return true;
                }
            }
        }
        return false;

    }

}
