package resuelve.sudokus;

import java.util.ArrayList;

/**
 * clas que implementa un sudoku
 * @author Gabi
 */
public class Sudoku {

    private Matriz matrizes[];
    private Casilla fila[][];
    private Casilla columnas[][];
    private Metodos metodos;

    // CONTRUCTOR QUE RECIME UN ARRAY DE MATRICES
    public Sudoku(Matriz[] m) {
        matrizes = m;

        fila = new Casilla[9][9];
        columnas = new Casilla[9][9];
        creaFilas();
        metodos = new Metodos();

    }

    // CONSTRUCTOR QUE RECIBE UN ARRAY DE DOS DIMENSIONES DE VALORES
    public Sudoku(int[][] valores) {
        matrizes = new Matriz[9];
        Casilla cas[][] = new Casilla[9][9];
        for (int i = 0; i < valores.length; i++) {
            //  cas[i] = new Casilla[9];
            for (int j = 0; j < valores[i].length; j++) {
                cas[i][j] = new Casilla(valores[i][j], j);

            }
            this.matrizes[i] = new Matriz(cas[i]);

        }

        fila = new Casilla[9][9];
        columnas = new Casilla[9][9];
        creaFilas();
        metodos = new Metodos();

    }

    // CONSTRUCTOR COPIA
    public Sudoku(Sudoku sudoku) {
        matrizes = new Matriz[sudoku.getMatrizes().length];
        copiaMatrizes(sudoku.getMatrizes());

        fila = new Casilla[9][9];
        columnas = new Casilla[9][9];
        creaFilas();
        metodos = new Metodos();
    }

    // COPIA UN ARRAY DE MATRICES
    public void copiaMatrizes(Matriz m[]) {

        for (int i = 0; i < m.length; i++) {
            matrizes[i] = new Matriz(m[i]);
        }

    }

    /**
     * INICIALIZA EL ARRAY FILAS A PARTIR DE LAS MATRICES
     */
    public void creaFilas() {

        fila[0][0] = matrizes[0].getCasillas()[0];
        fila[0][1] = matrizes[0].getCasillas()[1];
        fila[0][2] = matrizes[0].getCasillas()[2];
        fila[0][3] = matrizes[1].getCasillas()[0];
        fila[0][4] = matrizes[1].getCasillas()[1];
        fila[0][5] = matrizes[1].getCasillas()[2];
        fila[0][6] = matrizes[2].getCasillas()[0];
        fila[0][7] = matrizes[2].getCasillas()[1];
        fila[0][8] = matrizes[2].getCasillas()[2];

        fila[1][0] = matrizes[0].getCasillas()[3];
        fila[1][1] = matrizes[0].getCasillas()[4];
        fila[1][2] = matrizes[0].getCasillas()[5];
        fila[1][3] = matrizes[1].getCasillas()[3];
        fila[1][4] = matrizes[1].getCasillas()[4];
        fila[1][5] = matrizes[1].getCasillas()[5];
        fila[1][6] = matrizes[2].getCasillas()[3];
        fila[1][7] = matrizes[2].getCasillas()[4];
        fila[1][8] = matrizes[2].getCasillas()[5];

        fila[2][0] = matrizes[0].getCasillas()[6];
        fila[2][1] = matrizes[0].getCasillas()[7];
        fila[2][2] = matrizes[0].getCasillas()[8];
        fila[2][3] = matrizes[1].getCasillas()[6];
        fila[2][4] = matrizes[1].getCasillas()[7];
        fila[2][5] = matrizes[1].getCasillas()[8];
        fila[2][6] = matrizes[2].getCasillas()[6];
        fila[2][7] = matrizes[2].getCasillas()[7];
        fila[2][8] = matrizes[2].getCasillas()[8];

        fila[3][0] = matrizes[3].getCasillas()[0];
        fila[3][1] = matrizes[3].getCasillas()[1];
        fila[3][2] = matrizes[3].getCasillas()[2];
        fila[3][3] = matrizes[4].getCasillas()[0];
        fila[3][4] = matrizes[4].getCasillas()[1];
        fila[3][5] = matrizes[4].getCasillas()[2];
        fila[3][6] = matrizes[5].getCasillas()[0];
        fila[3][7] = matrizes[5].getCasillas()[1];
        fila[3][8] = matrizes[5].getCasillas()[2];

        fila[4][0] = matrizes[3].getCasillas()[3];
        fila[4][1] = matrizes[3].getCasillas()[4];
        fila[4][2] = matrizes[3].getCasillas()[5];
        fila[4][3] = matrizes[4].getCasillas()[3];
        fila[4][4] = matrizes[4].getCasillas()[4];
        fila[4][5] = matrizes[4].getCasillas()[5];
        fila[4][6] = matrizes[5].getCasillas()[3];
        fila[4][7] = matrizes[5].getCasillas()[4];
        fila[4][8] = matrizes[5].getCasillas()[5];

        fila[5][0] = matrizes[3].getCasillas()[6];
        fila[5][1] = matrizes[3].getCasillas()[7];
        fila[5][2] = matrizes[3].getCasillas()[8];
        fila[5][3] = matrizes[4].getCasillas()[6];
        fila[5][4] = matrizes[4].getCasillas()[7];
        fila[5][5] = matrizes[4].getCasillas()[8];
        fila[5][6] = matrizes[5].getCasillas()[6];
        fila[5][7] = matrizes[5].getCasillas()[7];
        fila[5][8] = matrizes[5].getCasillas()[8];

        fila[6][0] = matrizes[6].getCasillas()[0];
        fila[6][1] = matrizes[6].getCasillas()[1];
        fila[6][2] = matrizes[6].getCasillas()[2];
        fila[6][3] = matrizes[7].getCasillas()[0];
        fila[6][4] = matrizes[7].getCasillas()[1];
        fila[6][5] = matrizes[7].getCasillas()[2];
        fila[6][6] = matrizes[8].getCasillas()[0];
        fila[6][7] = matrizes[8].getCasillas()[1];
        fila[6][8] = matrizes[8].getCasillas()[2];

        fila[7][0] = matrizes[6].getCasillas()[3];
        fila[7][1] = matrizes[6].getCasillas()[4];
        fila[7][2] = matrizes[6].getCasillas()[5];
        fila[7][3] = matrizes[7].getCasillas()[3];
        fila[7][4] = matrizes[7].getCasillas()[4];
        fila[7][5] = matrizes[7].getCasillas()[5];
        fila[7][6] = matrizes[8].getCasillas()[3];
        fila[7][7] = matrizes[8].getCasillas()[4];
        fila[7][8] = matrizes[8].getCasillas()[5];

        fila[8][0] = matrizes[6].getCasillas()[6];
        fila[8][1] = matrizes[6].getCasillas()[7];
        fila[8][2] = matrizes[6].getCasillas()[8];
        fila[8][3] = matrizes[7].getCasillas()[6];
        fila[8][4] = matrizes[7].getCasillas()[7];
        fila[8][5] = matrizes[7].getCasillas()[8];
        fila[8][6] = matrizes[8].getCasillas()[6];
        fila[8][7] = matrizes[8].getCasillas()[7];
        fila[8][8] = matrizes[8].getCasillas()[8];

        creaColumnas();

    }

    // DEVUELVE LAS MATRICES
    public Matriz[] getMatrizes() {
        return matrizes;
    }

    // CAMBIA EL VALOR DEL EL ARRAY DE MATRICES                
    public void setMatrizes(Matriz[] matrizes) {
        this.matrizes = matrizes;
    }

    // DEVUELVE EL ARRAY FILA
    public Casilla[][] getFila() {
        return fila;
    }

    // CAMBIA EL ARRAY FILA
    public void setFila(Casilla[][] fila) {
        this.fila = fila;
    }

    // DEVUELVE EL ARRAY COLUMNAS
    public Casilla[][] getColumnas() {
        return columnas;
    }

    // CAMBIA EL ARRAY COLUMNAS
    public void setColumnas(Casilla[][] columnas) {
        this.columnas = columnas;
    }

    // INICIALIZA LAS COLUMNAS A PARTIR DE LAS FILAS
    public void creaColumnas() {
        for (int i = 0; i < fila.length; i++) {
            for (int k = 0; k < fila[i].length; k++) {
                columnas[i][k] = fila[k][i];
            }
        }
    }

    // IMPRIME POR CONSOLA EL VALOR DE LAS FILAS
    // 
    public void imprimeFila() {
        for (int i = 0; i < 9; i++) {
            System.out.println("Fila: " + i);
            for (int k = 0; k < 9; k++) {

                System.out.println(fila[i][k].getValor());
            }
        }
    }

    // EJECUTA LA REGLA DE ELIMINAR LOS CANDIDATOS SALIDOS EN LAS COLUMNAS PARA TODAS LAS COLUMNAS
    public void eliminaCandidatosSalidosEnColumnas() {
        for (int i = 0; i < columnas.length; i++) {
          
            metodos.eliminaCandidatosSalidosEnLinea(columnas[i]);
        }
    }
    // EJECUTA LA REGLA DE ELIMINAR LOS CANDIDATOS SALIDOS EN LAS FILAS PARA TODAS LAS FILAS

    public void eliminaCandidatosSalidosEnFilas() {
        for (int i = 0; i < fila.length; i++) {
            metodos.eliminaCandidatosSalidosEnLinea(fila[i]);
        }
    }

    // DEVUELVE EL VALOR DE LAS CASILLAS Y SUS CANDIDATOS EN UN STRING
    public String guardaValorEnString() {
        String salida = "";
        for (int i = 0; i < matrizes.length; i++) {
            for (int p = 0; p < matrizes[i].getCasillas().length; p++) {
                salida += matrizes[i].getCasillas()[p].getValor();
                for (int j = 0; j < matrizes[i].getCasillas()[p].getCandidatos().length; j++) {
                    salida += matrizes[i].getCasillas()[p].getCandidatos()[j];
                }

            }
        }
        return salida;
    }

    // DEVUELVE TRUE SI EL SUDOKU TIENE TODAS LAS CASILLAS LLENAS
    public boolean estaCompleto() {
        for (int i = 0; i < matrizes.length; i++) {
            for (int k = 0; k < matrizes[i].getCasillas().length; k++) {
               
                if (matrizes[i].getCasillas()[k].getValor() == 0) {
                    return false;
                }
            }
        }
        return true;
    }

    // devuelve el numero de candidatos que tiene la casilla con menos candidatos
    public int cuentaMinimaDeCandidatos() {
        int cuenta = 9;

        for (int i = 0; i < matrizes.length; i++) {

            int cuentaAux = matrizes[i].cuentaMinimaDeCandidatos();

            if (cuentaAux < cuenta && cuentaAux > 1) {
                cuenta = cuentaAux;
            }
            if (cuenta == 2) {
                return cuenta;
            }

        }
        return cuenta;

    }

    // DEVUELVE LA CASILLA CON MENOS CANDIDATOS
    public Casilla buscaCasillaConMenosCadidatos() {

        int casillaConMenosCandidatos = 0;
        int numCandidatos = 9;
        int numMat = 0;
        for (int i = 0; i < matrizes.length; i++) {

            int[] vector = matrizes[i].buscaCasillasConMenosCandidatos();

            int casilla = vector[0];
            int numCandidatosB = vector[1];

            if (numCandidatos > numCandidatosB) {
                casillaConMenosCandidatos = casilla;
                numCandidatos = numCandidatosB;
                numMat = i;
            }

        }

        return matrizes[numMat].getCasillas()[casillaConMenosCandidatos];
    }

    // DEVUELVE LA POSICION A LA QUE PERTENECE UNA LA MATRIZ DONDE SE ENCUENTRA LA CASILLA PASADA COMO PARÁMETRO
    public int matrizPerteneciente(Casilla casilla) {
        for (int i = 0; i < matrizes.length; i++) {
            Casilla casillas[] = matrizes[i].getCasillas();
            for (int p = 0; p < casillas.length; p++) {
                if (casillas[p].equals(casilla)) {
                    return i;
                }

            }
        }
        return -1;

    }

    // comprueba que no se haya asignado el mismo valor dentro de una línea 
    public boolean valoresRepetidos(Casilla casillas[]) {

        for (int i = 0; i < casillas.length - 1; i++) {
            if (casillas[i].getValor() > 0) {
                for (int k = i + 1; k < casillas.length; k++) {
                    if (casillas[k].getValor() > 0) {
                        if (casillas[i].getValor() == casillas[k].getValor()) {
                            return false;
                        }
                    }
                }
            }
        }
        return true;

    }

    // COMPRUEBA SI EL SUDOKU TIENE SOLUCIÓN
    public boolean estaDeformado() {
        for (int i = 0; i < matrizes.length; i++) {

            if (!valoresRepetidos(matrizes[i].getCasillas())) {

                return false;
            }

            if (matrizes[i].deformacionDeCandidatos()) {
                return false;
            }
        }

        for (int i = 0; i < fila.length; i++) {

            if (!valoresRepetidos(fila[i])) {

                return false;
            }
        }

        for (int i = 0; i < columnas.length; i++) {
            if (!valoresRepetidos(columnas[i])) {

                return false;
            }
        }

        return true;

    }

    /*
		// devuelve el valor mas repetido y las veces repetido
		public int  []  valorMasRepetido(){
			ArrayList<Integer> valores = new ArrayList<Integer>();
			int salida [] = new int[2];
			// guarda el valor mas repetido y las veces que se ha repetido
		
			for (int i=0;i<matrizes.length;i++){
				for(int c =0;c<matrizes[i].getCasillas().length;c++){
					if(matrizes[i].getCasillas()[c].getValor()>0){
						valores.add(matrizes[i].getCasillas()[c].getValor());
						

					}
				}
					
			}
			salida = getValorMasRepetido(valores);
			return salida;
		}
     */

 /*
		public int [] getValorMasRepetido(ArrayList<Integer> lista){
			
			ArrayList<Integer> salidos = metodos.eliminaRepetidosArray(lista);
			  int [] salida = new int[2];
		
			  int veces = 0;
			 int vecesAux = 0;
			  for(int i =0;i<salidos.size();i++){
				  vecesAux = 0;
				  for(int p =0;p<lista.size();p++){
				  if(salidos.get(i)==lista.get(p)){
					  vecesAux++;
				  }
			  }
				  if(vecesAux>veces){
					  veces = vecesAux;
					  salida[0] = salidos.get(i);
				  }

				  }
			  
			  salida[1] = veces;
			  return salida;
			  
		}
     */
    // devuelve la linea matriz o fila mas mas completa
    public int[] getLineaMasCompleta() {
        int masCompleta[] = new int[3];

        int lineas[] = new int[3];

        int mMatriz = metodos.getMatrizConMasCandidatos(matrizes)[1];
        int mFila = metodos.getLineaConMasCandidatos(fila)[1];
        int mColumna = metodos.getLineaConMasCandidatos(columnas)[1];

        // guarda el valor mas grande
        if (mMatriz > mFila) {

            if (mMatriz > mColumna) {
                masCompleta[1] = 0;
                masCompleta[0] = mMatriz;
                masCompleta[2] = metodos.getMatrizConMasCandidatos(matrizes)[0];
            } else {
                masCompleta[1] = 1;
                masCompleta[0] = mColumna;
                masCompleta[2] = metodos.getLineaConMasCandidatos(columnas)[0];
            }
        } else {
            if (mFila > mColumna) {
                masCompleta[1] = 2;
                masCompleta[0] = mFila;
                masCompleta[2] = metodos.getLineaConMasCandidatos(fila)[0];
            } else {
                masCompleta[1] = 1;
                masCompleta[0] = mColumna;
                masCompleta[2] = metodos.getLineaConMasCandidatos(columnas)[0];
            }
        }

        return masCompleta;

    }

    // devuelve la linea matriz o fila mas mas completa
    public int[] getLineaConMenosCandidatos() {
        int masCompleta[] = new int[3];

        int lineas[] = new int[3];

        int mMatriz = metodos.getLineasConMenosCandidatos(matrizes)[1];
        int mFila = metodos.getLineasConMenosCandidatos(fila)[1];
        int mColumna = metodos.getLineasConMenosCandidatos(columnas)[1];

        // guarda el valor mas grande
        if (mMatriz < mFila) {

            if (mMatriz < mColumna) {
                masCompleta[1] = 0;
                masCompleta[0] = mMatriz;
                masCompleta[2] = metodos.getLineasConMenosCandidatos(matrizes)[0];
            } else {
                masCompleta[1] = 1;
                masCompleta[0] = mColumna;
                masCompleta[2] = metodos.getLineasConMenosCandidatos(columnas)[0];
            }
        } else {
            if (mFila < mColumna) {
                masCompleta[1] = 2;
                masCompleta[0] = mFila;
                masCompleta[2] = metodos.getLineasConMenosCandidatos(fila)[0];
            } else {
                masCompleta[1] = 1;
                masCompleta[0] = mColumna;
                masCompleta[2] = metodos.getLineasConMenosCandidatos(columnas)[0];
            }
        }

        return masCompleta;

    }

    // EJECUTA LA REGLA PAREJAS ESCONDIDAS PARA TODAS LAS MATRIZES
    public void eliminaParejasTriosEscondidosMatrizes() {

        for (int i = 0; i < matrizes.length; i++) {

            metodos.parejasTriosEscondidas(matrizes[i].getCasillas());
        }

    }

    // EJECUTA LA REGLA PAREJAS ESCONDIDAS PARA TODAS LAS FILAS
    public void eliminaParejasTriosEscondidosFilas() {

        for (int i = 0; i < fila.length; i++) {

            metodos.parejasTriosEscondidas(fila[i]);
        }

    }
    // EJECUTA LA REGLA PAREJAS ESCONDIDAS PARA TODAS LAS COLUMNAS

    public void eliminaParejasTriosEscondidosColumnas() {

        for (int i = 0; i < columnas.length; i++) {

            metodos.parejasTriosEscondidas(columnas[i]);
        }

    }

    // EJECUTA REGLA PAREJAS DESNUDAS EN TODAS LAS MATRICES (NO SE USA)
    public void reglaParejasDesnudasMatrizes() {

        for (int i = 0; i < matrizes.length; i++) {

            metodos.reglaParejasDesnudas(matrizes[i].getCasillas());
        }

    }
    // EJECUTA REGLA PAREJAS DESNUDAS EN TODAS LAS FILAS (NO SE USA)

    public void reglaParejasDesnudasFilas() {

        for (int i = 0; i < fila.length; i++) {

            metodos.reglaParejasDesnudas(fila[i]);
        }

    }
    // EJECUTA REGLA PAREJAS DESNUDAS EN TODAS LAS COLUMNAS (NO SE USA)

    public void reglaParejasDesnudasColumnas() {

        for (int i = 0; i < columnas.length; i++) {

            metodos.reglaParejasDesnudas(columnas[i]);
        }

    }

    // DEVUELVE LAS VECES QE HA SALIDO UN VALOR EN UNA MATRIZ(NO SE USA)
    public int vecesSalido(int valor) {
        int cuenta = 0;
        for (int i = 0; i < fila.length; i++) {

            for (int y = 0; y < fila[i].length; y++) {

                if (fila[i][y].getValor() == valor) {
                    cuenta++;

                }

            }

        }
        return cuenta;
    }

    // IMPRIME EL SUDOKU CON SUS VALORES Y CANDIDATOS		
    public void imprime() {
        for (int i = 0; i < matrizes.length; i++) {
            System.out.println("Matriz " + i + "\n\n");
            matrizes[i].imprime();
            System.out.println("\n");
        }
        System.out.println("\n\n");
    }
    
    // devuelve true si no se ha introducido ningun valor en el sudoku
    public boolean estaVacio(){
        
        for(Matriz m : matrizes){
            
            for(Casilla c : m.getCasillas()){
                if(c.getValor()>0){
                    return false;
                }
            }
        }
        return true;
        
    }
    

    // IMPRIME EL SUDOKU CON FORMA DE SUDOKU POR CONSOLA
    public void imprimeSudokuFolio() {

        Matriz a = matrizes[0];
        Matriz b = matrizes[1];
        Matriz c = matrizes[2];
        Matriz d = matrizes[3];
        Matriz e = matrizes[4];
        Matriz f = matrizes[5];
        Matriz g = matrizes[6];
        Matriz h = matrizes[7];
        Matriz i = matrizes[8];

        Casilla a1[] = a.getCasillas();
        Casilla a2[] = b.getCasillas();
        Casilla a3[] = c.getCasillas();
        Casilla a4[] = d.getCasillas();
        Casilla a5[] = e.getCasillas();
        Casilla a6[] = f.getCasillas();
        Casilla a7[] = g.getCasillas();
        Casilla a8[] = h.getCasillas();
        Casilla a9[] = i.getCasillas();

        String salid = "|" + a1[0].getValor() + "|" + a1[1].getValor() + "|" + a1[2].getValor() + "| |" + a2[0].getValor() + "|" + a2[1].getValor() + "|" + a2[2].getValor() + "| |" + a3[0].getValor() + "|" + a3[1].getValor() + "|" + a3[2].getValor() + "|\n"
                + "|" + a1[3].getValor() + "|" + a1[4].getValor() + "|" + a1[5].getValor() + "| |" + a2[3].getValor() + "|" + a2[4].getValor() + "|" + a2[5].getValor() + "| |" + a3[3].getValor() + "|" + a3[4].getValor() + "|" + a3[5].getValor() + "|\n"
                + "|" + a1[6].getValor() + "|" + a1[7].getValor() + "|" + a1[8].getValor() + "| |" + a2[6].getValor() + "|" + a2[7].getValor() + "|" + a2[8].getValor() + "| |" + a3[6].getValor() + "|" + a3[7].getValor() + "|" + a3[8].getValor() + "|\n\n"
                + "|" + a4[0].getValor() + "|" + a4[1].getValor() + "|" + a4[2].getValor() + "| |" + a5[0].getValor() + "|" + a5[1].getValor() + "|" + a5[2].getValor() + "| |" + a6[0].getValor() + "|" + a6[1].getValor() + "|" + a6[2].getValor() + "|\n"
                + "|" + a4[3].getValor() + "|" + a4[4].getValor() + "|" + a4[5].getValor() + "| |" + a5[3].getValor() + "|" + a5[4].getValor() + "|" + a5[5].getValor() + "| |" + a6[3].getValor() + "|" + a6[4].getValor() + "|" + a6[5].getValor() + "|\n"
                + "|" + a4[6].getValor() + "|" + a4[7].getValor() + "|" + a4[8].getValor() + "| |" + a5[6].getValor() + "|" + a5[7].getValor() + "|" + a5[8].getValor() + "| |" + a6[6].getValor() + "|" + a6[7].getValor() + "|" + a6[8].getValor() + "|\n\n"
                + "|" + a7[0].getValor() + "|" + a7[1].getValor() + "|" + a7[2].getValor() + "| |" + a8[0].getValor() + "|" + a8[1].getValor() + "|" + a8[2].getValor() + "| |" + a9[0].getValor() + "|" + a9[1].getValor() + "|" + a9[2].getValor() + "|\n"
                + "|" + a7[3].getValor() + "|" + a7[4].getValor() + "|" + a7[5].getValor() + "| |" + a8[3].getValor() + "|" + a8[4].getValor() + "|" + a8[5].getValor() + "| |" + a9[3].getValor() + "|" + a9[4].getValor() + "|" + a9[5].getValor() + "|\n"
                + "|" + a7[6].getValor() + "|" + a7[7].getValor() + "|" + a7[8].getValor() + "| |" + a8[6].getValor() + "|" + a8[7].getValor() + "|" + a8[8].getValor() + "| |" + a9[6].getValor() + "|" + a9[7].getValor() + "|" + a9[8].getValor() + "|\n";

        System.out.println(salid);

    }

}
