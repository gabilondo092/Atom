package resuelve.sudokus;
import interfaz.Tablero;
import java.util.ArrayList;
import javax.swing.JOptionPane;


/**
 * Clase encargada de resolver el sudoku
 * @author Gabi
 */



public class Principal extends Thread {
    // controla el fin del flujo dependiendo según el tiempo que tarde
    private static boolean termina = false;
    // controla las veces que se ha ejecutadao el método recursivo resueklve
    private static int cuentaRecursiva = 0;
    // controla la distancia de métodos a la que está el método resulve principal
    private static int nivelRecursividad = 0;
    // se usa cuando el sudoku se resuelve dentro del método recursivo
    private static Sudoku sudokuResuelto = null;
    
    private Sudoku sudoku = null;
    private JOptionPane panel;
    //private boolean[] terminado = new boolean[]{false};
    
    private static long t1 = 0;
    Tablero tablero;
    // static int max

    private Casilla aa1[] = new Casilla[9];
    private Casilla aa2[] = new Casilla[9];
    private Casilla aa3[] = new Casilla[9];
    private Casilla aa4[] = new Casilla[9];
    private Casilla aa5[] = new Casilla[9];
    private Casilla aa6[] = new Casilla[9];
    private Casilla aa7[] = new Casilla[9];
    private Casilla aa8[] = new Casilla[9];
    private Casilla aa9[] = new Casilla[9];
    private Casilla cas[][] = new Casilla[][]{aa1, aa2, aa3, aa4, aa5, aa6, aa7, aa8, aa9};

    private Matriz ma = new Matriz(aa1);
    private Matriz mb = new Matriz(aa2);
    private Matriz mc = new Matriz(aa3);
    private Matriz md = new Matriz(aa4);
    private Matriz me = new Matriz(aa5);
    private Matriz mf = new Matriz(aa6);
    private Matriz mg = new Matriz(aa7);
    private Matriz mh = new Matriz(aa8);
    private Matriz mi = new Matriz(aa9);
    private Matriz matrizes[] = new Matriz[]{ma, mb, mc, md, me, mf, mg, mh, mi};

    public Principal(int valores[][]) {

        iniciaSudoku(valores);
        t1 = 0;
     termina = false;

    }

    public Principal(int valores[][], boolean b[], JOptionPane pan) {
     t1 = 0;
     termina = false;
       

        iniciaSudoku(valores);
        panel = pan;

    }

    public Principal(Sudoku s, Tablero tablero) {

        aa1 = s.getMatrizes()[0].getCasillas();
        aa2 = s.getMatrizes()[1].getCasillas();
        aa3 = s.getMatrizes()[2].getCasillas();
        aa4 = s.getMatrizes()[3].getCasillas();
        aa5 = s.getMatrizes()[4].getCasillas();
        aa6 = s.getMatrizes()[5].getCasillas();
        aa7 = s.getMatrizes()[6].getCasillas();
        aa8 = s.getMatrizes()[7].getCasillas();
        aa9 = s.getMatrizes()[8].getCasillas();
        cas = new Casilla[][]{aa1, aa2, aa3, aa4, aa5, aa6, aa7, aa8, aa9};
        ma = new Matriz(aa1);
        mb = new Matriz(aa2);
        mc = new Matriz(aa3);
        md = new Matriz(aa4);
        me = new Matriz(aa5);
        mf = new Matriz(aa6);
        mg = new Matriz(aa7);
        mh = new Matriz(aa8);
        mi = new Matriz(aa9);
        matrizes = new Matriz[]{
            ma, mb, mc, md, me, mf, mg, mh, mi
        };
        sudoku = new Sudoku(matrizes);
        this.tablero = tablero;
        t1 = 0;
     termina = false;

    }

    public void iniciaSudoku(int valores[][]) {

        for (int i = 0; i < cas.length; i++) {

            for (int j = 0; j < cas.length; j++) {

                cas[i][j] = new Casilla(valores[i][j], j);

            }

        }

        Matriz matrizes[] = new Matriz[]{ma, mb, mc, md, me, mf, mg, mh, mi}; // sudoku.getMatrizes();//

        //GeneraSudoku generaSud = new GeneraSudoku();
        sudoku = new Sudoku(matrizes); //generaSudoku.generaSudoku4();

    }

    // métoodo run que ejecuta el método resuelve
    public void run() {
    //    termina = false;
        
        Metodos m = new Metodos();
        long t0 = System.currentTimeMillis();
        resuelve();
        tablero.activaBotones();
        long t1 = System.currentTimeMillis();

        long marcaTiempo = t1 - t0;
        

        javax.swing.JLabel img = tablero.getimgCargando();
        img.setVisible(false);
        tablero.getBtnParar().setVisible(false);

        if (sudoku.estaDeformado()) {
            if(sudoku.estaCompleto()){
            tablero.cambiaValores(sudoku);
            long seg = marcaTiempo / 1000;
            tablero.getLblTiempo().setText("Tiempo: " + seg + (seg == 1 ? " segundo" : " segundos"));
            }else{
            JOptionPane.showMessageDialog(null, "El sudoku que has introducido no tiene solución");
            tablero.getLblTiempo().setText("Tiempo:");
            }
        } else {
            JOptionPane.showMessageDialog(null, "El sudoku que has introducido no tiene solución");
            tablero.getLblTiempo().setText("Tiempo:");
        }

    }

    public Sudoku getSudoku() {
        return sudoku;
    }

    /**
     *
     * @return
     */
    public Sudoku resuelve() {
           
        Casilla filas[][] = sudoku.getFila();
        Casilla columnas[][] = sudoku.getColumnas();
        Metodos metodos = new Metodos();
        boolean cambios = false;
        
        // se inicia el contador antes de empezar a resolver
        // si tarda mucho significa que no hay solución
           t1 =   System.currentTimeMillis()/1000;
        

        // COMIENZO DEL BUCLE PRINCIPAL
        while (!sudoku.estaCompleto()) {
       
            // si ha pasado mucho tiempo y no lo resuleve significa que no tiene solución asique termina
            if(termina){ return sudoku;   }
            // GUARDA VALORES INICIALES PARA COMPARARLOS
            String comp1 = sudoku.guardaValorEnString();
            cambios = false;
            // REGLAS BÁSICAS
            metodos.eliminaCandidatosSalidoEnMatrizes(sudoku);

            metodos.eliminaCandidatosSalidosEnColumnas(sudoku);

            metodos.eliminaCandidatosSalidosEnFilas(sudoku);

            //  COMPRUEBA SI EL SUDOKU TIENE SULUCIÓN
            if (!sudoku.estaDeformado()) {

                break;
            }

            // EJECUTA LA REGLA PAREJAS TRIOS ESCONDIDAS PARA FILAS			
            sudoku.eliminaParejasTriosEscondidosFilas();

            sudoku.eliminaParejasTriosEscondidosColumnas();
            // GUARDA LOS VALORES DEL SUDOKU
            // GUARDA LOS VALORES DEL SUDOKU
            String comp2 = sudoku.guardaValorEnString();

            // SI SE HAN PRODUCIDO CAMBIOS EN EL SUDOKU TRAS EJECUTARSE LAS REGLAS ANTERIORES
            if (comp1.equals(comp2)) {
                cambios = true;
            } else {
                cambios = false;
            }

            if (cambios) {

                sudoku.eliminaParejasTriosEscondidosFilas();

                // GUARDA LOS VALORES DEL SUDOKU
                comp2 = sudoku.guardaValorEnString();

                // SI SE HAN PRODUCIDO CAMBIOS EN EL SUDOKU TRAS EJECUTARSE LAS REGLAS ANTERIORES
                if (comp1.equals(comp2)) {
                    cambios = true;
                } else {
                    cambios = false;
                }

                if (cambios) {

                    // EJECUTA LA REGLA PAREJAS ESCONDIDAS APLICADAS A MATRICES
                    sudoku.eliminaParejasTriosEscondidosMatrizes();

                    // GUARDA EL VALOR DEL SUDOKU		
                    comp2 = sudoku.guardaValorEnString();

                    if (comp1.equals(comp2)) {
                        cambios = true;
                    } else {
                        cambios = false;
                    }

                    if (cambios) {

                        // APLICA LA REGLA CANDIDATOS EXCLUSIVOS EN LAS MATRICES
                        for (int y = 0; y < sudoku.getMatrizes().length; y++) {

                            metodos.asignaCandidatoExclusivo(sudoku.getMatrizes()[y].getCasillas());

                        }

                        // GUARDA EL VALOR DEL SUDOKU	
                        comp2 = sudoku.guardaValorEnString();

                        if (comp1.equals(comp2)) {
                            cambios = true;
                        } else {
                            cambios = false;
                        }
                        {

                        }
                        if (cambios) {

                            // APLICA LA REGLA CANDIDATOS EXCLUSIVOS EN FILAS
                            for (int y = 0; y < sudoku.getMatrizes().length; y++) {

                                metodos.asignaCandidatoExclusivo(filas[y]);
                            }
                            //GUARDA EL VALOR DEL SUDOKU
                            comp2 = sudoku.guardaValorEnString();

                            if (comp1.equals(comp2)) {
                                cambios = true;
                            } else {
                                cambios = false;
                            }

                            if (cambios) {

                                // APLICA CANDIDATO EXCLUSIVO
                                for (int y = 0; y < sudoku.getMatrizes().length; y++) {

                                    metodos.asignaCandidatoExclusivo(columnas[y]);
                                }

                                // GUARDA EL VALRO DEL SUDOKU
                                comp2 = sudoku.guardaValorEnString();
                                if (comp1.equals(comp2)) {
                                    cambios = true;
                                } else {
                                    cambios = false;
                                }

                                if (cambios) {
                                    metodos.eliminaCandidatosEnUnaSolaFila(sudoku.getMatrizes());

                                    comp2 = sudoku.guardaValorEnString();
                                    if (comp1.equals(comp2)) {
                                        cambios = true;
                                    } else {
                                        cambios = false;
                                    }
                                    if (cambios) {

                                        // EJECUTA LA REGLA CANDIATOS EN LINEA PARA COLUMNAS
                                        metodos.eliminaCandidatosEnUnaSolaColumna(sudoku.getMatrizes());

                                        comp2 = sudoku.guardaValorEnString();
                                        if (comp1.equals(comp2)) {
                                            cambios = true;
                                        } else {
                                            cambios = false;
                                        }

                                        if (cambios) {

                                            //COMIENZO DEL BACKTRACKING
                                            // CREA UNA COPIA DEL SUDOKU
                                            Sudoku sudokuCopia = new Sudoku(sudoku);

                                            // GUARDA LA CASILLA CON MENOS CANDIDATOS
                                            Casilla cas = sudokuCopia.buscaCasillaConMenosCadidatos();
                                            // GUARDA LISTA DE CANDIDATOS
                                            ArrayList<Integer> can = cas.getCandidatosUnicamente();

                                            // comprobar que sudoku tenga algina casilla con dos candidatos
                                            // RECORRE LISTA DE CANDIDATOS
                                            for (int l = 0; l < can.size(); l++) {
                                                // SI EL CANDIDATO ES MAYOR QUE CERO(SIEMPRE LO ES)
                                                if (can.get(l) > 0) {

                                                    // restauracion de valores en caso de que los primeros valores den error
                                                    sudokuCopia = new Sudoku(sudoku);

                                                    // GUARDA LA CASILLA CON MENOS CANDIDATOS
                                                    cas = sudokuCopia.buscaCasillaConMenosCadidatos();
                                                    // CAMBIA SU VALOR POR EL DEL PRIMER CANDIDATO
                                                    cas.setValor(can.get(l));
                                                
                                                    // EJECUTA EL MÉTODO RESUELVE_SUDOKU
                                                    // SI EL NÚMERO QUE SE HA INTRODUCIDO ESTÁ BIEN DEVOLVERA EL SUDOKU YA RESUELTO
                                                    if (resuelveSudoku(sudokuCopia)) {
                                                        // GUARDAMOS EL VALOR DEL SUDOKU YA RESUELTO
                                                        sudoku = sudokuCopia;
                                                        //  return sudoku;
                                                        break;

                                                    } // SI EL NÚMERO QUE SE HA INTRODUCIDO ES ERRÓNEO
                                                    else {
                                                        // si solo tiene dos candidatos la casilla que estamos probando
                                                        // y da error uno significa que la el que encaja es el otro
                                                        if (can.size() == 2) {
                                                            // ASIQUE CAMBIAMOS EL VALOR POR EL DEL SIGUIENTE CANDIDATO
                                                            Casilla casillaElim = sudoku.buscaCasillaConMenosCadidatos();
                                                            casillaElim.setValor(can.get(l + 1));;

                                                            break;
                                                        }
                                                    }

                                                }
                                            }
                                            if(termina){
                                                
                                               sudokuResuelto = sudoku;
                                               return sudoku;
                                            }

                                        }

                                    }
                                }
                            }
                        }

                    }

                }

            }
           
        }
        return sudoku;
    }

    /**
     * resuelveSudoku -> sobrecarga que devuelve boolean, en vez de Sudoku
     *
     * @param sudoku
     * @return true , si el sudoku se resuelve, false si no tiene solución
     */
    //--------------------------------------------------------------------------------
    public static boolean resuelveSudoku(Sudoku sudoku) {

        // cada vez que se ejecuta este método se aumentan las variables
        // para conprobar las veces que se ha ejecutado
        nivelRecursividad++;
        cuentaRecursiva++;

        Casilla filas[][] = sudoku.getFila();
        Casilla columnas[][] = sudoku.getColumnas();
        Metodos metodos = new Metodos();
        boolean cambio = false;

       
       
        // COMIENZO DEL BUCLE PRINCIPAL
        while (!sudoku.estaCompleto()) {
            long t2 = System.currentTimeMillis()/1000;
        long tr = t2-t1;
   
                
        if(tr>80){
            termina = true;
            sudokuResuelto = sudoku;
            return false;
            
            
            
            /*
 
            
            sudoku.getMatrizes()[0].getCasillas()[0].setValor3(0);
            for(int i = 0;i<sudoku.getMatrizes()[0].getCasillas()[0].getCandidatos().length;i++){
            sudoku.getMatrizes()[0].getCasillas()[0].getCandidatos()[i] = 0;
        
            }
            */
            
            
            
            
        }
            if (!sudoku.estaDeformado()) {

                nivelRecursividad--;

                return false;
            }

            // GUARDA VALORES INICIALES PARA COMPARARLOS
            String comp1 = sudoku.guardaValorEnString();
            cambio = false;

            for (int j = 0; j < sudoku.getMatrizes().length; j++) {

                Casilla[][] filass = sudoku.getMatrizes()[j].divideEnFilas();

                metodos.eliminaCandidatosSalidosEnLinea(sudoku.getMatrizes()[j].getCasillas());

            }

            sudoku.eliminaCandidatosSalidosEnColumnas();

            sudoku.eliminaCandidatosSalidosEnFilas();

            if (!sudoku.estaDeformado()) {

                nivelRecursividad--;

                return false;
            }

            

            sudoku.eliminaParejasTriosEscondidosFilas();

         String   comp2 = sudoku.guardaValorEnString();

            if (comp1.equals(comp2)) {
                cambio = true;
            } else {
                cambio = false;
            }
         

            if (cambio) {

                sudoku.eliminaParejasTriosEscondidosColumnas();

                comp2 = sudoku.guardaValorEnString();

                if (comp1.equals(comp2)) {
                    cambio = true;
                } else {
                    cambio = false;
                }
                

                if (cambio) {

                    sudoku.eliminaParejasTriosEscondidosMatrizes();

                    comp2 = sudoku.guardaValorEnString();

                    if (comp1.equals(comp2)) {
                        cambio = true;
                    } else {
                        cambio = false;
                    }
/*
                    if (cambio) {
                        sudoku.reglaParejasDesnudasMatrizes();

                        comp2 = sudoku.guardaValorEnString();

                        if (comp1.equals(comp2)) {
                            cambio = true;
                        } else {
                            cambio = false;
                        }
 */
                        if (cambio) {

                            for (int y = 0; y < sudoku.getMatrizes().length; y++) {

                                metodos.asignaCandidatoExclusivo(sudoku.getMatrizes()[y].getCasillas());

                            }

                            comp2 = sudoku.guardaValorEnString();
                            if (comp1.equals(comp2)) {
                                cambio = true;
                            } else {
                                cambio = false;
                            }
                            {

                            }
                            if (cambio) {

                                for (int y = 0; y < sudoku.getMatrizes().length; y++) {

                                    metodos.asignaCandidatoExclusivo(filas[y]);
                                }

                                comp2 = sudoku.guardaValorEnString();

                                if (comp1.equals(comp2)) {
                                    cambio = true;
                                } else {
                                    cambio = false;
                                }

                                if (cambio) {

                                    for (int y = 0; y < sudoku.getMatrizes().length; y++) {

                                        metodos.asignaCandidatoExclusivo(columnas[y]);
                                    }

                                    comp2 = sudoku.guardaValorEnString();
                                    if (comp1.equals(comp2)) {
                                        cambio = true;
                                    } else {
                                        cambio = false;
                                    }

                                    if (cambio) {

                                        metodos.eliminaCandidatosEnUnaSolaFila(sudoku.getMatrizes());

                                        if (!sudoku.estaDeformado()) {

                                            nivelRecursividad--;

                                            return false;
                                        }

                                        comp2 = sudoku.guardaValorEnString();
                                        if (comp1.equals(comp2)) {
                                            cambio = true;
                                        } else {
                                            cambio = false;
                                        }
                                        if (cambio) {
                                           

                                            metodos.eliminaCandidatosEnUnaSolaColumna(sudoku.getMatrizes());

                                            comp2 = sudoku.guardaValorEnString();
                                            if (comp1.equals(comp2)) {
                                                cambio = true;
                                            } else {
                                                cambio = false;
                                            }

                                            if (cambio) {

                                                Sudoku sudokuCopia = new Sudoku(sudoku);

                                                Casilla cas = sudokuCopia.buscaCasillaConMenosCadidatos();
                                                ArrayList<Integer> can = cas.getCandidatosUnicamente();

                                                for (int l = 0; l < can.size(); l++) {

                                                    if (can.get(l) > 0) {

                                                        // restauracion de valores en caso de que los primeros valores den error
                                                        sudokuCopia = new Sudoku(sudoku);
                                                        cas = sudokuCopia.buscaCasillaConMenosCadidatos();
                                                        cas.setValor(can.get(l));

                                                        cuentaRecursiva++;
                                                        nivelRecursividad++;

                                                        if (resuelveSudoku(sudokuCopia)) {

                                                            sudoku = sudokuResuelto;
                                                            sudokuCopia = sudokuResuelto;

                                                            return true;

                                                        } else {
                                                            // si solo tiene dos candidatos la casilla que estamos probando
                                                            // y da error uno significa que la que encaja es el otro
                                                            if (can.size() == 2) {
                                                                Casilla casillaElim = sudoku.buscaCasillaConMenosCadidatos();
                                                                casillaElim.setValor(can.get(l + 1));;
                                                                break;
                                                            }
                                                        }

                                                    }

                                                }

                                            }

                                        }
                                    }
                               
                            }

                        }

                    }
                }

            }
           

            if (!sudoku.estaDeformado()) {

                nivelRecursividad--;

                return false;
            }

        }

        sudokuResuelto = sudoku;
        nivelRecursividad--;
        return true;
    }

}
