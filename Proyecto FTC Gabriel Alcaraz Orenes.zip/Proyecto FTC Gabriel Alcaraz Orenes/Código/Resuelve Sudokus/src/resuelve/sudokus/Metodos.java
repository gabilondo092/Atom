package resuelve.sudokus;

import java.util.ArrayList;

/**
 * Esta clase implementa las técnicas de resolución de sudokus
 * y otros métodos de comprobación que se usan tanto en matrices,columnas y filas
 * 
 * @author Gabi
 */



public class Metodos {

    // devuelve los valores salidos dentro de una linea o matriz
    public ArrayList<Integer> getValoresSalidos(Casilla casillas[]) {
        ArrayList<Integer> salidos = new ArrayList<Integer>();
        for (int i = 0; i < casillas.length; i++) {
            if (casillas[i].getValor() > 0) {
                salidos.add(casillas[i].getValor());
            }
        }
      
        for (int v : salidos) {
       
        }
        return salidos;

    }

    /**
     * Regla básica que consiste en eliminar los candidatos equivalentes a los
     * valores que ya han salido en una línea.
     *
     * @param casillas
     */
    public void eliminaCandidatosSalidosEnLinea(Casilla casillas[]) {

        // Crea array con los valores salidos en una línea
        ArrayList<Integer> salidos = getValoresSalidos(casillas);

        // recorre las casillas de la línea
        for (int i = 0; i < casillas.length; i++) {

            // si la casilla esta vacía
            if (casillas[i].getValor() == 0) {

                // recorre los valores salidos en la línea
                for (int j = 0; j < salidos.size(); j++) {

                    // elimina el candidato equivalente a los valores que han salido
                    casillas[i].eliminaCandidato(salidos.get(j));
                }

            }
            // si solo queda un candidato cambiara su valor al de ese candidato
            cojeUnicoCandidatoDisponible(casillas);
        }
    }

    /**
     * Ejecuta la regla básica de eliminar candidatos que ya han salido
     *
     * @param sudoku
     */
    public void eliminaCandidatosSalidoEnMatrizes(Sudoku sudoku) {

        Matriz matrizes[] = sudoku.getMatrizes();

        for (Matriz m : matrizes) {

            eliminaCandidatosSalidosEnLinea(m.getCasillas());

        }

    }

    /**
     * Ejecuta la regla básica de eliminar candidatos que ya han salido
     *
     * @param sudoku
     */
    public void eliminaCandidatosSalidosEnColumnas(Sudoku sudoku) {
        for (int i = 0; i < sudoku.getColumnas().length; i++) {

            eliminaCandidatosSalidosEnLinea(sudoku.getColumnas()[i]);
        }
    }

    /**
     * Ejecuta la regla básica de eliminar candidatos que ya han salido
     *
     * @param sudoku
     */
    public void eliminaCandidatosSalidosEnFilas(Sudoku sudoku) {
        for (int i = 0; i < sudoku.getFila().length; i++) {
            
            eliminaCandidatosSalidosEnLinea(sudoku.getFila()[i]);
        }
    }

    /**
     * Recorre una línea y comprueba Si solo queda un candidato, cambia su valor
     * por el de ese candidato
     *
     * @param casillas
     */
    public void cojeUnicoCandidatoDisponible(Casilla casillas[]) {
        for (int i = 0; i < casillas.length; i++) {
            if (casillas[i].soloHayUnCandidato() != -1) {
                casillas[i].asignarUnicoCandidato();
            }
        }
    }

    /**
     * DEVUELVE UNA LISTA DE CANDIDATOS REPETIDOS DENTRO DE UNA LÍNEA (EL
     * PARÁMETRO QUE RECIBE)
     *
     * @param casillas
     * @return
     */
    public ArrayList<Integer> getCandidatosRepetidos(Casilla casillas[]) {
        ArrayList<Integer> repetidos = new ArrayList<Integer>();

        // recorre casillas
        for (int i = 0; i < casillas.length; i++) {

            // si está vacia
            if (casillas[i].getValor() == 0) {
                // recorre los candidatos
                int[] candidatos = casillas[i].getCandidatos();

                for (int j = 0; j < candidatos.length; j++) {

                    boolean pasa = false;

                    if (candidatos[j] > 0) {

                        //		Syrecorre las casillas que hay por delante de la casilla actual
                        for (int h = i + 1; h < casillas.length; h++) {
                            //		si esta vacia
                            if (casillas[h].getValor() == 0) {
                                int[] candidatosSig = casillas[h].getCandidatos();
                                // pasa sus candidatos
                                for (int l = 0; l < candidatosSig.length; l++) {

                                    if (candidatosSig[l] > 0) {
                                        // si el candidato i conincide con el candidato	l estan repetidos
                                        if (candidatosSig[l] == candidatos[j]) {
                                            // si no esta en la lista lo añade
                                            if (!repetidos.contains(candidatosSig[l])) {
                                                repetidos.add(candidatosSig[l]);
                                                pasa = true;
                                                break;
                                            }
                                        }
                                    }
                                }
                            }
                            if (pasa) {
                                break;
                            }
                        } 

                    }
                }
            }
        }
        return repetidos;
    }

    /*
	public ArrayList<Integer> eliminaRepetidosArray(ArrayList<Integer> repetidos){
		ArrayList<Integer> salida = new ArrayList<Integer>();
		
		for(int i=0;i<repetidos.size();i++){
			boolean dentro = true;
			for(int j=0;j<salida.size();j++){
				if(repetidos.get(i)==salida.get(j)){
					dentro = false;
					break;
				}
				
			} if(dentro) salida.add(repetidos.get(i));
		}
		return salida;
	}

     */
    // DEVUELVEUNA LISTA DE LOS VALORES QUE FALTAN POR SALIR EN EL ARRAY DE CASILLAS
    public ArrayList<Integer> getValoresNoSalidos(Casilla casillas[]) {
        ArrayList<Integer> salidos = getValoresSalidos(casillas);
        ArrayList<Integer> noSalidos = new ArrayList<Integer>();
        int[] todos = new int[]{1, 2, 3, 4, 5, 6, 7, 8, 9};
        for (int i = 0; i < salidos.size(); i++) {
            if (salidos.get(i) > 0) {
                for (int j = 0; j < todos.length; j++) {
                    if (todos[j] > 0) {
                        if (salidos.get(i) == todos[j]) {
                            todos[j] = 0;
                            break;
                        }
                    }
                }
            }

        }
        for (int i = 0; i < todos.length; i++) {
            if (todos[i] != 0) {

                noSalidos.add(todos[i]);
            }
        }
        return noSalidos;
    }

    // REGLA 
    public void asignaCandidatoExclusivo(Casilla casillas[]) {

        //  genera lista de candidatos repetidos en la línea
        ArrayList<Integer> repetidos = getCandidatosRepetidos(casillas);
        // se recorre la linea
        for (int i = 0; i < casillas.length; i++) {
            // si la casilla esta vacía
            if (casillas[i].getValor() == 0) {
                // genera lista de candidatos
                int[] candidatos = casillas[i].getCandidatos();

                // recorre lista de candidatos
                for (int j = 0; j < candidatos.length; j++) {

                    if (candidatos[j] > 0) {

                        // si el candidato no esta en la lista de repetidos
                        if (!repetidos.contains(candidatos[j])) {

                            // significa que es exclusivo y solo encaja en esa casilla
                            // cambia el valor de la casilla por el del candidato
                            casillas[i].setValor(candidatos[j]);
                        }

                    }
                }
            }
        }

    }

    // no usado
    public void asignaCandidatoExclusivo2(Casilla casillas[]) {
        //	
        ArrayList<Integer> repetidos = getCandidatosRepetidos(casillas);
        for (int i = 0; i < casillas.length; i++) {
            //casillas[i].imprime();
            if (casillas[i].getValor() == 0) {
                int[] candidatos = casillas[i].getCandidatos();
                for (int j = 0; j < candidatos.length; j++) {
                    if (candidatos[j] > 0) {
                        for (int l = 0; l < repetidos.size(); l++) {
                            if (candidatos[j] == repetidos.get(l)) {

                                break;
                            } else {
                                if (l == repetidos.size() - 1) {
                                    casillas[i].setValor(candidatos[j]);
                                    break;
                                }
                            }
                        }
                    }
                }
            }
        }
        
    }

    // divide en columnas una matriz, array de casilla que recibe como parámetro
    public Casilla[][] divideEnColumnas(Casilla[] casillas) {
        int cont = 0;
        Casilla[][] columnas = new Casilla[3][3];
        for (int i = 0; i < casillas.length; i++) {
            if (i < 3) {
                columnas[cont][0] = casillas[i];
            }
            if (i > 2 && i <= 5) {
                columnas[cont][1] = casillas[i];
            }
            if (i >= 5) {
                columnas[cont][2] = casillas[i];
            }

            cont++;
            if (cont == 3) {
                cont = 0;
            }
        }
        return columnas;

    }
 // comprueba si el valor pasado como parametro está en una sola columna como candidato
    // de la matriz pasada como parámetro(array de casillas)
    public int candidatoEnUnaSolaColumna(Casilla casillas[], int v) {

        //ArrayList<Integer> noSalidos = getValoresNoSalidos(casillas);
        Casilla[][] columnas = divideEnColumnas(casillas);
        int repetidos = 0;
        int numColumna = -1;

        for (int x = 0; x < columnas.length; x++) {

            boolean salidoEnFila = false;
            for (int y = 0; y < columnas[x].length; y++) {

                if (columnas[x][y].getValor() == 0) {

                    int[] candidatos = columnas[x][y].getCandidatos();

                    for (int c = 0; c < candidatos.length; c++) {
                        // si el candidato es igual al valor pasado como parámetro

                        if (candidatos[c] == v) {

                            repetidos++;
                            numColumna = x;
                            salidoEnFila = true;
                            break;
                        }
                    }
                    if (salidoEnFila) {
                        break;
                    }

                }

            }
        }
        if (repetidos == 1) {
         
            return numColumna;
        }

        return -1;

    }
   
    // comprueba si hay valores en una sola fila en las casillas
    public int[] buscaCandidatosEnUnaSolaColumna(Casilla casillas[], ArrayList<Integer> encontradoUnicaColumna) {
        ArrayList<Integer> noSalidos = getValoresNoSalidos(casillas);
        int columna = -1;
        for (int i = 0; i < noSalidos.size(); i++) {

            if (!encontradoUnicaColumna.contains(noSalidos.get(i))) {

                columna = candidatoEnUnaSolaColumna(casillas, noSalidos.get(i));

                if (columna > -1) {

                    // lo añade a la lista para evitar hacer las mismas comprbaciones innecesarias con este valor
                    encontradoUnicaColumna.add(noSalidos.get(i));

                    return new int[]{columna, noSalidos.get(i)};
                }
            }
        }
        return new int[]{-1};
    }

    // divide una matriz(array de casillas pasada como parámetro), en 3 filas que las devuelve en una matriz de enteros
    public Casilla[][] divideEnFilas(Casilla[] casillas) {
        int cont = 0;
        Casilla[][] filas = new Casilla[3][3];
        for (int i = 0; i < casillas.length; i++) {
            if (i < 3) {
                filas[0][cont] = casillas[i];
            }
            if (i > 2 && i <= 5) {
                filas[1][cont] = casillas[i];
            }
            if (i >= 5) {
                filas[2][cont] = casillas[i];
            }

            cont++;
            if (cont == 3) {
                cont = 0;
            }
        }
        return filas;
    }
    // regla lineas de candidatos
    public void eliminaCandidatosEnUnaSolaColumna(Matriz matriz[]) {
        boolean hecho = false;

        for (int i = 0; i < matriz.length; i++) {

            int[] vec = buscaCandidatosEnUnaSolaColumna(matriz[i].getCasillas(), matriz[i].getBuscadosEnColumnas());

            boolean salta = false;
            if (vec.length == 2) {
                salta = true;
                int numFila = vec[0];
                int candidato = vec[1];

                int ind = 0;

                if (i == 0 || i == 3 || i == 6) {
                    ind = 0;
                }

                if (i == 1 || i == 4 || i == 7) {
                    ind = 1;
                }
                if (i == 2 || i == 5 || i == 8) {
                    ind = 2;
                }

                for (int k = ind; k < 9; k = k + 3) {

                    if (k != i) {

                        if (!matriz[k].haSalido(candidato)) {

                            int cas = 0;

                            cas = numFila;

                            int ultimCas = 9;
                            for (int p = cas; p < ultimCas; p = p + 3) {
                                matriz[k].getCasillas()[p].eliminaCandidato(candidato);
                                hecho = true;

                            }
                            if (hecho) {
                                break;
                            }

                        }
                        if (hecho) {
                            break;
                        }
                    }
                    if (hecho) {
                        break;
                    }
                }
                if (hecho) {
                    break;
                }

            }
            if (hecho) {
                break;
            }

            if (salta) {
                break;
            }

            if (hecho) {
                break;
            }
        }
    }

    /**
     * COMPRUEBA SI EL PARÁMETRO v ESTÁ EN UNA ÚNICA FILA COMO CANDIDATO DENTRO
     * DE LA MATRIZ (ARRAY DE CASILLA RECIBIDO COMO PARÁMETRO) DEVUELVE EL
     * NUMERO DE FILA DONDE ESTÁ ÚNICAMENTE COMO CANDIDATO Ó .-1 SI EL VALOR NO
     * ESTÁ COMO CANDIDATO EN UNA ÚNICA FILA
     *
     *
     *
     */
    public int candidatoEnUnaSolaFila(Casilla casillas[], int v) {

        // filas de la matriz divididas en 3x3
        Casilla[][] filas = divideEnFilas(casillas);

        // contador
        int repetidos = 0;
        // se guardara el valor de la fila donde este el parametro int v equivalente a un candidato
        int numFila = -1;

        // se recorren las filas de la matriz
        for (int x = 0; x < filas.length; x++) {
            // controla que el candidato aparezca en una fila
            boolean salidoEnFila = false;
            for (int y = 0; y < filas[x].length; y++) {

                // si la casilla esta vacia
                if (filas[x][y].getValor() == 0) {

                    // lista de candidatos de la casilla
                    int[] candidatos = filas[x][y].getCandidatos();

                    // recorre candidatos de la casilla
                    for (int c = 0; c < candidatos.length; c++) {
                        // si el candidato es igual al parametro	
                        if (candidatos[c] == v) {
                            // incrementa contador
                            repetidos++;
                            // se guarda el numero de la fila donde aparece elcanddato
                            numFila = x;

                            salidoEnFila = true;
                            break;
                        }
                    }
                    // si el candidato aparece en una fila, pasa a la siguiente fila
                    if (salidoEnFila) {
                        break;
                    }

                }

            }

        }
        // si el candidato aparece en una sola fila exclusivamente
        if (repetidos == 1) {
            // retorna el numero de fila
            return numFila;
        }

        // resultado negativo operacion sin exito
        return -1;

    }

    // REGLA LINEASS DE CANDIDATOS APLICADO A FILAS
    public int[] buscaCandidatosEnUnaSolaFila(Casilla casillas[], ArrayList<Integer> encontradoUnicaFila) {

        // lista de valores que no han salido en la matriz
        ArrayList<Integer> noSalidos = getValoresNoSalidos(casillas);
        // se guarda el número de fila que retornará en caso de que haya un candidato en una sola fila
        int fila = -1;

        // recorre los valores no salidos en la matriz
        for (int i = 0; i < noSalidos.size(); i++) {

            // si el valor actual recorrdo no ha sido sufrido esta operación anteriormente
            if (!encontradoUnicaFila.contains(noSalidos.get(i))) {

                // obtiene el numero de fila donde solo esta ese candidato, ò -1 
                fila = candidatoEnUnaSolaFila(casillas, noSalidos.get(i));

                // si el candidato está en una sola fila
                if (fila > -1) {

                    // se añade el candidato a la lista(candidatos ya vistos)
                    encontradoUnicaFila.add(noSalidos.get(i));

                    // devuelve numero de fila y el candidato que esta solo en esa fila
                    return new int[]{fila, noSalidos.get(i)};
                }
            }
        }
        // devuelve resultado negativo (la operacion no ha tenido exito)
        return new int[]{-1};
    }

    // REGLA LINEAS DE CANDIDATOS APLICADO A FILAS
    public void eliminaCandidatosEnUnaSolaFila(Matriz matriz[]) {
        // controla que se haya realizado la operación en un valor con exito
        boolean hecho = false;

        // recorre matrices
        for (int i = 0; i < matriz.length; i++) {

            // guarda el numero de fila y valor a eliminar en esa fila o un -1
            int[] vec = buscaCandidatosEnUnaSolaFila(matriz[i].getCasillas(), matriz[i].getBuscadosEnFilas());
            // controla que haya algun candidato en una sola fila	
            boolean salta = false;

            // si en esta matriz hay un candidato unicamente en una fila
            if (vec.length == 2) {

                salta = true;
                // se guarda el numero de fila
                int numFila = vec[0];
                // se guarda el valor a eliminar
                int candidato = vec[1];

                // se guarda el inicia del idic de un bucle
                int ind = 0;

                // si el indice de la matriz que se esta comprobando en esta iteracio 
                // esta comprendido entre el 3 y el 5 ambos incluidos
                if (i > 2 && i < 6) {

                    ind = 3;
                }
                // si el indice de la matriz que se esta comprobando en esta iteracio 
                // es mayor de 5

                if (i > 5) {
                    ind = 6;
                }

                // final del recorrido del bucle
                int ultim = ind + 3;

                // recorrera la fila de matrizes 
                for (int k = ind; k < ultim; k++) {

                    // si la matriz que se esta recorriendo es diferente a la matriz donde hay un candidato en una sola fila
                    if (k != i) {
                        // si en la matriz no ha salido ese valor
                        if (!matriz[k].haSalido(candidato)) {

                            // se usa el mismo procedimiento
                            // guarda el indice de las casillas a recorrer
                            int cas = 0;

                            // si el numero de fila donde hay que eliminar el valor de la variable candidato
                            switch (numFila) {

                                case 1:
                                    cas = 3;
                                    break;
                                case 2:
                                    cas = 6;
                                    break;
                            }
                            // final del recorrido del bucle
                            int ultimCas = cas + 3;

                            // recorre las casillas de la fila donde tiene que eliminar el candidato c
                            for (int p = cas; p < ultimCas; p++) {

                                // elimina candidato de la casilla
                                matriz[k].getCasillas()[p].eliminaCandidato(candidato);
                                // si la operacion se ha realizado con exito se saldra del método
                                hecho = true;
                            }

                        }
                    }
                    if (hecho) {
                        break;
                    }
                }
                if (hecho) {
                    break;
                }

            }
            if (hecho) {
                break;
            }

            if (salta) {
                break;
            }

            if (hecho) {
                break;
            }
        }
    }

//devuelve la fila con mas completa
    public int[] getMatrizConMasCandidatos(Matriz[] c) {
        int lineaConMasCandidatos[] = new int[2];
        lineaConMasCandidatos[0] = 0;
        int mayor = 0;

        for (int i = 0; i < c.length; i++) {
            int mayorAux = getNumeroValoresSalidosEnLinea(c[i]);

            if (mayorAux > mayor) {
                mayor = mayorAux;
                lineaConMasCandidatos[0] = i;
            }

        }
        lineaConMasCandidatos[1] = mayor;
        return lineaConMasCandidatos;
    }

// devuelve la fila con mas completa
    public int[] getLineaConMasCandidatos(Casilla[][] c) {
        int lineaConMasCandidatos[] = new int[2];
        lineaConMasCandidatos[0] = 0;
        int mayor = 0;

        for (int i = 0; i < c.length; i++) {
            int mayorAux = getNumeroValoresSalidosEnLinea(c[i]);

            if (mayorAux > mayor) {
                mayor = mayorAux;
                lineaConMasCandidatos[0] = i;
            }

        }
        lineaConMasCandidatos[1] = mayor;
        return lineaConMasCandidatos;
    }

    // devuelve el numero de valores ya salidos en una linea
    public int getNumeroValoresSalidosEnLinea(Casilla casillas[]) {
        int numeroSalidos = 0;

        for (int i = 0; i < casillas.length; i++) {
            if (casillas[i].getValor() > 0) {
                numeroSalidos++;
            }
        }
        return numeroSalidos;

    }

    // devuelve el numero de valores ya salidos en una matriz
    public int getNumeroValoresSalidosEnLinea(Matriz casillas) {
        int numeroSalidos = 0;

        for (int i = 0; i < casillas.getCasillas().length; i++) {
            if (casillas.getCasillas()[i].getValor() > 0) {
                numeroSalidos++;
            }
        }
        return numeroSalidos;

    }
    // NO SE USA

    public int[] getLineasConMenosCandidatos(Casilla casillas[][]) {
        int filaConMenosCandidatos[] = new int[2];
        filaConMenosCandidatos[0] = 0;
        int menor = 10;
        for (int i = 0; i < casillas.length; i++) {
            int aux = getNumeroCandidatos(casillas[i]);
            if (aux < menor) {
                filaConMenosCandidatos[0] = i;
                menor = aux;
            }
        }
        filaConMenosCandidatos[1] = menor;

        return filaConMenosCandidatos;

    }

    // devuelve numero de candidatos de una linea
    public int getNumeroCandidatos(Casilla casillas[]) {
        int cuenta = 0;
        for (int i = 0; i < casillas.length; i++) {
            cuenta = casillas[i].getCandidatosUnicamente().size() + cuenta;

        }
        return cuenta;
    }

    // NO SE USA
    public int[] getLineasConMenosCandidatos(Matriz casillas[]) {
        int filaConMenosCandidatos[] = new int[2];
        filaConMenosCandidatos[0] = 0;
        int menor = 10;
        for (int i = 0; i < casillas.length; i++) {
            int aux = getNumeroCandidatos(casillas[i]);
            if (aux < menor) {
                filaConMenosCandidatos[0] = i;
                menor = aux;
            }
        }
        filaConMenosCandidatos[1] = menor;
        return filaConMenosCandidatos;

    }

    // devuelve numero de candidatos de una linea
    public int getNumeroCandidatos(Matriz casillas) {
        int cuenta = 0;
        for (int i = 0; i < casillas.getCasillas().length; i++) {
            cuenta = casillas.getCasillas()[i].getCandidatosUnicamente().size() + cuenta;

        }
        return cuenta;
    }

    // NO SE USA
    public ArrayList<Integer> getCandidatosAEliminarPE(ArrayList<Integer> candidatos, ArrayList<String> cadenas, String cadena) {
        ArrayList<Integer> salida = new ArrayList<Integer>();
        for (int i = 0; i < candidatos.size(); i++) {
            if (cadenas.get(i).equals(cadena)) {
                salida.add(candidatos.get(i));
            }
        }
        return salida;

    }

    // compara si alguna de las posiciones pasadas por parametro coincide
    // devuelve las posiciones donde estan las coincidencias
    public ArrayList<Integer> comparaPosicionesParejasTrioEscondidos(ArrayList<String> posiciones, ArrayList<Integer> cand) {

        int veces = 0;
        boolean encontrado = false;

        for (int i = 0; i < posiciones.size(); i++) {
            veces = 0;
            for (int j = i + 1; j < posiciones.size(); j++) {

                if (posiciones.get(j).equals(posiciones.get(i))) {
                    encontrado = true;

                    veces++;

                }

            }

            if (encontrado) {
                String[] split = posiciones.get(i).split("'");

                if (veces == split.length) {

                    return pasaAInteger(posiciones.get(i));

                }
            }

        }
        ArrayList<Integer> l = new ArrayList<Integer>();
        l.add(-1);

        return l;

    }

    // NO SE USA
    public ArrayList<Integer> pasaAInteger(String cadena) {

        String array[] = cadena.split(",");
        ArrayList<Integer> num = new ArrayList<Integer>();

        for (int i = 0; i < array.length; i++) {

            num.add(Integer.parseInt(array[i]));

        }
        return num;

    }

    // NO SE USA
    public String getPosicionesToString(ArrayList<Integer> lista) {
        String salida = "";
        for (int i = 0; i < lista.size(); i++) {
            salida += lista.get(i) + ",";
        }
        return salida;
    }

    // REGLA PAREJAS ESCONDIDAS
    public void parejasTriosEscondidas(Casilla casillas[]) {

        // crea una lista con los valores que quedan por salir en la línea
        ArrayList<Integer> valores = getValoresNoSalidos(casillas);
        // pasamos valores que no han salido en la linea
        for (int i = 0; i < valores.size(); i++) {
            // contador de coincidencia de posiciones donde encaja un valor
            int cuenta = 0;

            // lista donde se guardaran los valores a eliminar en las casillas donde los valores que se estan recorriendo en el bucle
            //no encajan
            ArrayList<Integer> valoresAEliminar = new ArrayList<Integer>();
            // lista donde se guardaran los valores a eliminar en las casillas donde ls valores que se estan recorriendo encajan
            ArrayList<Integer> parejas = new ArrayList<Integer>();

            // lista de posiciones donde encaja el valor que no ha salido en la matriz
            ArrayList<Integer> s1 = getPosicionesDondeEncaja(casillas, valores.get(i));

            // recorre de nuevo los valores que no han salido en la matriz
            for (int l = 0; l < valores.size(); l++) {
                // guarda posiciones donde encaja el valor qdel segundo bucle que no ha salido en la matriz todavia
                ArrayList<Integer> s2 = getPosicionesDondeEncaja(casillas, valores.get(l));

                // si las lista de posiciones donde encaja lo valores que no han salido en la matriz
                if (s1.equals(s2)) {

                    // se aumenta la cuenta
                    cuenta++;
                    // se añade el valor que no ha salido en la matriz del segundo bucle a la lista
                    // de vaores a eliminar fuera de las casilla donde no encaja este valor
                    parejas.add(valores.get(l));
                    //	coincidencia = true;
                } else {
                    // se añade el valor que no ha salido en la matriz del segundo bucle a la lista
                    // de vaores a eliminar dentro de las casilla donde no encaja este valor
                    valoresAEliminar.add(valores.get(l));
                }

            } // fin l

            if (cuenta == s1.size()) {

                // eliminan los candidatos de las casillas que estan fuera de las posiciones donde no hay parejas 
                for (int v : valoresAEliminar) {
                    // recorre posiciones
                    for (int p : s1) {
                        // si el candidato esta en la casilla
                        if (casillas[p].estaElCandidato(v)) {

                            // se elimina el candidato
                            casillas[p].eliminaCandidato(v);
                        }
                    }
                }
                // elimina los candidatos en las casillas donde hay parejas
                for (int v : parejas) {
                    for (int p : getValoresContrarios(s1)) {
                        if (casillas[p].estaElCandidato(v)) {

                            casillas[p].eliminaCandidato(v);
                        }
                    }
                }

            }

        }

    }

    // devuelve una lista de posiciones donde existe como candidato
    public ArrayList<Integer> getPosicionesDondeEncaja(Casilla casillas[], int v) {

        ArrayList<Integer> posiciones = new ArrayList<Integer>();

        // si hay mas de una casilla vacia en la línea
        if (getValoresNoSalidos(casillas).size() > 1) {

            // recorre las casilla de la linea
            for (int i = 0; i < casillas.length; i++) {
                // si estta vacía
                if (casillas[i].getValor() == 0) {
                    // si contiene como candidato el valor pasado como parametro	
                    if (casillas[i].estaElCandidato(v)) {

                        // añade a la lista la posicion de la casilla que contiene el mismo valor que falta por salir
                        posiciones.add(i);

                    }
                }

            }

        }
        return posiciones;

    }

    // compara si varios candidatos comparten las mismas casillas unicamente
    public String ComparaPosicionesigualesPE(ArrayList<String> posiciones) {

        int vecesRep = 0;

        ArrayList<Integer> candidatos = new ArrayList<Integer>();
        for (int i = 0; i < posiciones.size(); i++) {

            for (int k = i + 1; k < posiciones.size(); k++) {

                if (posiciones.get(i).equals(posiciones.get(k))) {

                    vecesRep++;

                }
            }

        }

        return null;
    }

    // devuelve 0,1,4,6,9 si la lista intr como parametro es 3,5,7,8
    public ArrayList<Integer> getValoresContrarios(ArrayList<Integer> lista) {

        ArrayList<Integer> ar = new ArrayList<Integer>();
        for (int i = 0; i < 9; i++) {
            ar.add(i);
        }

        for (int y = 0; y < lista.size(); y++) {

            for (int k = 0; k < ar.size(); k++) {
                if (ar.get(k) == lista.get(y)) {
                    ar.remove(k);
                }
            }

        }
        return ar;

    }

    // si hay 2,3,5,7 devuelve 1,4,6,8,9
    public ArrayList<Integer> getPosicionesAEliminarPE(ArrayList<Integer> lista) {

        int ar[] = new int[]{0, 1, 2, 3, 4, 5, 6, 7, 8};

        for (int i : ar) {

            for (int y = 0; y < lista.size(); y++) {
                if (lista.get(y) == i) {
                    ar[i] = 0;
                }
            }

        }

        ArrayList<Integer> salida = new ArrayList<Integer>();

        for (int i : ar) {
            if (i > 0) {
                salida.add(i);
            }
        }

        return salida;

    }

    /*
  	// devuelve los candidatos que ha en una linea
  	public ArrayList<Integer> getCandidatosEnUnaLinea(Casilla casillas[]){
  		ArrayList<Integer> comunes = new ArrayList<Integer>();
  		for(int i=0;i<casillas.length;i++){
  			if(casillas[i].getValor()==0){
  			
  			int can [] = casillas[i].getCandidatos();
  				
  			
  			for(int c = 0;c<can.length;c++){
  				
  				if(can[c]>0){
  					comunes.add(can[c]);
  				}
  				
  			}
  			
  			}
  		}
  		
  		return eliminaRepetidosArray(comunes);
  		
  		
  	}
     */
    // regla parejas desnudas(no se usa)
    public void reglaParejasDesnudas(Casilla casillas[]) {
        // si en la linea que se va a compara hay mas de dos casillas vacias entra
        if (getValoresNoSalidos(casillas).size() > 2) {
            ArrayList<Integer> posicionesABorrar = new ArrayList<Integer>();
            ArrayList<String> lista = new ArrayList<String>();
            // obtenemos los string de los candidatos en las casillas vacias
            boolean sal = false;
            for (int i = 0; i < casillas.length; i++) {

                if (casillas[i].getValor() == 0) {
                    posicionesABorrar = new ArrayList<Integer>();
                    String s1 = getPosicionesToString(casillas[i].getCandidatosUnicamente());
                    int cuenta = 0;
                    boolean coincide = false;
                    for (int z = 0; z < casillas.length; z++) {
                        if (casillas[z].getValor() == 0) {

                            String s2 = getPosicionesToString(casillas[z].getCandidatosUnicamente());

                            if (s1.equals(s2)) {
                                coincide = true;
                                cuenta++;
                            } else {
                                posicionesABorrar.add(z);
                            }

                        }
                    }
                    if (coincide) {
                        if (cuenta == casillas[i].getCandidatosUnicamente().size()) {
                     

                            // eliminamos los candidatos que ya no encajan de las casillas correspondientes

                            for (int o = 0; o < posicionesABorrar.size(); o++) {

                                if (casillas[posicionesABorrar.get(o)].getValor() == 0) {
                                    for (int l = 0; l < casillas[i].getCandidatosUnicamente().size(); l++) {
                                        if (casillas[posicionesABorrar.get(o)].estaElCandidato(casillas[i].getCandidatosUnicamente().get(l))) {
                                            casillas[posicionesABorrar.get(o)].eliminaCandidato(casillas[i].getCandidatosUnicamente().get(l));
                                            sal = true;
                                        }
                                    }
                                }

                            }

                        }
                    }
                   

                }
            }

        }
    }

    public void imprimeLinea(Casilla casillas[]) {
        for (int i = 0; i < casillas.length; i++) {
            System.out.println("casilla " + i);
            casillas[i].imprime();
        }
    }

    public void imprimeLista(ArrayList<Integer> lista) {
        for (int v : lista) {
            System.out.println(v);
        }
    }

    public boolean estaEnCasillas(Casilla[] casillas, int valor) {

        for (int i = 0; i < casillas.length; i++) {
            if (casillas[i].getValor() > 0) {
                if (casillas[i].getValor() == valor) {

                    return true;
                }
            }
        }
        return false;

    }

}
