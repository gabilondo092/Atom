/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package interfaz;

import java.awt.Color;
import java.awt.Image;
import java.awt.Toolkit;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import resuelve.sudokus.Principal;
import resuelve.sudokus.Sudoku;

/**
 * Clase que implementa la interfaz
 * @author Gabi
 */
public class Tablero extends javax.swing.JFrame {

     Principal resolv;

    // Listas que contienen los valores que no se pueden colocar en una casilla
    private ArrayList<Integer> prohibidosA0;
    private ArrayList<Integer> prohibidosA1;
    private ArrayList<Integer> prohibidosA2;
    private ArrayList<Integer> prohibidosA3;
    private ArrayList<Integer> prohibidosA4;
    private ArrayList<Integer> prohibidosA5;
    private ArrayList<Integer> prohibidosA6;
    private ArrayList<Integer> prohibidosA7;
    private ArrayList<Integer> prohibidosA8;

    private ArrayList<Integer> prohibidosB0;
    private ArrayList<Integer> prohibidosB1;
    private ArrayList<Integer> prohibidosB2;
    private ArrayList<Integer> prohibidosB3;
    private ArrayList<Integer> prohibidosB4;
    private ArrayList<Integer> prohibidosB5;
    private ArrayList<Integer> prohibidosB6;
    private ArrayList<Integer> prohibidosB7;
    private ArrayList<Integer> prohibidosB8;

    private ArrayList<Integer> prohibidosC0;
    private ArrayList<Integer> prohibidosC1;
    private ArrayList<Integer> prohibidosC2;
    private ArrayList<Integer> prohibidosC3;
    private ArrayList<Integer> prohibidosC4;
    private ArrayList<Integer> prohibidosC5;
    private ArrayList<Integer> prohibidosC6;
    private ArrayList<Integer> prohibidosC7;
    private ArrayList<Integer> prohibidosC8;

    private ArrayList<Integer> prohibidosD0;
    private ArrayList<Integer> prohibidosD1;
    private ArrayList<Integer> prohibidosD2;
    private ArrayList<Integer> prohibidosD3;
    private ArrayList<Integer> prohibidosD4;
    private ArrayList<Integer> prohibidosD5;
    private ArrayList<Integer> prohibidosD6;
    private ArrayList<Integer> prohibidosD7;
    private ArrayList<Integer> prohibidosD8;

    private ArrayList<Integer> prohibidosE0;
    private ArrayList<Integer> prohibidosE1;
    private ArrayList<Integer> prohibidosE2;
    private ArrayList<Integer> prohibidosE3;
    private ArrayList<Integer> prohibidosE4;
    private ArrayList<Integer> prohibidosE5;
    private ArrayList<Integer> prohibidosE6;
    private ArrayList<Integer> prohibidosE7;
    private ArrayList<Integer> prohibidosE8;

    private ArrayList<Integer> prohibidosF0;
    private ArrayList<Integer> prohibidosF1;
    private ArrayList<Integer> prohibidosF2;
    private ArrayList<Integer> prohibidosF3;
    private ArrayList<Integer> prohibidosF4;
    private ArrayList<Integer> prohibidosF5;
    private ArrayList<Integer> prohibidosF6;
    private ArrayList<Integer> prohibidosF7;
    private ArrayList<Integer> prohibidosF8;

    private ArrayList<Integer> prohibidosG0;
    private ArrayList<Integer> prohibidosG1;
    private ArrayList<Integer> prohibidosG2;
    private ArrayList<Integer> prohibidosG3;
    private ArrayList<Integer> prohibidosG4;
    private ArrayList<Integer> prohibidosG5;
    private ArrayList<Integer> prohibidosG6;
    private ArrayList<Integer> prohibidosG7;
    private ArrayList<Integer> prohibidosG8;

    private ArrayList<Integer> prohibidosH0;
    private ArrayList<Integer> prohibidosH1;
    private ArrayList<Integer> prohibidosH2;
    private ArrayList<Integer> prohibidosH3;
    private ArrayList<Integer> prohibidosH4;
    private ArrayList<Integer> prohibidosH5;
    private ArrayList<Integer> prohibidosH6;
    private ArrayList<Integer> prohibidosH7;
    private ArrayList<Integer> prohibidosH8;

    private ArrayList<Integer> prohibidosI0;
    private ArrayList<Integer> prohibidosI1;
    private ArrayList<Integer> prohibidosI2;
    private ArrayList<Integer> prohibidosI3;
    private ArrayList<Integer> prohibidosI4;
    private ArrayList<Integer> prohibidosI5;
    private ArrayList<Integer> prohibidosI6;
    private ArrayList<Integer> prohibidosI7;
    private ArrayList<Integer> prohibidosI8;

    /**
     * Creates new form Tablero
     */
    public Tablero() {
        initComponents();
        imgCargando.setVisible(false);
        //btnResolver.enable(false);
        btnParar.setVisible(false);
        cambiaColorTextoAzul();

    }

    public javax.swing.JLabel getimgCargando() {
        return imgCargando;
    }

    public javax.swing.JButton getBtnParar() {
        return btnParar;
    }

    public boolean hayValores() {

        int valores[][] = recojeValores();

        for (int ar[] : valores) {

            for (int v : ar) {

                if (v != 0) {
                    return false;
                }
            }

        }
        return true;

    }

    public void bloqueBoton() {
        if (hayValores()) {
            btnResolver.setEnabled(false);

        } else {
            btnResolver.setEnabled(true);
        }
    }

    // invisiviliza los componentes  visuales que son interactuables con el usuario
    // se usa antes de comenzar el proceso de resolver
    public void desactivarBotones() {

        btnResolver.setVisible(false);
        btnLimpiar.setVisible(false);
        //btnGenerar.setVisible(false);
//         btnGenerar.setVisible(false);     
        a0.setVisible(false);
        a1.setVisible(false);
        a2.setVisible(false);
        a3.setVisible(false);
        a4.setVisible(false);
        a5.setVisible(false);
        a6.setVisible(false);
        a7.setVisible(false);
        a8.setVisible(false);

        b0.setVisible(false);
        b1.setVisible(false);
        b2.setVisible(false);
        b3.setVisible(false);
        b4.setVisible(false);
        b5.setVisible(false);
        b6.setVisible(false);
        b7.setVisible(false);
        b8.setVisible(false);

        c0.setVisible(false);
        c1.setVisible(false);
        c2.setVisible(false);
        c3.setVisible(false);
        c4.setVisible(false);
        c5.setVisible(false);
        c6.setVisible(false);
        c7.setVisible(false);
        c8.setVisible(false);

        d0.setVisible(false);
        d1.setVisible(false);
        d2.setVisible(false);
        d3.setVisible(false);
        d4.setVisible(false);
        d5.setVisible(false);
        d6.setVisible(false);
        d7.setVisible(false);
        d8.setVisible(false);

        e0.setVisible(false);
        e1.setVisible(false);
        e2.setVisible(false);
        e3.setVisible(false);
        e4.setVisible(false);
        e5.setVisible(false);
        e6.setVisible(false);
        e7.setVisible(false);
        e8.setVisible(false);

        f0.setVisible(false);
        f1.setVisible(false);
        f2.setVisible(false);
        f3.setVisible(false);
        f4.setVisible(false);
        f5.setVisible(false);
        f6.setVisible(false);
        f7.setVisible(false);
        f8.setVisible(false);

        g0.setVisible(false);
        g1.setVisible(false);
        g2.setVisible(false);
        g3.setVisible(false);
        g4.setVisible(false);
        g5.setVisible(false);
        g6.setVisible(false);
        g7.setVisible(false);
        g8.setVisible(false);

        h0.setVisible(false);
        h1.setVisible(false);
        h2.setVisible(false);
        h3.setVisible(false);
        h4.setVisible(false);
        h5.setVisible(false);
        h6.setVisible(false);
        h7.setVisible(false);
        h8.setVisible(false);

        i0.setVisible(false);
        i1.setVisible(false);
        i2.setVisible(false);
        i3.setVisible(false);
        i4.setVisible(false);
        i5.setVisible(false);
        i6.setVisible(false);
        i7.setVisible(false);
        i8.setVisible(false);
        lblFondoNegro.setVisible(false);
    }

    // visibiliza los componentes interactuables con el usuario
    // se usa cuando ha terminado el proceso de resolver el sudoku
    public void activaBotones() {

        btnResolver.setVisible(true);
        btnLimpiar.setVisible(true);
        //  btnGenerar.setVisible(true);  
        a0.setVisible(true);
        a1.setVisible(true);
        a2.setVisible(true);
        a3.setVisible(true);
        a4.setVisible(true);
        a5.setVisible(true);
        a6.setVisible(true);
        a7.setVisible(true);
        a8.setVisible(true);

        b0.setVisible(true);
        b1.setVisible(true);
        b2.setVisible(true);
        b3.setVisible(true);
        b4.setVisible(true);
        b5.setVisible(true);
        b6.setVisible(true);
        b7.setVisible(true);
        b8.setVisible(true);

        c0.setVisible(true);
        c1.setVisible(true);
        c2.setVisible(true);
        c3.setVisible(true);
        c4.setVisible(true);
        c5.setVisible(true);
        c6.setVisible(true);
        c7.setVisible(true);
        c8.setVisible(true);

        d0.setVisible(true);
        d1.setVisible(true);
        d2.setVisible(true);
        d3.setVisible(true);
        d4.setVisible(true);
        d5.setVisible(true);
        d6.setVisible(true);
        d7.setVisible(true);
        d8.setVisible(true);

        e0.setVisible(true);
        e1.setVisible(true);
        e2.setVisible(true);
        e3.setVisible(true);
        e4.setVisible(true);
        e5.setVisible(true);
        e6.setVisible(true);
        e7.setVisible(true);
        e8.setVisible(true);

        f0.setVisible(true);
        f1.setVisible(true);
        f2.setVisible(true);
        f3.setVisible(true);
        f4.setVisible(true);
        f5.setVisible(true);
        f6.setVisible(true);
        f7.setVisible(true);
        f8.setVisible(true);

        g0.setVisible(true);
        g1.setVisible(true);
        g2.setVisible(true);
        g3.setVisible(true);
        g4.setVisible(true);
        g5.setVisible(true);
        g6.setVisible(true);
        g7.setVisible(true);
        g8.setVisible(true);

        h0.setVisible(true);
        h1.setVisible(true);
        h2.setVisible(true);
        h3.setVisible(true);
        h4.setVisible(true);
        h5.setVisible(true);
        h6.setVisible(true);
        h7.setVisible(true);
        h8.setVisible(true);

        i0.setVisible(true);
        i1.setVisible(true);
        i2.setVisible(true);
        i3.setVisible(true);
        i4.setVisible(true);
        i5.setVisible(true);
        i6.setVisible(true);
        i7.setVisible(true);
        i8.setVisible(true);
        lblFondoNegro.setVisible(true);
    }

    // elimina los numero de las cajas de texto
    // se ejecuta al hacer click en el botón resolver
    public void limpiarSudoku() {
        a0.setText("");
        a1.setText("");
        a2.setText("");
        a3.setText("");
        a4.setText("");
        a5.setText("");
        a6.setText("");
        a7.setText("");
        a8.setText("");

        b0.setText("");
        b1.setText("");
        b2.setText("");
        b3.setText("");
        b4.setText("");
        b5.setText("");
        b6.setText("");
        b7.setText("");
        b8.setText("");

        c0.setText("");
        c1.setText("");
        c2.setText("");
        c3.setText("");
        c4.setText("");
        c5.setText("");
        c6.setText("");
        c7.setText("");
        c8.setText("");

        d0.setText("");
        d1.setText("");
        d2.setText("");
        d3.setText("");
        d4.setText("");
        d5.setText("");
        d6.setText("");
        d7.setText("");
        d8.setText("");

        e0.setText("");
        e1.setText("");
        e2.setText("");
        e3.setText("");
        e4.setText("");
        e5.setText("");
        e6.setText("");
        e7.setText("");
        e8.setText("");

        f0.setText("");
        f1.setText("");
        f2.setText("");
        f3.setText("");
        f4.setText("");
        f5.setText("");
        f6.setText("");
        f7.setText("");
        f8.setText("");

        g0.setText("");
        g1.setText("");
        g2.setText("");
        g3.setText("");
        g4.setText("");
        g5.setText("");
        g6.setText("");
        g7.setText("");
        g8.setText("");

        h0.setText("");
        h1.setText("");
        h2.setText("");
        h3.setText("");
        h4.setText("");
        h5.setText("");
        h6.setText("");
        h7.setText("");
        h8.setText("");

        i0.setText("");
        i1.setText("");
        i2.setText("");
        i3.setText("");
        i4.setText("");
        i5.setText("");
        i6.setText("");
        i7.setText("");
        i8.setText("");
    }

    // impide que entren carácteres no deseados en las casillas
    private void validaCasillas(javax.swing.JTextField casilla, java.awt.event.KeyEvent evt) {

        char caracter = evt.getKeyChar();
     

        if (!Character.isDigit(caracter)) {
            evt.consume();
        } else {
            if (caracter == '0') {
                evt.consume();
            }
        }
        if (casilla.getText().length() > 0) {
            evt.consume();
        }

    }

    // impide que se introduzca un valor en la casilla que ya ha salido en la matriz, fila o columna a la que pertenece
    private void validaValoresSalidos(ArrayList<Integer> salidos, java.awt.event.KeyEvent evt) {
        char caracter = evt.getKeyChar();
        for (int i : salidos) {
            String salido = String.valueOf(i);
            if ((caracter + "").equals(salido)) {
                evt.consume();
            }

        }

    }

    public static void guardaEnLista(ArrayList<Integer> lista, int[] array) {

        for (int i = 0; i < array.length; i++) {

            if (array[i] != 0) {
                if (!lista.contains(array[i])) {
                    lista.add(array[i]);
                }
            }

        }

    }

    // devuelve una matriz de enteros con los corresponientes valores del sudoku
    public int[][] recojeValores() {

        int[][] valores = new int[9][9];

        valores[0][0] = a0.getText().length() > 0 ? Integer.parseInt(a0.getText()) : 0;
        valores[0][1] = a1.getText().length() > 0 ? Integer.parseInt(a1.getText()) : 0;
        valores[0][2] = a2.getText().length() > 0 ? Integer.parseInt(a2.getText()) : 0;
        valores[0][3] = a3.getText().length() > 0 ? Integer.parseInt(a3.getText()) : 0;
        valores[0][4] = a4.getText().length() > 0 ? Integer.parseInt(a4.getText()) : 0;
        valores[0][5] = a5.getText().length() > 0 ? Integer.parseInt(a5.getText()) : 0;
        valores[0][6] = a6.getText().length() > 0 ? Integer.parseInt(a6.getText()) : 0;
        valores[0][7] = a7.getText().length() > 0 ? Integer.parseInt(a7.getText()) : 0;
        valores[0][8] = a8.getText().length() > 0 ? Integer.parseInt(a8.getText()) : 0;

        // matriz 1
        valores[1][0] = b0.getText().length() > 0 ? Integer.parseInt(b0.getText()) : 0;
        valores[1][1] = b1.getText().length() > 0 ? Integer.parseInt(b1.getText()) : 0;
        valores[1][2] = b2.getText().length() > 0 ? Integer.parseInt(b2.getText()) : 0;
        valores[1][3] = b3.getText().length() > 0 ? Integer.parseInt(b3.getText()) : 0;
        valores[1][4] = b4.getText().length() > 0 ? Integer.parseInt(b4.getText()) : 0;
        valores[1][5] = b5.getText().length() > 0 ? Integer.parseInt(b5.getText()) : 0;
        valores[1][6] = b6.getText().length() > 0 ? Integer.parseInt(b6.getText()) : 0;
        valores[1][7] = b7.getText().length() > 0 ? Integer.parseInt(b7.getText()) : 0;
        valores[1][8] = b8.getText().length() > 0 ? Integer.parseInt(b8.getText()) : 0;

        // matriz 2
        valores[2][0] = c0.getText().length() > 0 ? Integer.parseInt(c0.getText()) : 0;
        valores[2][1] = c1.getText().length() > 0 ? Integer.parseInt(c1.getText()) : 0;
        valores[2][2] = c2.getText().length() > 0 ? Integer.parseInt(c2.getText()) : 0;
        valores[2][3] = c3.getText().length() > 0 ? Integer.parseInt(c3.getText()) : 0;
        valores[2][4] = c4.getText().length() > 0 ? Integer.parseInt(c4.getText()) : 0;
        valores[2][5] = c5.getText().length() > 0 ? Integer.parseInt(c5.getText()) : 0;
        valores[2][6] = c6.getText().length() > 0 ? Integer.parseInt(c6.getText()) : 0;
        valores[2][7] = c7.getText().length() > 0 ? Integer.parseInt(c7.getText()) : 0;
        valores[2][8] = c8.getText().length() > 0 ? Integer.parseInt(c8.getText()) : 0;

        // matriz 3
        valores[3][0] = d0.getText().length() > 0 ? Integer.parseInt(d0.getText()) : 0;
        valores[3][1] = d1.getText().length() > 0 ? Integer.parseInt(d1.getText()) : 0;
        valores[3][2] = d2.getText().length() > 0 ? Integer.parseInt(d2.getText()) : 0;
        valores[3][3] = d3.getText().length() > 0 ? Integer.parseInt(d3.getText()) : 0;
        valores[3][4] = d4.getText().length() > 0 ? Integer.parseInt(d4.getText()) : 0;
        valores[3][5] = d5.getText().length() > 0 ? Integer.parseInt(d5.getText()) : 0;
        valores[3][6] = d6.getText().length() > 0 ? Integer.parseInt(d6.getText()) : 0;
        valores[3][7] = d7.getText().length() > 0 ? Integer.parseInt(d7.getText()) : 0;
        valores[3][8] = d8.getText().length() > 0 ? Integer.parseInt(d8.getText()) : 0;

        // matriz 4
        valores[4][0] = e0.getText().length() > 0 ? Integer.parseInt(e0.getText()) : 0;
        valores[4][1] = e1.getText().length() > 0 ? Integer.parseInt(e1.getText()) : 0;
        valores[4][2] = e2.getText().length() > 0 ? Integer.parseInt(e2.getText()) : 0;
        valores[4][3] = e3.getText().length() > 0 ? Integer.parseInt(e3.getText()) : 0;
        valores[4][4] = e4.getText().length() > 0 ? Integer.parseInt(e4.getText()) : 0;
        valores[4][5] = e5.getText().length() > 0 ? Integer.parseInt(e5.getText()) : 0;
        valores[4][6] = e6.getText().length() > 0 ? Integer.parseInt(e6.getText()) : 0;
        valores[4][7] = e7.getText().length() > 0 ? Integer.parseInt(e7.getText()) : 0;
        valores[4][8] = e8.getText().length() > 0 ? Integer.parseInt(e8.getText()) : 0;

        // matriz 5
        valores[5][0] = f0.getText().length() > 0 ? Integer.parseInt(f0.getText()) : 0;
        valores[5][1] = f1.getText().length() > 0 ? Integer.parseInt(f1.getText()) : 0;
        valores[5][2] = f2.getText().length() > 0 ? Integer.parseInt(f2.getText()) : 0;
        valores[5][3] = f3.getText().length() > 0 ? Integer.parseInt(f3.getText()) : 0;
        valores[5][4] = f4.getText().length() > 0 ? Integer.parseInt(f4.getText()) : 0;
        valores[5][5] = f5.getText().length() > 0 ? Integer.parseInt(f5.getText()) : 0;
        valores[5][6] = f6.getText().length() > 0 ? Integer.parseInt(f6.getText()) : 0;
        valores[5][7] = f7.getText().length() > 0 ? Integer.parseInt(f7.getText()) : 0;
        valores[5][8] = f8.getText().length() > 0 ? Integer.parseInt(f8.getText()) : 0;

        // matriz 6
        valores[6][0] = g0.getText().length() > 0 ? Integer.parseInt(g0.getText()) : 0;
        valores[6][1] = g1.getText().length() > 0 ? Integer.parseInt(g1.getText()) : 0;
        valores[6][2] = g2.getText().length() > 0 ? Integer.parseInt(g2.getText()) : 0;
        valores[6][3] = g3.getText().length() > 0 ? Integer.parseInt(g3.getText()) : 0;
        valores[6][4] = g4.getText().length() > 0 ? Integer.parseInt(g4.getText()) : 0;
        valores[6][5] = g5.getText().length() > 0 ? Integer.parseInt(g5.getText()) : 0;
        valores[6][6] = g6.getText().length() > 0 ? Integer.parseInt(g6.getText()) : 0;
        valores[6][7] = g7.getText().length() > 0 ? Integer.parseInt(g7.getText()) : 0;
        valores[6][8] = g8.getText().length() > 0 ? Integer.parseInt(g8.getText()) : 0;

        // matriz 7
        valores[7][0] = h0.getText().length() > 0 ? Integer.parseInt(h0.getText()) : 0;
        valores[7][1] = h1.getText().length() > 0 ? Integer.parseInt(h1.getText()) : 0;
        valores[7][2] = h2.getText().length() > 0 ? Integer.parseInt(h2.getText()) : 0;
        valores[7][3] = h3.getText().length() > 0 ? Integer.parseInt(h3.getText()) : 0;
        valores[7][4] = h4.getText().length() > 0 ? Integer.parseInt(h4.getText()) : 0;
        valores[7][5] = h5.getText().length() > 0 ? Integer.parseInt(h5.getText()) : 0;
        valores[7][6] = h6.getText().length() > 0 ? Integer.parseInt(h6.getText()) : 0;
        valores[7][7] = h7.getText().length() > 0 ? Integer.parseInt(h7.getText()) : 0;
        valores[7][8] = h8.getText().length() > 0 ? Integer.parseInt(h8.getText()) : 0;

        // matriz 8
        valores[8][0] = i0.getText().length() > 0 ? Integer.parseInt(i0.getText()) : 0;
        valores[8][1] = i1.getText().length() > 0 ? Integer.parseInt(i1.getText()) : 0;
        valores[8][2] = i2.getText().length() > 0 ? Integer.parseInt(i2.getText()) : 0;
        valores[8][3] = i3.getText().length() > 0 ? Integer.parseInt(i3.getText()) : 0;
        valores[8][4] = i4.getText().length() > 0 ? Integer.parseInt(i4.getText()) : 0;
        valores[8][5] = i5.getText().length() > 0 ? Integer.parseInt(i5.getText()) : 0;
        valores[8][6] = i6.getText().length() > 0 ? Integer.parseInt(i6.getText()) : 0;
        valores[8][7] = i7.getText().length() > 0 ? Integer.parseInt(i7.getText()) : 0;
        valores[8][8] = i8.getText().length() > 0 ? Integer.parseInt(i8.getText()) : 0;

        return valores;
    }

    public void validaNumeroSalido() {

        javax.swing.JTextField casillas[][] = new javax.swing.JTextField[9][9];

        String s = a0.getName();

        // casillas[0][0] = a0;
    }

    // cambia el color del texto de las casillas a azul
    // se usa al introducir valores, para distinguir los de entrada de los de salida
    public void cambiaColorTextoAzul() {

        a0.setForeground(Color.BLUE);
        a1.setForeground(Color.BLUE);
        a2.setForeground(Color.BLUE);
        a3.setForeground(Color.BLUE);
        a4.setForeground(Color.BLUE);
        a5.setForeground(Color.BLUE);
        a6.setForeground(Color.BLUE);
        a7.setForeground(Color.BLUE);
        a8.setForeground(Color.BLUE);

        b0.setForeground(Color.BLUE);
        b1.setForeground(Color.BLUE);
        b2.setForeground(Color.BLUE);
        b3.setForeground(Color.BLUE);
        b4.setForeground(Color.BLUE);
        b5.setForeground(Color.BLUE);
        b6.setForeground(Color.BLUE);
        b7.setForeground(Color.BLUE);
        b8.setForeground(Color.BLUE);

        c0.setForeground(Color.BLUE);
        c1.setForeground(Color.BLUE);
        c2.setForeground(Color.BLUE);
        c3.setForeground(Color.BLUE);
        c4.setForeground(Color.BLUE);
        c5.setForeground(Color.BLUE);
        c6.setForeground(Color.BLUE);
        c7.setForeground(Color.BLUE);
        c8.setForeground(Color.BLUE);

        d0.setForeground(Color.BLUE);
        d1.setForeground(Color.BLUE);
        d2.setForeground(Color.BLUE);
        d3.setForeground(Color.BLUE);
        d4.setForeground(Color.BLUE);
        d5.setForeground(Color.BLUE);
        d6.setForeground(Color.BLUE);
        d7.setForeground(Color.BLUE);
        d8.setForeground(Color.BLUE);

        e0.setForeground(Color.BLUE);
        e1.setForeground(Color.BLUE);
        e2.setForeground(Color.BLUE);
        e3.setForeground(Color.BLUE);
        e4.setForeground(Color.BLUE);
        e5.setForeground(Color.BLUE);
        e6.setForeground(Color.BLUE);
        e7.setForeground(Color.BLUE);
        e8.setForeground(Color.BLUE);

        f0.setForeground(Color.BLUE);
        f1.setForeground(Color.BLUE);
        f2.setForeground(Color.BLUE);
        f3.setForeground(Color.BLUE);
        f4.setForeground(Color.BLUE);
        f5.setForeground(Color.BLUE);
        f6.setForeground(Color.BLUE);
        f7.setForeground(Color.BLUE);
        f8.setForeground(Color.BLUE);

        g0.setForeground(Color.BLUE);
        g1.setForeground(Color.BLUE);
        g2.setForeground(Color.BLUE);
        g3.setForeground(Color.BLUE);
        g4.setForeground(Color.BLUE);
        g5.setForeground(Color.BLUE);
        g6.setForeground(Color.BLUE);
        g7.setForeground(Color.BLUE);
        g8.setForeground(Color.BLUE);

        h0.setForeground(Color.BLUE);
        h1.setForeground(Color.BLUE);
        h2.setForeground(Color.BLUE);
        h3.setForeground(Color.BLUE);
        h4.setForeground(Color.BLUE);
        h5.setForeground(Color.BLUE);
        h6.setForeground(Color.BLUE);
        h7.setForeground(Color.BLUE);
        h8.setForeground(Color.BLUE);

        i0.setForeground(Color.BLUE);
        i1.setForeground(Color.BLUE);
        i2.setForeground(Color.BLUE);
        i3.setForeground(Color.BLUE);
        i4.setForeground(Color.BLUE);
        i5.setForeground(Color.BLUE);
        i6.setForeground(Color.BLUE);
        i7.setForeground(Color.BLUE);
        i8.setForeground(Color.BLUE);

    }

    
    // cambia el color del texto de las casillas que están vacías a negro
    // se al ejecutar el evento click del botón resolver, estó hace
    // que los valores de salida se pinten de negro y se distinguen de los valores de entrada
    public void cambiaColorTextoNegro() {

        if (a0.getText().length() == 0) {
            a0.setForeground(Color.BLACK);
        }
        if (a1.getText().length() == 0) {
            a1.setForeground(Color.BLACK);
        }
        if (a2.getText().length() == 0) {
            a2.setForeground(Color.BLACK);
        }
        if (a3.getText().length() == 0) {
            a3.setForeground(Color.BLACK);
        }
        if (a4.getText().length() == 0) {
            a4.setForeground(Color.BLACK);
        }
        if (a5.getText().length() == 0) {
            a5.setForeground(Color.BLACK);
        }
        if (a6.getText().length() == 0) {
            a6.setForeground(Color.BLACK);
        }
        if (a7.getText().length() == 0) {
            a7.setForeground(Color.BLACK);
        }
        if (a8.getText().length() == 0) {
            a8.setForeground(Color.BLACK);
        }

        if (b0.getText().length() == 0) {
            b0.setForeground(Color.BLACK);
        }
        if (b1.getText().length() == 0) {
            b1.setForeground(Color.BLACK);
        }
        if (b2.getText().length() == 0) {
            b2.setForeground(Color.BLACK);
        }
        if (b3.getText().length() == 0) {
            b3.setForeground(Color.BLACK);
        }
        if (b4.getText().length() == 0) {
            b4.setForeground(Color.BLACK);
        }
        if (b5.getText().length() == 0) {
            b5.setForeground(Color.BLACK);
        }
        if (b6.getText().length() == 0) {
            b6.setForeground(Color.BLACK);
        }
        if (b7.getText().length() == 0) {
            b7.setForeground(Color.BLACK);
        }
        if (b8.getText().length() == 0) {
            b8.setForeground(Color.BLACK);
        }

        if (c0.getText().length() == 0) {
            c0.setForeground(Color.BLACK);
        }
        if (c1.getText().length() == 0) {
            c1.setForeground(Color.BLACK);
        }
        if (c2.getText().length() == 0) {
            c2.setForeground(Color.BLACK);
        }
        if (c3.getText().length() == 0) {
            c3.setForeground(Color.BLACK);
        }
        if (c4.getText().length() == 0) {
            c4.setForeground(Color.BLACK);
        }
        if (c5.getText().length() == 0) {
            c5.setForeground(Color.BLACK);
        }
        if (c6.getText().length() == 0) {
            c6.setForeground(Color.BLACK);
        }
        if (c7.getText().length() == 0) {
            c7.setForeground(Color.BLACK);
        }
        if (c8.getText().length() == 0) {
            c8.setForeground(Color.BLACK);
        }

        if (d0.getText().length() == 0) {
            d0.setForeground(Color.BLACK);
        }
        if (d1.getText().length() == 0) {
            d1.setForeground(Color.BLACK);
        }
        if (d2.getText().length() == 0) {
            d2.setForeground(Color.BLACK);
        }
        if (d3.getText().length() == 0) {
            d3.setForeground(Color.BLACK);
        }
        if (d4.getText().length() == 0) {
            d4.setForeground(Color.BLACK);
        }
        if (d5.getText().length() == 0) {
            d5.setForeground(Color.BLACK);
        }
        if (d6.getText().length() == 0) {
            d6.setForeground(Color.BLACK);
        }
        if (d7.getText().length() == 0) {
            d7.setForeground(Color.BLACK);
        }
        if (d8.getText().length() == 0) {
            d8.setForeground(Color.BLACK);
        }

        if (e0.getText().length() == 0) {
            e0.setForeground(Color.BLACK);
        }
        if (e1.getText().length() == 0) {
            e1.setForeground(Color.BLACK);
        }
        if (e2.getText().length() == 0) {
            e2.setForeground(Color.BLACK);
        }
        if (e3.getText().length() == 0) {
            e3.setForeground(Color.BLACK);
        }
        if (e4.getText().length() == 0) {
            e4.setForeground(Color.BLACK);
        }
        if (e5.getText().length() == 0) {
            e5.setForeground(Color.BLACK);
        }
        if (e6.getText().length() == 0) {
            e6.setForeground(Color.BLACK);
        }
        if (e7.getText().length() == 0) {
            e7.setForeground(Color.BLACK);
        }
        if (e8.getText().length() == 0) {
            e8.setForeground(Color.BLACK);
        }

        if (f0.getText().length() == 0) {
            f0.setForeground(Color.BLACK);
        }
        if (f1.getText().length() == 0) {
            f1.setForeground(Color.BLACK);
        }
        if (f2.getText().length() == 0) {
            f2.setForeground(Color.BLACK);
        }
        if (f3.getText().length() == 0) {
            f3.setForeground(Color.BLACK);
        }
        if (f4.getText().length() == 0) {
            f4.setForeground(Color.BLACK);
        }
        if (f5.getText().length() == 0) {
            f5.setForeground(Color.BLACK);
        }
        if (f6.getText().length() == 0) {
            f6.setForeground(Color.BLACK);
        }
        if (f7.getText().length() == 0) {
            f7.setForeground(Color.BLACK);
        }
        if (f8.getText().length() == 0) {
            f8.setForeground(Color.BLACK);
        }

        if (g0.getText().length() == 0) {
            g0.setForeground(Color.BLACK);
        }
        if (g1.getText().length() == 0) {
            g1.setForeground(Color.BLACK);
        }
        if (g2.getText().length() == 0) {
            g2.setForeground(Color.BLACK);
        }
        if (g3.getText().length() == 0) {
            g3.setForeground(Color.BLACK);
        }
        if (g4.getText().length() == 0) {
            g4.setForeground(Color.BLACK);
        }
        if (g5.getText().length() == 0) {
            g5.setForeground(Color.BLACK);
        }
        if (g6.getText().length() == 0) {
            g6.setForeground(Color.BLACK);
        }
        if (g7.getText().length() == 0) {
            g7.setForeground(Color.BLACK);
        }
        if (g8.getText().length() == 0) {
            g8.setForeground(Color.BLACK);
        }

        if (h0.getText().length() == 0) {
            h0.setForeground(Color.BLACK);
        }
        if (h1.getText().length() == 0) {
            h1.setForeground(Color.BLACK);
        }
        if (h2.getText().length() == 0) {
            h2.setForeground(Color.BLACK);
        }
        if (h3.getText().length() == 0) {
            h3.setForeground(Color.BLACK);
        }
        if (h4.getText().length() == 0) {
            h4.setForeground(Color.BLACK);
        }
        if (h5.getText().length() == 0) {
            h5.setForeground(Color.BLACK);
        }
        if (h6.getText().length() == 0) {
            h6.setForeground(Color.BLACK);
        }
        if (h7.getText().length() == 0) {
            h7.setForeground(Color.BLACK);
        }
        if (h8.getText().length() == 0) {
            h8.setForeground(Color.BLACK);
        }

        if (i0.getText().length() == 0) {
            i0.setForeground(Color.BLACK);
        }
        if (i1.getText().length() == 0) {
            i1.setForeground(Color.BLACK);
        }
        if (i2.getText().length() == 0) {
            i2.setForeground(Color.BLACK);
        }
        if (i3.getText().length() == 0) {
            i3.setForeground(Color.BLACK);
        }
        if (i4.getText().length() == 0) {
            i4.setForeground(Color.BLACK);
        }
        if (i5.getText().length() == 0) {
            i5.setForeground(Color.BLACK);
        }
        if (i6.getText().length() == 0) {
            i6.setForeground(Color.BLACK);
        }
        if (i7.getText().length() == 0) {
            i7.setForeground(Color.BLACK);
        }
        if (i8.getText().length() == 0) {
            i8.setForeground(Color.BLACK);
        }

        /* 
        i0.setForeground(Color.BLUE);
        i1.setForeground(Color.BLUE);
        i2.setForeground(Color.BLUE);
        i3.setForeground(Color.BLUE);
        i4.setForeground(Color.BLUE);
        i5.setForeground(Color.BLUE);
        i6.setForeground(Color.BLUE);
        i7.setForeground(Color.BLUE);
        i8.setForeground(Color.BLUE);
         */
    }

    // cambia los valores del tablero por los del sudoku ya resuelto
    // se usa cuado el sudoku se ha resuelto
    public void cambiaValores(Sudoku s) {

        // para controlar que no entre un cero, se usa if else ternario
        a0.setText(s.getMatrizes()[0].getCasillas()[0].getValor() == 0 ? "" : s.getMatrizes()[0].getCasillas()[0].getValor() + "");
        a1.setText(s.getMatrizes()[0].getCasillas()[1].getValor() == 0 ? "" : s.getMatrizes()[0].getCasillas()[1].getValor() + "");
        a2.setText(s.getMatrizes()[0].getCasillas()[2].getValor() == 0 ? "" : s.getMatrizes()[0].getCasillas()[2].getValor() + "");
        a3.setText(s.getMatrizes()[0].getCasillas()[3].getValor() == 0 ? "" : s.getMatrizes()[0].getCasillas()[3].getValor() + "");
        a4.setText(s.getMatrizes()[0].getCasillas()[4].getValor() == 0 ? "" : s.getMatrizes()[0].getCasillas()[4].getValor() + "");
        a5.setText(s.getMatrizes()[0].getCasillas()[5].getValor() == 0 ? "" : s.getMatrizes()[0].getCasillas()[5].getValor() + "");
        a6.setText(s.getMatrizes()[0].getCasillas()[6].getValor() == 0 ? "" : s.getMatrizes()[0].getCasillas()[6].getValor() + "");
        a7.setText(s.getMatrizes()[0].getCasillas()[7].getValor() == 0 ? "" : s.getMatrizes()[0].getCasillas()[7].getValor() + "");
        a8.setText(s.getMatrizes()[0].getCasillas()[8].getValor() == 0 ? "" : s.getMatrizes()[0].getCasillas()[8].getValor() + "");

        //---
        b0.setText(s.getMatrizes()[1].getCasillas()[0].getValor() + "");
        b1.setText(s.getMatrizes()[1].getCasillas()[1].getValor() + "");
        b2.setText(s.getMatrizes()[1].getCasillas()[2].getValor() + "");
        b3.setText(s.getMatrizes()[1].getCasillas()[3].getValor() + "");
        b4.setText(s.getMatrizes()[1].getCasillas()[4].getValor() + "");
        b5.setText(s.getMatrizes()[1].getCasillas()[5].getValor() + "");
        b6.setText(s.getMatrizes()[1].getCasillas()[6].getValor() + "");
        b7.setText(s.getMatrizes()[1].getCasillas()[7].getValor() + "");
        b8.setText(s.getMatrizes()[1].getCasillas()[8].getValor() + "");

        // ----
        c0.setText(s.getMatrizes()[2].getCasillas()[0].getValor() + "");
        c1.setText(s.getMatrizes()[2].getCasillas()[1].getValor() + "");
        c2.setText(s.getMatrizes()[2].getCasillas()[2].getValor() + "");
        c3.setText(s.getMatrizes()[2].getCasillas()[3].getValor() + "");
        c4.setText(s.getMatrizes()[2].getCasillas()[4].getValor() + "");
        c5.setText(s.getMatrizes()[2].getCasillas()[5].getValor() + "");
        c6.setText(s.getMatrizes()[2].getCasillas()[6].getValor() + "");
        c7.setText(s.getMatrizes()[2].getCasillas()[7].getValor() + "");
        c8.setText(s.getMatrizes()[2].getCasillas()[8].getValor() + "");

        // ----
        d0.setText(s.getMatrizes()[3].getCasillas()[0].getValor() + "");
        d1.setText(s.getMatrizes()[3].getCasillas()[1].getValor() + "");
        d2.setText(s.getMatrizes()[3].getCasillas()[2].getValor() + "");
        d3.setText(s.getMatrizes()[3].getCasillas()[3].getValor() + "");
        d4.setText(s.getMatrizes()[3].getCasillas()[4].getValor() + "");
        d5.setText(s.getMatrizes()[3].getCasillas()[5].getValor() + "");
        d6.setText(s.getMatrizes()[3].getCasillas()[6].getValor() + "");
        d7.setText(s.getMatrizes()[3].getCasillas()[7].getValor() + "");
        d8.setText(s.getMatrizes()[3].getCasillas()[8].getValor() + "");

        // ----
        e0.setText(s.getMatrizes()[4].getCasillas()[0].getValor() + "");
        e1.setText(s.getMatrizes()[4].getCasillas()[1].getValor() + "");
        e2.setText(s.getMatrizes()[4].getCasillas()[2].getValor() + "");
        e3.setText(s.getMatrizes()[4].getCasillas()[3].getValor() + "");
        e4.setText(s.getMatrizes()[4].getCasillas()[4].getValor() + "");
        e5.setText(s.getMatrizes()[4].getCasillas()[5].getValor() + "");
        e6.setText(s.getMatrizes()[4].getCasillas()[6].getValor() + "");
        e7.setText(s.getMatrizes()[4].getCasillas()[7].getValor() + "");
        e8.setText(s.getMatrizes()[4].getCasillas()[8].getValor() + "");

        // ----
        f0.setText(s.getMatrizes()[5].getCasillas()[0].getValor() + "");
        f1.setText(s.getMatrizes()[5].getCasillas()[1].getValor() + "");
        f2.setText(s.getMatrizes()[5].getCasillas()[2].getValor() + "");
        f3.setText(s.getMatrizes()[5].getCasillas()[3].getValor() + "");
        f4.setText(s.getMatrizes()[5].getCasillas()[4].getValor() + "");
        f5.setText(s.getMatrizes()[5].getCasillas()[5].getValor() + "");
        f6.setText(s.getMatrizes()[5].getCasillas()[6].getValor() + "");
        f7.setText(s.getMatrizes()[5].getCasillas()[7].getValor() + "");
        f8.setText(s.getMatrizes()[5].getCasillas()[8].getValor() + "");

        // ----
        g0.setText(s.getMatrizes()[6].getCasillas()[0].getValor() + "");
        g1.setText(s.getMatrizes()[6].getCasillas()[1].getValor() + "");
        g2.setText(s.getMatrizes()[6].getCasillas()[2].getValor() + "");
        g3.setText(s.getMatrizes()[6].getCasillas()[3].getValor() + "");
        g4.setText(s.getMatrizes()[6].getCasillas()[4].getValor() + "");
        g5.setText(s.getMatrizes()[6].getCasillas()[5].getValor() + "");
        g6.setText(s.getMatrizes()[6].getCasillas()[6].getValor() + "");
        g7.setText(s.getMatrizes()[6].getCasillas()[7].getValor() + "");
        g8.setText(s.getMatrizes()[6].getCasillas()[8].getValor() + "");

        // ----
        h0.setText(s.getMatrizes()[7].getCasillas()[0].getValor() + "");
        h1.setText(s.getMatrizes()[7].getCasillas()[1].getValor() + "");
        h2.setText(s.getMatrizes()[7].getCasillas()[2].getValor() + "");
        h3.setText(s.getMatrizes()[7].getCasillas()[3].getValor() + "");
        h4.setText(s.getMatrizes()[7].getCasillas()[4].getValor() + "");
        h5.setText(s.getMatrizes()[7].getCasillas()[5].getValor() + "");
        h6.setText(s.getMatrizes()[7].getCasillas()[6].getValor() + "");
        h7.setText(s.getMatrizes()[7].getCasillas()[7].getValor() + "");
        h8.setText(s.getMatrizes()[7].getCasillas()[8].getValor() + "");

        // ----
        i0.setText(s.getMatrizes()[8].getCasillas()[0].getValor() + "");
        i1.setText(s.getMatrizes()[8].getCasillas()[1].getValor() + "");
        i2.setText(s.getMatrizes()[8].getCasillas()[2].getValor() + "");
        i3.setText(s.getMatrizes()[8].getCasillas()[3].getValor() + "");
        i4.setText(s.getMatrizes()[8].getCasillas()[4].getValor() + "");
        i5.setText(s.getMatrizes()[8].getCasillas()[5].getValor() + "");
        i6.setText(s.getMatrizes()[8].getCasillas()[6].getValor() + "");
        i7.setText(s.getMatrizes()[8].getCasillas()[7].getValor() + "");
        i8.setText(s.getMatrizes()[8].getCasillas()[8].getValor() + "");

        
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        a0 = new javax.swing.JTextField();
        a1 = new javax.swing.JTextField();
        a2 = new javax.swing.JTextField();
        b0 = new javax.swing.JTextField();
        b1 = new javax.swing.JTextField();
        b2 = new javax.swing.JTextField();
        c0 = new javax.swing.JTextField();
        c1 = new javax.swing.JTextField();
        c2 = new javax.swing.JTextField();
        c5 = new javax.swing.JTextField();
        c4 = new javax.swing.JTextField();
        c3 = new javax.swing.JTextField();
        b5 = new javax.swing.JTextField();
        b4 = new javax.swing.JTextField();
        b3 = new javax.swing.JTextField();
        a5 = new javax.swing.JTextField();
        a4 = new javax.swing.JTextField();
        a3 = new javax.swing.JTextField();
        a6 = new javax.swing.JTextField();
        a7 = new javax.swing.JTextField();
        a8 = new javax.swing.JTextField();
        b6 = new javax.swing.JTextField();
        b7 = new javax.swing.JTextField();
        b8 = new javax.swing.JTextField();
        c6 = new javax.swing.JTextField();
        c7 = new javax.swing.JTextField();
        c8 = new javax.swing.JTextField();
        f2 = new javax.swing.JTextField();
        f1 = new javax.swing.JTextField();
        f0 = new javax.swing.JTextField();
        e2 = new javax.swing.JTextField();
        e1 = new javax.swing.JTextField();
        d2 = new javax.swing.JTextField();
        e0 = new javax.swing.JTextField();
        d1 = new javax.swing.JTextField();
        d0 = new javax.swing.JTextField();
        d3 = new javax.swing.JTextField();
        d6 = new javax.swing.JTextField();
        d4 = new javax.swing.JTextField();
        d5 = new javax.swing.JTextField();
        d8 = new javax.swing.JTextField();
        d7 = new javax.swing.JTextField();
        e3 = new javax.swing.JTextField();
        e4 = new javax.swing.JTextField();
        e5 = new javax.swing.JTextField();
        e8 = new javax.swing.JTextField();
        e7 = new javax.swing.JTextField();
        e6 = new javax.swing.JTextField();
        f3 = new javax.swing.JTextField();
        f4 = new javax.swing.JTextField();
        f5 = new javax.swing.JTextField();
        f8 = new javax.swing.JTextField();
        f7 = new javax.swing.JTextField();
        f6 = new javax.swing.JTextField();
        i0 = new javax.swing.JTextField();
        i1 = new javax.swing.JTextField();
        i2 = new javax.swing.JTextField();
        i5 = new javax.swing.JTextField();
        i4 = new javax.swing.JTextField();
        i3 = new javax.swing.JTextField();
        i6 = new javax.swing.JTextField();
        i7 = new javax.swing.JTextField();
        i8 = new javax.swing.JTextField();
        h8 = new javax.swing.JTextField();
        h5 = new javax.swing.JTextField();
        h2 = new javax.swing.JTextField();
        h1 = new javax.swing.JTextField();
        h0 = new javax.swing.JTextField();
        h3 = new javax.swing.JTextField();
        h4 = new javax.swing.JTextField();
        h7 = new javax.swing.JTextField();
        h6 = new javax.swing.JTextField();
        g8 = new javax.swing.JTextField();
        g5 = new javax.swing.JTextField();
        g2 = new javax.swing.JTextField();
        g1 = new javax.swing.JTextField();
        g0 = new javax.swing.JTextField();
        g3 = new javax.swing.JTextField();
        g4 = new javax.swing.JTextField();
        g7 = new javax.swing.JTextField();
        g6 = new javax.swing.JTextField();
        btnParar = new javax.swing.JButton();
        btnLimpiar = new javax.swing.JButton();
        lblTiempo = new javax.swing.JLabel();
        imgCargando = new javax.swing.JLabel();
        btnResolver = new javax.swing.JButton();
        lblFondoNegro = new javax.swing.JLabel();
        lblCargando = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setIconImage(getIconImage());
        setName("Resuelve Sudoku"); // NOI18N
        setResizable(false);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        a0.setFont(new java.awt.Font("DejaVu Serif", 3, 18)); // NOI18N
        a0.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        a0.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                a0FocusGained(evt);
            }
        });
        a0.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                a0ActionPerformed(evt);
            }
        });
        a0.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                a0KeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                a0KeyTyped(evt);
            }
        });
        getContentPane().add(a0, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 50, 40, 40));

        a1.setFont(new java.awt.Font("DejaVu Serif", 3, 18)); // NOI18N
        a1.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        a1.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                a1FocusGained(evt);
            }
        });
        a1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                a1MouseClicked(evt);
            }
        });
        a1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                a1ActionPerformed(evt);
            }
        });
        a1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                a1KeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                a1KeyTyped(evt);
            }
        });
        getContentPane().add(a1, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 50, 40, 40));

        a2.setFont(new java.awt.Font("DejaVu Serif", 3, 18)); // NOI18N
        a2.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        a2.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                a2FocusGained(evt);
            }
        });
        a2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                a2ActionPerformed(evt);
            }
        });
        a2.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                a2KeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                a2KeyTyped(evt);
            }
        });
        getContentPane().add(a2, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 50, 40, 40));

        b0.setFont(new java.awt.Font("DejaVu Serif", 3, 18)); // NOI18N
        b0.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        b0.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                b0KeyTyped(evt);
            }
        });
        getContentPane().add(b0, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 50, 40, 40));

        b1.setFont(new java.awt.Font("DejaVu Serif", 3, 18)); // NOI18N
        b1.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        b1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                b1KeyTyped(evt);
            }
        });
        getContentPane().add(b1, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 50, 40, 40));

        b2.setFont(new java.awt.Font("DejaVu Serif", 3, 18)); // NOI18N
        b2.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        b2.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                b2KeyTyped(evt);
            }
        });
        getContentPane().add(b2, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 50, 40, 40));

        c0.setFont(new java.awt.Font("DejaVu Serif", 3, 18)); // NOI18N
        c0.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        c0.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                c0KeyTyped(evt);
            }
        });
        getContentPane().add(c0, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 50, 40, 40));

        c1.setFont(new java.awt.Font("DejaVu Serif", 3, 18)); // NOI18N
        c1.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        c1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                c1KeyTyped(evt);
            }
        });
        getContentPane().add(c1, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 50, 40, 40));

        c2.setFont(new java.awt.Font("DejaVu Serif", 3, 18)); // NOI18N
        c2.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        c2.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                c2KeyTyped(evt);
            }
        });
        getContentPane().add(c2, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 50, 40, 40));

        c5.setFont(new java.awt.Font("DejaVu Serif", 3, 18)); // NOI18N
        c5.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        c5.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                c5KeyTyped(evt);
            }
        });
        getContentPane().add(c5, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 90, 40, 40));

        c4.setFont(new java.awt.Font("DejaVu Serif", 3, 18)); // NOI18N
        c4.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        c4.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                c4KeyTyped(evt);
            }
        });
        getContentPane().add(c4, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 90, 40, 40));

        c3.setFont(new java.awt.Font("DejaVu Serif", 3, 18)); // NOI18N
        c3.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        c3.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                c3KeyTyped(evt);
            }
        });
        getContentPane().add(c3, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 90, 40, 40));

        b5.setFont(new java.awt.Font("DejaVu Serif", 3, 18)); // NOI18N
        b5.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        b5.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                b5KeyTyped(evt);
            }
        });
        getContentPane().add(b5, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 90, 40, 40));

        b4.setFont(new java.awt.Font("DejaVu Serif", 3, 18)); // NOI18N
        b4.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        b4.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                b4KeyTyped(evt);
            }
        });
        getContentPane().add(b4, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 90, 40, 40));

        b3.setFont(new java.awt.Font("DejaVu Serif", 3, 18)); // NOI18N
        b3.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        b3.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                b3KeyTyped(evt);
            }
        });
        getContentPane().add(b3, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 90, 40, 40));

        a5.setFont(new java.awt.Font("DejaVu Serif", 3, 18)); // NOI18N
        a5.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        a5.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                a5FocusGained(evt);
            }
        });
        a5.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                a5KeyTyped(evt);
            }
        });
        getContentPane().add(a5, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 90, 40, 40));

        a4.setFont(new java.awt.Font("DejaVu Serif", 3, 18)); // NOI18N
        a4.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        a4.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                a4FocusGained(evt);
            }
        });
        a4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                a4ActionPerformed(evt);
            }
        });
        a4.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                a4KeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                a4KeyTyped(evt);
            }
        });
        getContentPane().add(a4, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 90, 40, 40));

        a3.setFont(new java.awt.Font("DejaVu Serif", 3, 18)); // NOI18N
        a3.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        a3.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                a3FocusGained(evt);
            }
        });
        a3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                a3ActionPerformed(evt);
            }
        });
        a3.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                a3KeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                a3KeyTyped(evt);
            }
        });
        getContentPane().add(a3, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 90, 40, 40));

        a6.setFont(new java.awt.Font("DejaVu Serif", 3, 18)); // NOI18N
        a6.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        a6.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                a6FocusGained(evt);
            }
        });
        a6.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                a6KeyTyped(evt);
            }
        });
        getContentPane().add(a6, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 130, 40, 40));

        a7.setFont(new java.awt.Font("DejaVu Serif", 3, 18)); // NOI18N
        a7.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        a7.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                a7FocusGained(evt);
            }
        });
        a7.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                a7KeyTyped(evt);
            }
        });
        getContentPane().add(a7, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 130, 40, 40));

        a8.setFont(new java.awt.Font("DejaVu Serif", 3, 18)); // NOI18N
        a8.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        a8.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                a8FocusGained(evt);
            }
        });
        a8.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                a8KeyTyped(evt);
            }
        });
        getContentPane().add(a8, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 130, 40, 40));

        b6.setFont(new java.awt.Font("DejaVu Serif", 3, 18)); // NOI18N
        b6.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        b6.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                b6KeyTyped(evt);
            }
        });
        getContentPane().add(b6, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 130, 40, 40));

        b7.setFont(new java.awt.Font("DejaVu Serif", 3, 18)); // NOI18N
        b7.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        b7.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                b7KeyTyped(evt);
            }
        });
        getContentPane().add(b7, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 130, 40, 40));

        b8.setFont(new java.awt.Font("DejaVu Serif", 3, 18)); // NOI18N
        b8.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        b8.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                b8KeyTyped(evt);
            }
        });
        getContentPane().add(b8, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 130, 40, 40));

        c6.setFont(new java.awt.Font("DejaVu Serif", 3, 18)); // NOI18N
        c6.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        c6.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                c6KeyTyped(evt);
            }
        });
        getContentPane().add(c6, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 130, 40, 40));

        c7.setFont(new java.awt.Font("DejaVu Serif", 3, 18)); // NOI18N
        c7.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        c7.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                c7KeyTyped(evt);
            }
        });
        getContentPane().add(c7, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 130, 40, 40));

        c8.setFont(new java.awt.Font("DejaVu Serif", 3, 18)); // NOI18N
        c8.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        c8.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                c8KeyTyped(evt);
            }
        });
        getContentPane().add(c8, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 130, 40, 40));

        f2.setFont(new java.awt.Font("DejaVu Serif", 3, 18)); // NOI18N
        f2.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        f2.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                f2KeyTyped(evt);
            }
        });
        getContentPane().add(f2, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 180, 40, 40));

        f1.setFont(new java.awt.Font("DejaVu Serif", 3, 18)); // NOI18N
        f1.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        f1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                f1KeyTyped(evt);
            }
        });
        getContentPane().add(f1, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 180, 40, 40));

        f0.setFont(new java.awt.Font("DejaVu Serif", 3, 18)); // NOI18N
        f0.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        f0.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                f0KeyTyped(evt);
            }
        });
        getContentPane().add(f0, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 180, 40, 40));

        e2.setFont(new java.awt.Font("DejaVu Serif", 3, 18)); // NOI18N
        e2.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        e2.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                e2KeyTyped(evt);
            }
        });
        getContentPane().add(e2, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 180, 40, 40));

        e1.setFont(new java.awt.Font("DejaVu Serif", 3, 18)); // NOI18N
        e1.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        e1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                e1KeyTyped(evt);
            }
        });
        getContentPane().add(e1, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 180, 40, 40));

        d2.setFont(new java.awt.Font("DejaVu Serif", 3, 18)); // NOI18N
        d2.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        d2.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                d2KeyTyped(evt);
            }
        });
        getContentPane().add(d2, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 180, 40, 40));

        e0.setFont(new java.awt.Font("DejaVu Serif", 3, 18)); // NOI18N
        e0.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        e0.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                e0KeyTyped(evt);
            }
        });
        getContentPane().add(e0, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 180, 40, 40));

        d1.setFont(new java.awt.Font("DejaVu Serif", 3, 18)); // NOI18N
        d1.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        d1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                d1KeyTyped(evt);
            }
        });
        getContentPane().add(d1, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 180, 40, 40));

        d0.setFont(new java.awt.Font("DejaVu Serif", 3, 18)); // NOI18N
        d0.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        d0.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                d0KeyTyped(evt);
            }
        });
        getContentPane().add(d0, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 180, 40, 40));

        d3.setFont(new java.awt.Font("DejaVu Serif", 3, 18)); // NOI18N
        d3.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        d3.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                d3KeyTyped(evt);
            }
        });
        getContentPane().add(d3, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 220, 40, 40));

        d6.setFont(new java.awt.Font("DejaVu Serif", 3, 18)); // NOI18N
        d6.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        d6.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                d6KeyTyped(evt);
            }
        });
        getContentPane().add(d6, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 260, 40, 40));

        d4.setFont(new java.awt.Font("DejaVu Serif", 3, 18)); // NOI18N
        d4.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        d4.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                d4KeyTyped(evt);
            }
        });
        getContentPane().add(d4, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 220, 40, 40));

        d5.setFont(new java.awt.Font("DejaVu Serif", 3, 18)); // NOI18N
        d5.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        d5.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                d5KeyTyped(evt);
            }
        });
        getContentPane().add(d5, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 220, 40, 40));

        d8.setFont(new java.awt.Font("DejaVu Serif", 3, 18)); // NOI18N
        d8.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        d8.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                d8KeyTyped(evt);
            }
        });
        getContentPane().add(d8, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 260, 40, 40));

        d7.setFont(new java.awt.Font("DejaVu Serif", 3, 18)); // NOI18N
        d7.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        d7.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                d7KeyTyped(evt);
            }
        });
        getContentPane().add(d7, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 260, 40, 40));

        e3.setFont(new java.awt.Font("DejaVu Serif", 3, 18)); // NOI18N
        e3.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        e3.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                e3KeyTyped(evt);
            }
        });
        getContentPane().add(e3, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 220, 40, 40));

        e4.setFont(new java.awt.Font("DejaVu Serif", 3, 18)); // NOI18N
        e4.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        e4.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                e4KeyTyped(evt);
            }
        });
        getContentPane().add(e4, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 220, 40, 40));

        e5.setFont(new java.awt.Font("DejaVu Serif", 3, 18)); // NOI18N
        e5.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        e5.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                e5KeyTyped(evt);
            }
        });
        getContentPane().add(e5, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 220, 40, 40));

        e8.setFont(new java.awt.Font("DejaVu Serif", 3, 18)); // NOI18N
        e8.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        e8.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                e8KeyTyped(evt);
            }
        });
        getContentPane().add(e8, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 260, 40, 40));

        e7.setFont(new java.awt.Font("DejaVu Serif", 3, 18)); // NOI18N
        e7.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        e7.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                e7KeyTyped(evt);
            }
        });
        getContentPane().add(e7, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 260, 40, 40));

        e6.setFont(new java.awt.Font("DejaVu Serif", 3, 18)); // NOI18N
        e6.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        e6.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                e6KeyTyped(evt);
            }
        });
        getContentPane().add(e6, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 260, 40, 40));

        f3.setFont(new java.awt.Font("DejaVu Serif", 3, 18)); // NOI18N
        f3.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        f3.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                f3KeyTyped(evt);
            }
        });
        getContentPane().add(f3, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 220, 40, 40));

        f4.setFont(new java.awt.Font("DejaVu Serif", 3, 18)); // NOI18N
        f4.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        f4.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                f4KeyTyped(evt);
            }
        });
        getContentPane().add(f4, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 220, 40, 40));

        f5.setFont(new java.awt.Font("DejaVu Serif", 3, 18)); // NOI18N
        f5.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        f5.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                f5KeyTyped(evt);
            }
        });
        getContentPane().add(f5, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 220, 40, 40));

        f8.setFont(new java.awt.Font("DejaVu Serif", 3, 18)); // NOI18N
        f8.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        f8.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                f8KeyTyped(evt);
            }
        });
        getContentPane().add(f8, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 260, 40, 40));

        f7.setFont(new java.awt.Font("DejaVu Serif", 3, 18)); // NOI18N
        f7.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        f7.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                f7KeyTyped(evt);
            }
        });
        getContentPane().add(f7, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 260, 40, 40));

        f6.setFont(new java.awt.Font("DejaVu Serif", 3, 18)); // NOI18N
        f6.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        f6.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                f6KeyTyped(evt);
            }
        });
        getContentPane().add(f6, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 260, 40, 40));

        i0.setFont(new java.awt.Font("DejaVu Serif", 3, 18)); // NOI18N
        i0.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        i0.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                i0KeyTyped(evt);
            }
        });
        getContentPane().add(i0, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 310, 40, 40));

        i1.setFont(new java.awt.Font("DejaVu Serif", 3, 18)); // NOI18N
        i1.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        i1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                i1KeyTyped(evt);
            }
        });
        getContentPane().add(i1, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 310, 40, 40));

        i2.setFont(new java.awt.Font("DejaVu Serif", 3, 18)); // NOI18N
        i2.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        i2.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                i2KeyTyped(evt);
            }
        });
        getContentPane().add(i2, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 310, 40, 40));

        i5.setFont(new java.awt.Font("DejaVu Serif", 3, 18)); // NOI18N
        i5.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        i5.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                i5KeyTyped(evt);
            }
        });
        getContentPane().add(i5, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 350, 40, 40));

        i4.setFont(new java.awt.Font("DejaVu Serif", 3, 18)); // NOI18N
        i4.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        i4.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                i4KeyTyped(evt);
            }
        });
        getContentPane().add(i4, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 350, 40, 40));

        i3.setFont(new java.awt.Font("DejaVu Serif", 3, 18)); // NOI18N
        i3.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        i3.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                i3KeyTyped(evt);
            }
        });
        getContentPane().add(i3, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 350, 40, 40));

        i6.setFont(new java.awt.Font("DejaVu Serif", 3, 18)); // NOI18N
        i6.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        i6.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                i6KeyTyped(evt);
            }
        });
        getContentPane().add(i6, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 390, 40, 40));

        i7.setFont(new java.awt.Font("DejaVu Serif", 3, 18)); // NOI18N
        i7.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        i7.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                i7KeyTyped(evt);
            }
        });
        getContentPane().add(i7, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 390, 40, 40));

        i8.setFont(new java.awt.Font("DejaVu Serif", 3, 18)); // NOI18N
        i8.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        i8.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                i8KeyTyped(evt);
            }
        });
        getContentPane().add(i8, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 390, 40, 40));

        h8.setFont(new java.awt.Font("DejaVu Serif", 3, 18)); // NOI18N
        h8.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        h8.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                h8KeyTyped(evt);
            }
        });
        getContentPane().add(h8, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 390, 40, 40));

        h5.setFont(new java.awt.Font("DejaVu Serif", 3, 18)); // NOI18N
        h5.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        h5.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                h5KeyTyped(evt);
            }
        });
        getContentPane().add(h5, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 350, 40, 40));

        h2.setFont(new java.awt.Font("DejaVu Serif", 3, 18)); // NOI18N
        h2.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        h2.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                h2KeyTyped(evt);
            }
        });
        getContentPane().add(h2, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 310, 40, 40));

        h1.setFont(new java.awt.Font("DejaVu Serif", 3, 18)); // NOI18N
        h1.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        h1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                h1KeyTyped(evt);
            }
        });
        getContentPane().add(h1, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 310, 40, 40));

        h0.setFont(new java.awt.Font("DejaVu Serif", 3, 18)); // NOI18N
        h0.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        h0.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                h0KeyTyped(evt);
            }
        });
        getContentPane().add(h0, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 310, 40, 40));

        h3.setFont(new java.awt.Font("DejaVu Serif", 3, 18)); // NOI18N
        h3.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        h3.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                h3KeyTyped(evt);
            }
        });
        getContentPane().add(h3, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 350, 40, 40));

        h4.setFont(new java.awt.Font("DejaVu Serif", 3, 18)); // NOI18N
        h4.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        h4.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                h4KeyTyped(evt);
            }
        });
        getContentPane().add(h4, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 350, 40, 40));

        h7.setFont(new java.awt.Font("DejaVu Serif", 3, 18)); // NOI18N
        h7.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        h7.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                h7KeyTyped(evt);
            }
        });
        getContentPane().add(h7, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 390, 40, 40));

        h6.setFont(new java.awt.Font("DejaVu Serif", 3, 18)); // NOI18N
        h6.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        h6.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                h6KeyTyped(evt);
            }
        });
        getContentPane().add(h6, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 390, 40, 40));

        g8.setFont(new java.awt.Font("DejaVu Serif", 3, 18)); // NOI18N
        g8.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        g8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                g8ActionPerformed(evt);
            }
        });
        g8.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                g8KeyTyped(evt);
            }
        });
        getContentPane().add(g8, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 390, 40, 40));

        g5.setFont(new java.awt.Font("DejaVu Serif", 3, 18)); // NOI18N
        g5.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        g5.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                g5KeyTyped(evt);
            }
        });
        getContentPane().add(g5, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 350, 40, 40));

        g2.setFont(new java.awt.Font("DejaVu Serif", 3, 18)); // NOI18N
        g2.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        g2.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                g2KeyTyped(evt);
            }
        });
        getContentPane().add(g2, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 310, 40, 40));

        g1.setFont(new java.awt.Font("DejaVu Serif", 3, 18)); // NOI18N
        g1.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        g1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                g1KeyTyped(evt);
            }
        });
        getContentPane().add(g1, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 310, 40, 40));

        g0.setFont(new java.awt.Font("DejaVu Serif", 3, 18)); // NOI18N
        g0.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        g0.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                g0KeyTyped(evt);
            }
        });
        getContentPane().add(g0, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 310, 40, 40));

        g3.setFont(new java.awt.Font("DejaVu Serif", 3, 18)); // NOI18N
        g3.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        g3.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                g3KeyTyped(evt);
            }
        });
        getContentPane().add(g3, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 350, 40, 40));

        g4.setFont(new java.awt.Font("DejaVu Serif", 3, 18)); // NOI18N
        g4.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        g4.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                g4KeyTyped(evt);
            }
        });
        getContentPane().add(g4, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 350, 40, 40));

        g7.setFont(new java.awt.Font("DejaVu Serif", 3, 18)); // NOI18N
        g7.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        g7.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                g7KeyTyped(evt);
            }
        });
        getContentPane().add(g7, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 390, 40, 40));

        g6.setFont(new java.awt.Font("DejaVu Serif", 3, 18)); // NOI18N
        g6.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        g6.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                g6KeyTyped(evt);
            }
        });
        getContentPane().add(g6, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 390, 40, 40));

        btnParar.setText("PARAR");
        btnParar.setActionCommand("generar");
        btnParar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPararActionPerformed(evt);
            }
        });
        getContentPane().add(btnParar, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 60, 80, 40));

        btnLimpiar.setText("LIMPIAR");
        btnLimpiar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLimpiarActionPerformed(evt);
            }
        });
        getContentPane().add(btnLimpiar, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 120, -1, -1));

        lblTiempo.setFont(new java.awt.Font("Yu Gothic UI Light", 3, 12)); // NOI18N
        lblTiempo.setText("Tiempo:  ");
        getContentPane().add(lblTiempo, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 400, 130, 40));

        imgCargando.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/cargando1.gif"))); // NOI18N
        getContentPane().add(imgCargando, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 150, 220, 150));

        btnResolver.setText("RESOLVER");
        btnResolver.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnResolverActionPerformed(evt);
            }
        });
        getContentPane().add(btnResolver, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 60, -1, 40));

        lblFondoNegro.setBackground(new java.awt.Color(0, 0, 0));
        lblFondoNegro.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/fondo_negro.jpg"))); // NOI18N
        getContentPane().add(lblFondoNegro, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 40, 400, 400));

        lblCargando.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/muchos-Numeros.jpg"))); // NOI18N
        getContentPane().add(lblCargando, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, 480));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    
    
    
    
    
    
    
    
    
    
    private void a0FocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_a0FocusGained
        // TODO add your handling code here:
    }//GEN-LAST:event_a0FocusGained

    private void a0ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_a0ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_a0ActionPerformed

    private void a0KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_a0KeyPressed

    }//GEN-LAST:event_a0KeyPressed

    private void a0KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_a0KeyTyped

        int[] valores[] = recojeValores();
        prohibidosA0 = new ArrayList<Integer>();

        guardaEnLista(prohibidosA0, valores[0]);
        guardaEnLista(prohibidosA0, new int[]{valores[0][0], valores[0][1], valores[0][2],
            valores[1][0], valores[1][1], valores[1][2], valores[2][0], valores[2][1], valores[2][2]});
    guardaEnLista(prohibidosA0, new int[]{
        valores[0][0], valores[0][3], valores[0][6], valores[3][0], valores[3][3], valores[3][6],
        valores[6][0], valores[6][3], valores[6][6]});

        validaCasillas(a0, evt);
        validaValoresSalidos(prohibidosA0, evt);
    }//GEN-LAST:event_a0KeyTyped

    private void a1FocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_a1FocusGained

    }//GEN-LAST:event_a1FocusGained

    private void a1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_a1MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_a1MouseClicked

    private void a1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_a1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_a1ActionPerformed

    private void a1KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_a1KeyPressed
        // TODO add your handling code here:
    }//GEN-LAST:event_a1KeyPressed

    private void a1KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_a1KeyTyped
        // TODO add your handling code here:

        int[] valores[] = recojeValores();
        prohibidosA1 = new ArrayList<Integer>();

        guardaEnLista(prohibidosA1, valores[0]);

        guardaEnLista(prohibidosA1, new int[]{valores[0][0], valores[0][1], valores[0][2],
            valores[1][0], valores[1][1], valores[1][2], valores[2][0], valores[2][1], valores[2][2]});

    guardaEnLista(prohibidosA1, new int[]{valores[0][1], valores[0][4], valores[0][7],
        valores[3][1], valores[3][4], valores[3][7], valores[6][1], valores[6][4], valores[3][7]});

        validaCasillas(a1, evt);

        validaValoresSalidos(prohibidosA1, evt);
    }//GEN-LAST:event_a1KeyTyped

    private void a2FocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_a2FocusGained
        // TODO add your handling code here:
    }//GEN-LAST:event_a2FocusGained

    private void a2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_a2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_a2ActionPerformed

    private void a2KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_a2KeyPressed

    }//GEN-LAST:event_a2KeyPressed

    private void a2KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_a2KeyTyped
        // TODO add your handling code here:

        int[] valores[] = recojeValores();
        prohibidosA2 = new ArrayList<Integer>();

        guardaEnLista(prohibidosA2, valores[0]);

        guardaEnLista(prohibidosA2, new int[]{valores[0][0], valores[0][1], valores[0][2],
            valores[1][0], valores[1][1], valores[1][2], valores[2][0], valores[2][1], valores[2][2]});

    guardaEnLista(prohibidosA2, new int[]{valores[0][2], valores[0][5], valores[0][8],
        valores[3][2], valores[3][5], valores[3][8], valores[6][2], valores[6][5], valores[6][8]});

        validaCasillas(a2, evt);
        validaValoresSalidos(prohibidosA2, evt);
    }//GEN-LAST:event_a2KeyTyped

    private void b0KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_b0KeyTyped
        // TODO add your handling code here:

        int[] valores[] = recojeValores();
        prohibidosB0 = new ArrayList<Integer>();

        guardaEnLista(prohibidosB0, valores[1]);
        guardaEnLista(prohibidosB0, new int[]{valores[0][0], valores[0][1], valores[0][2],
            valores[1][0], valores[1][1], valores[1][2], valores[2][0], valores[2][1], valores[2][2]});
    guardaEnLista(prohibidosB0, new int[]{
        valores[1][0], valores[1][3], valores[1][6], valores[4][0], valores[4][3], valores[4][6],
        valores[7][0], valores[7][3], valores[7][6]});
        validaCasillas(b0, evt);
        validaValoresSalidos(prohibidosB0, evt);
    }//GEN-LAST:event_b0KeyTyped

    private void b1KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_b1KeyTyped
        // TODO add your handling code here:

        int[] valores[] = recojeValores();
        prohibidosB1 = new ArrayList<Integer>();

        guardaEnLista(prohibidosB1, valores[1]);
        guardaEnLista(prohibidosB1, new int[]{valores[0][0], valores[0][1], valores[0][2],
            valores[1][0], valores[1][1], valores[1][2], valores[2][0], valores[2][1], valores[2][2]});
    guardaEnLista(prohibidosB1, new int[]{
        valores[1][1], valores[1][4], valores[1][7], valores[4][1], valores[4][4], valores[4][7],
        valores[7][1], valores[7][4], valores[7][7]});

        validaCasillas(b1, evt);
        validaValoresSalidos(prohibidosB1, evt);
    }//GEN-LAST:event_b1KeyTyped

    private void b2KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_b2KeyTyped
        // TODO add your handling code here:

        int[] valores[] = recojeValores();
        prohibidosB2 = new ArrayList<Integer>();

        guardaEnLista(prohibidosB2, valores[1]);
        guardaEnLista(prohibidosB2, new int[]{valores[0][0], valores[0][1], valores[0][2],
            valores[1][0], valores[1][1], valores[1][2], valores[2][0], valores[2][1], valores[2][2]});
    guardaEnLista(prohibidosB2, new int[]{
        valores[1][2], valores[1][5], valores[1][8], valores[4][2], valores[4][5], valores[4][8],
        valores[7][2], valores[7][5], valores[7][8]});

        validaCasillas(b2, evt);
        validaValoresSalidos(prohibidosB2, evt);
    }//GEN-LAST:event_b2KeyTyped

    private void c0KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_c0KeyTyped
        // TODO add your handling code here:

        int[] valores[] = recojeValores();
        prohibidosC0 = new ArrayList<Integer>();

        guardaEnLista(prohibidosC0, valores[2]);
        guardaEnLista(prohibidosC0, new int[]{valores[0][0], valores[0][1], valores[0][2],
            valores[1][0], valores[1][1], valores[1][2], valores[2][0], valores[2][1], valores[2][2]});
    guardaEnLista(prohibidosC0, new int[]{valores[2][0], valores[2][3], valores[2][6],
        valores[5][0], valores[5][3], valores[5][6], valores[8][0], valores[8][3], valores[8][6]});
        validaCasillas(c0, evt);
        validaValoresSalidos(prohibidosC0, evt);
    }//GEN-LAST:event_c0KeyTyped

    private void c1KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_c1KeyTyped
        // TODO add your handling code here:
        int[] valores[] = recojeValores();
        prohibidosC1 = new ArrayList<Integer>();

        guardaEnLista(prohibidosC1, valores[2]);
        guardaEnLista(prohibidosC1, new int[]{valores[0][0], valores[0][1], valores[0][2],
            valores[1][0], valores[1][1], valores[1][2], valores[2][0], valores[2][1], valores[2][2]});
    guardaEnLista(prohibidosC1, new int[]{valores[2][1], valores[2][4], valores[2][7],
        valores[5][1], valores[5][4], valores[5][7], valores[8][1], valores[8][4], valores[8][7]});
        validaCasillas(c1, evt);
        validaValoresSalidos(prohibidosC1, evt);
    }//GEN-LAST:event_c1KeyTyped

    private void c2KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_c2KeyTyped
        // TODO add your handling code here:

        int[] valores[] = recojeValores();
        prohibidosC2 = new ArrayList<Integer>();

        guardaEnLista(prohibidosC2, valores[2]);
        guardaEnLista(prohibidosC2, new int[]{valores[0][0], valores[0][1], valores[0][2],
            valores[1][0], valores[1][1], valores[1][2], valores[2][0], valores[2][1], valores[2][2]});
    guardaEnLista(prohibidosC2, new int[]{valores[2][2], valores[2][5], valores[2][8],
        valores[5][2], valores[5][5], valores[5][8], valores[8][2], valores[8][5], valores[8][8]});

        validaCasillas(c2, evt);
        validaValoresSalidos(prohibidosC2, evt);
    }//GEN-LAST:event_c2KeyTyped

    private void c5KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_c5KeyTyped
        // TODO add your handling code here:
        int[] valores[] = recojeValores();
        prohibidosC5 = new ArrayList<Integer>();

        guardaEnLista(prohibidosC5, valores[2]);
        guardaEnLista(prohibidosC5, new int[]{valores[0][3], valores[0][4], valores[0][5],
            valores[1][3], valores[1][4], valores[1][5], valores[2][3], valores[2][4], valores[2][5]});
    guardaEnLista(prohibidosC5, new int[]{valores[2][2], valores[2][5], valores[2][8],
        valores[5][2], valores[5][5], valores[5][8], valores[8][2], valores[8][5], valores[8][8]});
        validaCasillas(c5, evt);
        validaValoresSalidos(prohibidosC5, evt);
    }//GEN-LAST:event_c5KeyTyped

    private void c4KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_c4KeyTyped
        // TODO add your handling code here:
        int[] valores[] = recojeValores();
        prohibidosC4 = new ArrayList<Integer>();

        guardaEnLista(prohibidosC4, valores[2]);
        guardaEnLista(prohibidosC4, new int[]{valores[0][3], valores[0][4], valores[0][5],
            valores[1][3], valores[1][4], valores[1][5], valores[2][3], valores[2][4], valores[2][5]});
    guardaEnLista(prohibidosC4, new int[]{valores[2][1], valores[2][4], valores[2][7],
        valores[5][1], valores[5][4], valores[5][7], valores[8][1], valores[8][4], valores[8][7]});
        validaCasillas(c4, evt);
        validaValoresSalidos(prohibidosC4, evt);
    }//GEN-LAST:event_c4KeyTyped

    private void c3KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_c3KeyTyped
        // TODO add your handling code here:
        int[] valores[] = recojeValores();
        prohibidosC3 = new ArrayList<Integer>();

        guardaEnLista(prohibidosC3, valores[2]);
        guardaEnLista(prohibidosC3, new int[]{valores[0][3], valores[0][4], valores[0][5],
            valores[1][3], valores[1][4], valores[1][5], valores[2][3], valores[2][4], valores[2][5]});
    guardaEnLista(prohibidosC3, new int[]{valores[2][0], valores[2][3], valores[2][6],
        valores[5][0], valores[5][3], valores[5][6], valores[8][0], valores[8][3], valores[8][6]});
        validaCasillas(c3, evt);
        validaValoresSalidos(prohibidosC3, evt);
    }//GEN-LAST:event_c3KeyTyped

    private void b5KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_b5KeyTyped
        // TODO add your handling code here:
        int[] valores[] = recojeValores();
        prohibidosB5 = new ArrayList<Integer>();

        guardaEnLista(prohibidosB5, valores[1]);
        guardaEnLista(prohibidosB5, new int[]{valores[0][3], valores[0][4], valores[0][5],
            valores[1][3], valores[1][4], valores[1][5], valores[2][3], valores[2][4], valores[2][5]});
    guardaEnLista(prohibidosB5, new int[]{
        valores[1][2], valores[1][5], valores[1][8], valores[4][2], valores[4][5], valores[4][8],
        valores[7][2], valores[7][5], valores[7][8]});
        validaCasillas(b5, evt);
        validaValoresSalidos(prohibidosB5, evt);
    }//GEN-LAST:event_b5KeyTyped

    private void b4KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_b4KeyTyped
        // TODO add your handling code here:
        int[] valores[] = recojeValores();
        prohibidosB4 = new ArrayList<Integer>();

        guardaEnLista(prohibidosB4, valores[1]);
        guardaEnLista(prohibidosB4, new int[]{valores[0][3], valores[0][4], valores[0][5],
            valores[1][3], valores[1][4], valores[1][5], valores[2][3], valores[2][4], valores[2][5]});
    guardaEnLista(prohibidosB4, new int[]{
        valores[1][1], valores[1][4], valores[1][7], valores[4][1], valores[4][4], valores[4][7],
        valores[7][1], valores[7][4], valores[7][7]});

        validaCasillas(b4, evt);
        validaValoresSalidos(prohibidosB4, evt);
    }//GEN-LAST:event_b4KeyTyped

    private void b3KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_b3KeyTyped
        // TODO add your handling code here:

        int[] valores[] = recojeValores();
        prohibidosB3 = new ArrayList<Integer>();

        guardaEnLista(prohibidosB3, valores[1]);
        guardaEnLista(prohibidosB3, new int[]{valores[0][3], valores[0][4], valores[0][5],
            valores[1][3], valores[1][4], valores[1][5], valores[2][3], valores[2][4], valores[2][5]});

    guardaEnLista(prohibidosB3, new int[]{
        valores[1][0], valores[1][3], valores[1][6], valores[4][0], valores[4][3], valores[4][6],
        valores[7][0], valores[7][3], valores[7][6]});

        validaCasillas(b3, evt);
        validaValoresSalidos(prohibidosB3, evt);
    }//GEN-LAST:event_b3KeyTyped

    private void a5FocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_a5FocusGained
        // TODO add your handling code here:
    }//GEN-LAST:event_a5FocusGained

    private void a5KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_a5KeyTyped
        // TODO add your handling code here:

        int[] valores[] = recojeValores();
        prohibidosA5 = new ArrayList<Integer>();

        guardaEnLista(prohibidosA5, valores[0]);

        guardaEnLista(prohibidosA5, new int[]{valores[0][3], valores[0][4], valores[0][5],
            valores[1][3], valores[1][4], valores[1][5], valores[2][3], valores[2][4], valores[2][5]});
    guardaEnLista(prohibidosA5, new int[]{valores[0][2], valores[0][5], valores[0][8],
        valores[3][2], valores[3][5], valores[3][8], valores[6][2], valores[6][5], valores[6][8]});

        validaCasillas(a5, evt);
        validaValoresSalidos(prohibidosA5, evt);
        //      bloqueBoton();
    }//GEN-LAST:event_a5KeyTyped

    private void a4FocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_a4FocusGained
        // TODO add your handling code here:
    }//GEN-LAST:event_a4FocusGained

    private void a4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_a4ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_a4ActionPerformed

    private void a4KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_a4KeyPressed

    }//GEN-LAST:event_a4KeyPressed

    private void a4KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_a4KeyTyped
        // TODO add your handling code here:

        int[] valores[] = recojeValores();
        prohibidosA4 = new ArrayList<Integer>();

        guardaEnLista(prohibidosA4, valores[0]);

        guardaEnLista(prohibidosA4, new int[]{valores[0][3], valores[0][4], valores[0][5],
            valores[1][3], valores[1][4], valores[1][5], valores[2][3], valores[2][4], valores[2][5]});

    guardaEnLista(prohibidosA4, new int[]{valores[0][1], valores[0][4], valores[0][7],
        valores[3][1], valores[3][4], valores[3][7], valores[6][1], valores[6][4], valores[3][7]});

        validaCasillas(a4, evt);
        validaValoresSalidos(prohibidosA4, evt);
        //   bloqueBoton();
    }//GEN-LAST:event_a4KeyTyped

    private void a3FocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_a3FocusGained
        // TODO add your handling
    }//GEN-LAST:event_a3FocusGained

    private void a3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_a3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_a3ActionPerformed

    private void a3KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_a3KeyPressed
        // TODO add your handling code here:
    }//GEN-LAST:event_a3KeyPressed

    private void a3KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_a3KeyTyped
        // TODO add your handling code here:

        int[] valores[] = recojeValores();
        prohibidosA3 = new ArrayList<Integer>();

        guardaEnLista(prohibidosA3, valores[0]);

        guardaEnLista(prohibidosA3, new int[]{valores[0][3], valores[0][4], valores[0][5],
            valores[1][3], valores[1][4], valores[1][5], valores[2][3], valores[2][4], valores[2][5]});

    guardaEnLista(prohibidosA3, new int[]{
        valores[0][0], valores[0][3], valores[0][6], valores[3][0], valores[3][3], valores[3][6],
        valores[6][0], valores[6][3], valores[6][6]});

        validaCasillas(a3, evt);
        validaValoresSalidos(prohibidosA3, evt);
        //    bloqueBoton();
    }//GEN-LAST:event_a3KeyTyped

    private void a6FocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_a6FocusGained
        // TODO add your handling code here:
    }//GEN-LAST:event_a6FocusGained

    private void a6KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_a6KeyTyped
        // TODO add your handling code here:

        int[] valores[] = recojeValores();
        prohibidosA6 = new ArrayList<Integer>();

        guardaEnLista(prohibidosA6, valores[0]);

        guardaEnLista(prohibidosA6, new int[]{valores[0][6], valores[0][7], valores[0][8],
            valores[1][6], valores[1][7], valores[1][8], valores[2][6], valores[2][7], valores[2][8]});

    guardaEnLista(prohibidosA6, new int[]{
        valores[0][0], valores[0][3], valores[0][6], valores[3][0], valores[3][3], valores[3][6],
        valores[6][0], valores[6][3], valores[6][6]});

        validaCasillas(a6, evt);
        validaValoresSalidos(prohibidosA6, evt);
    }//GEN-LAST:event_a6KeyTyped

    private void a7FocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_a7FocusGained
        // TODO add your handling code here:
    }//GEN-LAST:event_a7FocusGained

    private void a7KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_a7KeyTyped
        // TODO add your handling code here:

        int[] valores[] = recojeValores();
        prohibidosA7 = new ArrayList<Integer>();

        guardaEnLista(prohibidosA7, valores[0]);

        guardaEnLista(prohibidosA7, new int[]{valores[0][6], valores[0][7], valores[0][8],
            valores[1][6], valores[1][7], valores[1][8], valores[2][6], valores[2][7], valores[2][8]});

    guardaEnLista(prohibidosA7, new int[]{valores[0][1], valores[0][4], valores[0][7],
        valores[3][1], valores[3][4], valores[3][7], valores[6][1], valores[6][4], valores[3][7]});

        validaCasillas(a7, evt);
        validaValoresSalidos(prohibidosA7, evt);
    }//GEN-LAST:event_a7KeyTyped

    private void a8FocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_a8FocusGained
        // TODO add your handling code here:
    }//GEN-LAST:event_a8FocusGained

    private void a8KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_a8KeyTyped
        // TODO add your handling code here:

        int[] valores[] = recojeValores();
        prohibidosA8 = new ArrayList<Integer>();

        guardaEnLista(prohibidosA8, valores[0]);

        guardaEnLista(prohibidosA8, new int[]{valores[0][6], valores[0][7], valores[0][8],
            valores[1][6], valores[1][7], valores[1][8], valores[2][6], valores[2][7], valores[2][8]});

    guardaEnLista(prohibidosA8, new int[]{valores[0][2], valores[0][5], valores[0][8],
        valores[3][2], valores[3][5], valores[3][8], valores[6][2], valores[6][5], valores[6][8]});

        validaCasillas(a8, evt);
        validaValoresSalidos(prohibidosA8, evt);
    }//GEN-LAST:event_a8KeyTyped

    private void b6KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_b6KeyTyped
        // TODO add your handling code here:
        int[] valores[] = recojeValores();
        prohibidosB6 = new ArrayList<Integer>();

        guardaEnLista(prohibidosB6, valores[1]);
        guardaEnLista(prohibidosB6, new int[]{valores[0][6], valores[0][7], valores[0][8],
            valores[1][6], valores[1][7], valores[1][8], valores[2][6], valores[2][7], valores[2][8]});
    guardaEnLista(prohibidosB6, new int[]{
        valores[1][0], valores[1][3], valores[1][6], valores[4][0], valores[4][3], valores[4][6],
        valores[7][0], valores[7][3], valores[7][6]});

        validaCasillas(b6, evt);
        validaValoresSalidos(prohibidosB6, evt);
    }//GEN-LAST:event_b6KeyTyped

    private void b7KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_b7KeyTyped
        // TODO add your handling code here:
        int[] valores[] = recojeValores();
        prohibidosB7 = new ArrayList<Integer>();

        guardaEnLista(prohibidosB7, valores[1]);
        guardaEnLista(prohibidosB7, new int[]{valores[0][6], valores[0][7], valores[0][8],
            valores[1][6], valores[1][7], valores[1][8], valores[2][6], valores[2][7], valores[2][8]});
    guardaEnLista(prohibidosB7, new int[]{
        valores[1][1], valores[1][4], valores[1][7], valores[4][1], valores[4][4], valores[4][7],
        valores[7][1], valores[7][4], valores[7][7]});
        validaCasillas(b7, evt);
        validaValoresSalidos(prohibidosB7, evt);
    }//GEN-LAST:event_b7KeyTyped

    private void b8KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_b8KeyTyped
        // TODO add your handling code here:
        int[] valores[] = recojeValores();
        prohibidosB8 = new ArrayList<Integer>();

        guardaEnLista(prohibidosB8, valores[1]);
        guardaEnLista(prohibidosB8, new int[]{valores[0][6], valores[0][7], valores[0][8],
            valores[1][6], valores[1][7], valores[1][8], valores[2][6], valores[2][7], valores[2][8]});
    guardaEnLista(prohibidosB8, new int[]{
        valores[1][2], valores[1][5], valores[1][8], valores[4][2], valores[4][5], valores[4][8],
        valores[7][2], valores[7][5], valores[7][8]});

        validaCasillas(b8, evt);
        validaValoresSalidos(prohibidosB8, evt);
    }//GEN-LAST:event_b8KeyTyped

    private void c6KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_c6KeyTyped
        // TODO add your handling code here:
        int[] valores[] = recojeValores();
        prohibidosC6 = new ArrayList<Integer>();

        guardaEnLista(prohibidosC6, valores[2]);
        guardaEnLista(prohibidosC6, new int[]{valores[0][6], valores[0][7], valores[0][8],
            valores[1][6], valores[1][7], valores[1][8], valores[2][6], valores[2][7], valores[2][8]});
    guardaEnLista(prohibidosC6, new int[]{valores[2][0], valores[2][3], valores[2][6],
        valores[5][0], valores[5][3], valores[5][6], valores[8][0], valores[8][3], valores[8][6]});
        validaCasillas(c6, evt);
        validaValoresSalidos(prohibidosC6, evt);
    }//GEN-LAST:event_c6KeyTyped

    private void c7KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_c7KeyTyped
        // TODO add your handling code here:
        int[] valores[] = recojeValores();
        prohibidosC7 = new ArrayList<Integer>();

        guardaEnLista(prohibidosC7, valores[2]);
        guardaEnLista(prohibidosC7, new int[]{valores[0][6], valores[0][7], valores[0][8],
            valores[1][6], valores[1][7], valores[1][8], valores[2][6], valores[2][7], valores[2][8]});
    guardaEnLista(prohibidosC7, new int[]{valores[2][1], valores[2][4], valores[2][7],
        valores[5][1], valores[5][4], valores[5][7], valores[8][1], valores[8][4], valores[8][7]});
        validaCasillas(c7, evt);
        validaValoresSalidos(prohibidosC7, evt);
    }//GEN-LAST:event_c7KeyTyped

    private void c8KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_c8KeyTyped
        // TODO add your handling code here:
        int[] valores[] = recojeValores();
        prohibidosC8 = new ArrayList<Integer>();

        guardaEnLista(prohibidosC8, valores[2]);
        guardaEnLista(prohibidosC8, new int[]{valores[0][6], valores[0][7], valores[0][8],
            valores[1][6], valores[1][7], valores[1][8], valores[2][6], valores[2][7], valores[2][8]});
    guardaEnLista(prohibidosC8, new int[]{valores[2][2], valores[2][5], valores[2][8],
        valores[5][2], valores[5][5], valores[5][8], valores[8][2], valores[8][5], valores[8][8]});
        validaCasillas(c8, evt);
        validaValoresSalidos(prohibidosC8, evt);
    }//GEN-LAST:event_c8KeyTyped

    private void f2KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_f2KeyTyped
        // TODO add your handling code here:
        int[] valores[] = recojeValores();
        prohibidosF2 = new ArrayList<Integer>();

        guardaEnLista(prohibidosF2, valores[5]);
        guardaEnLista(prohibidosF2, new int[]{valores[3][0], valores[3][1], valores[3][2],
            valores[4][0], valores[4][1], valores[4][2], valores[5][0], valores[5][1], valores[5][2]});
    guardaEnLista(prohibidosF2, new int[]{valores[2][2], valores[2][5], valores[2][8],
        valores[5][2], valores[5][5], valores[5][8], valores[8][2], valores[8][5], valores[8][8]});
        validaCasillas(f2, evt);
        validaValoresSalidos(prohibidosF2, evt);
    }//GEN-LAST:event_f2KeyTyped

    private void f1KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_f1KeyTyped
        // TODO add your handling code here:
        int[] valores[] = recojeValores();
        prohibidosF1 = new ArrayList<Integer>();

        guardaEnLista(prohibidosF1, valores[5]);
        guardaEnLista(prohibidosF1, new int[]{valores[3][0], valores[3][1], valores[3][2],
            valores[4][0], valores[4][1], valores[4][2], valores[5][0], valores[5][1], valores[5][2]});
    guardaEnLista(prohibidosF1, new int[]{valores[2][1], valores[2][4], valores[2][7],
        valores[5][1], valores[5][4], valores[5][7], valores[8][1], valores[8][4], valores[8][7]});
        validaCasillas(f1, evt);
        validaValoresSalidos(prohibidosF1, evt);
    }//GEN-LAST:event_f1KeyTyped

    private void f0KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_f0KeyTyped
        // TODO add your handling code here:

        int[] valores[] = recojeValores();
        prohibidosF0 = new ArrayList<Integer>();

        guardaEnLista(prohibidosF0, valores[5]);
        guardaEnLista(prohibidosF0, new int[]{valores[3][0], valores[3][1], valores[3][2],
            valores[4][0], valores[4][1], valores[4][2], valores[5][0], valores[5][1], valores[5][2]});
    guardaEnLista(prohibidosF0, new int[]{valores[2][0], valores[2][3], valores[2][6],
        valores[5][0], valores[5][3], valores[5][6], valores[8][0], valores[8][3], valores[8][6]});
        validaCasillas(f0, evt);
        validaValoresSalidos(prohibidosF0, evt);
    }//GEN-LAST:event_f0KeyTyped

    private void e2KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_e2KeyTyped
        // TODO add your handling code here:

        int[] valores[] = recojeValores();
        prohibidosE2 = new ArrayList<Integer>();

        guardaEnLista(prohibidosE2, valores[4]);
        guardaEnLista(prohibidosE2, new int[]{valores[3][0], valores[3][1], valores[3][2],
            valores[4][0], valores[4][1], valores[4][2], valores[5][0], valores[5][1], valores[5][2]});
    guardaEnLista(prohibidosE2, new int[]{
        valores[1][2], valores[1][5], valores[1][8], valores[4][2], valores[4][5], valores[4][8],
        valores[7][2], valores[7][5], valores[7][8]});
        validaCasillas(e2, evt);
        validaValoresSalidos(prohibidosE2, evt);
    }//GEN-LAST:event_e2KeyTyped

    private void e1KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_e1KeyTyped
        // TODO add your handling code here:

        int[] valores[] = recojeValores();
        prohibidosE1 = new ArrayList<Integer>();

        guardaEnLista(prohibidosE1, valores[4]);
        guardaEnLista(prohibidosE1, new int[]{valores[3][0], valores[3][1], valores[3][2],
            valores[4][0], valores[4][1], valores[4][2], valores[5][0], valores[5][1], valores[5][2]});
    guardaEnLista(prohibidosE1, new int[]{
        valores[1][1], valores[1][4], valores[1][7], valores[4][1], valores[4][4], valores[4][7],
        valores[7][1], valores[7][4], valores[7][7]});
        validaValoresSalidos(prohibidosE1, evt);

        validaCasillas(e1, evt);
    }//GEN-LAST:event_e1KeyTyped

    private void d2KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_d2KeyTyped
        // TODO add your handling code here:
        int[] valores[] = recojeValores();
        prohibidosD2 = new ArrayList<Integer>();

        guardaEnLista(prohibidosD2, valores[3]);
        guardaEnLista(prohibidosD2, new int[]{valores[3][0], valores[3][1], valores[3][2],
            valores[4][0], valores[4][1], valores[4][2], valores[5][0], valores[5][1], valores[5][2]});

    guardaEnLista(prohibidosD2, new int[]{valores[0][2], valores[0][5], valores[0][8],
        valores[3][2], valores[3][5], valores[3][8], valores[6][2], valores[6][5], valores[6][8]});
        validaCasillas(d2, evt);
        validaValoresSalidos(prohibidosD2, evt);
    }//GEN-LAST:event_d2KeyTyped

    private void e0KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_e0KeyTyped
        // TODO add your handling code here:

        int[] valores[] = recojeValores();
        prohibidosE0 = new ArrayList<Integer>();

        guardaEnLista(prohibidosE0, valores[4]);
        guardaEnLista(prohibidosE0, new int[]{valores[3][0], valores[3][1], valores[3][2],
            valores[4][0], valores[4][1], valores[4][2], valores[5][0], valores[5][1], valores[5][2]});
    guardaEnLista(prohibidosE0, new int[]{
        valores[1][0], valores[1][3], valores[1][6], valores[4][0], valores[4][3], valores[4][6],
        valores[7][0], valores[7][3], valores[7][6]});
        validaCasillas(e0, evt);
        validaValoresSalidos(prohibidosE0, evt);
    }//GEN-LAST:event_e0KeyTyped

    private void d1KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_d1KeyTyped
        // TODO add your handling code here:
        int[] valores[] = recojeValores();
        prohibidosD1 = new ArrayList<Integer>();

        guardaEnLista(prohibidosD1, valores[3]);
        guardaEnLista(prohibidosD1, new int[]{valores[3][0], valores[3][1], valores[3][2],
            valores[4][0], valores[4][1], valores[4][2], valores[5][0], valores[5][1], valores[5][2]});
    guardaEnLista(prohibidosD1, new int[]{
        valores[0][1], valores[0][4], valores[0][7], valores[3][1], valores[3][4], valores[3][7],
        valores[6][1], valores[6][4], valores[6][7]});
        validaCasillas(d1, evt);
        validaValoresSalidos(prohibidosD1, evt);
    }//GEN-LAST:event_d1KeyTyped

    private void d0KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_d0KeyTyped
        // TODO add your handling code here:

        int[] valores[] = recojeValores();
        prohibidosD0 = new ArrayList<Integer>();

        guardaEnLista(prohibidosD0, valores[3]);
        guardaEnLista(prohibidosD0, new int[]{valores[3][0], valores[3][1], valores[3][2],
            valores[4][0], valores[4][1], valores[4][2], valores[5][0], valores[5][1], valores[5][2]});
    guardaEnLista(prohibidosD0, new int[]{
        valores[0][0], valores[0][3], valores[0][6], valores[3][0], valores[3][3], valores[3][6],
        valores[6][0], valores[6][3], valores[6][6]});
        validaCasillas(d0, evt);
        validaValoresSalidos(prohibidosD0, evt);
    }//GEN-LAST:event_d0KeyTyped

    private void d3KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_d3KeyTyped
        // TODO add your handling code here:
        int[] valores[] = recojeValores();
        prohibidosD3 = new ArrayList<Integer>();

        guardaEnLista(prohibidosD3, valores[3]);
        guardaEnLista(prohibidosD3, new int[]{valores[3][3], valores[3][4], valores[3][5],
            valores[4][3], valores[4][4], valores[4][5], valores[5][3], valores[5][4], valores[5][5]});
    guardaEnLista(prohibidosD3, new int[]{
        valores[0][0], valores[0][3], valores[0][6], valores[3][0], valores[3][3], valores[3][6],
        valores[6][0], valores[6][3], valores[6][6]});
        validaCasillas(d3, evt);
        validaValoresSalidos(prohibidosD3, evt);
    }//GEN-LAST:event_d3KeyTyped

    private void d6KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_d6KeyTyped
        // TODO add your handling code here:
        int[] valores[] = recojeValores();
        prohibidosD6 = new ArrayList<Integer>();

        guardaEnLista(prohibidosD6, valores[3]);
        guardaEnLista(prohibidosD6, new int[]{valores[3][6], valores[3][7], valores[3][8],
            valores[4][6], valores[4][7], valores[4][8], valores[5][6], valores[5][7], valores[5][8]});
    guardaEnLista(prohibidosD6, new int[]{
        valores[0][0], valores[0][3], valores[0][6], valores[3][0], valores[3][3], valores[3][6],
        valores[6][0], valores[6][3], valores[6][6]});
        validaCasillas(d6, evt);
        validaValoresSalidos(prohibidosD6, evt);
    }//GEN-LAST:event_d6KeyTyped

    private void d4KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_d4KeyTyped
        // TODO add your handling code here:
        int[] valores[] = recojeValores();
        prohibidosD4 = new ArrayList<Integer>();

        guardaEnLista(prohibidosD4, valores[3]);
        guardaEnLista(prohibidosD4, new int[]{valores[3][3], valores[3][4], valores[3][5],
            valores[4][3], valores[4][4], valores[4][5], valores[5][3], valores[5][4], valores[5][5]});
    guardaEnLista(prohibidosD4, new int[]{
        valores[0][1], valores[0][4], valores[0][7], valores[3][1], valores[3][4], valores[3][7],
        valores[6][1], valores[6][4], valores[6][7]});

        validaCasillas(d4, evt);
        validaValoresSalidos(prohibidosD4, evt);
    }//GEN-LAST:event_d4KeyTyped

    private void d5KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_d5KeyTyped
        // TODO add your handling code here:
        int[] valores[] = recojeValores();
        prohibidosD5 = new ArrayList<Integer>();

        guardaEnLista(prohibidosD5, valores[3]);
        guardaEnLista(prohibidosD5, new int[]{valores[3][3], valores[3][4], valores[3][5],
            valores[4][3], valores[4][4], valores[4][5], valores[5][3], valores[5][4], valores[5][5]});
    guardaEnLista(prohibidosD5, new int[]{valores[0][2], valores[0][5], valores[0][8],
        valores[3][2], valores[3][5], valores[3][8], valores[6][2], valores[6][5], valores[6][8]});
        validaCasillas(d5, evt);
        validaValoresSalidos(prohibidosD5, evt);
    }//GEN-LAST:event_d5KeyTyped

    private void d8KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_d8KeyTyped
        // TODO add your handling code here:
        int[] valores[] = recojeValores();
        prohibidosD8 = new ArrayList<Integer>();

        guardaEnLista(prohibidosD8, valores[3]);
        guardaEnLista(prohibidosD8, new int[]{valores[3][6], valores[3][7], valores[3][8],
            valores[4][6], valores[4][7], valores[4][8], valores[5][6], valores[5][7], valores[5][8]});
    guardaEnLista(prohibidosD8, new int[]{valores[0][2], valores[0][5], valores[0][8],
        valores[3][2], valores[3][5], valores[3][8], valores[6][2], valores[6][5], valores[6][8]});

        validaCasillas(d8, evt);
        validaValoresSalidos(prohibidosD8, evt);
    }//GEN-LAST:event_d8KeyTyped

    private void d7KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_d7KeyTyped
        // TODO add your handling code here:

        int[] valores[] = recojeValores();
        prohibidosD7 = new ArrayList<Integer>();

        guardaEnLista(prohibidosD7, valores[3]);
        guardaEnLista(prohibidosD7, new int[]{valores[3][6], valores[3][7], valores[3][8],
            valores[4][6], valores[4][7], valores[4][8], valores[5][6], valores[5][7], valores[5][8]});
    guardaEnLista(prohibidosD7, new int[]{
        valores[0][1], valores[0][4], valores[0][7], valores[3][1], valores[3][4], valores[3][7],
        valores[6][1], valores[6][4], valores[6][7]});

        validaCasillas(d7, evt);
        validaValoresSalidos(prohibidosD7, evt);
    }//GEN-LAST:event_d7KeyTyped

    private void e3KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_e3KeyTyped
        // TODO add your handling code here:

        int[] valores[] = recojeValores();
        prohibidosE3 = new ArrayList<Integer>();

        guardaEnLista(prohibidosE3, valores[4]);
        guardaEnLista(prohibidosE3, new int[]{valores[3][3], valores[3][4], valores[3][5],
            valores[4][3], valores[4][4], valores[4][5], valores[5][3], valores[5][4], valores[5][5]});
    guardaEnLista(prohibidosE3, new int[]{
        valores[1][0], valores[1][3], valores[1][6], valores[4][0], valores[4][3], valores[4][6],
        valores[7][0], valores[7][3], valores[7][6]});

        validaCasillas(e3, evt);
        validaValoresSalidos(prohibidosE3, evt);
    }//GEN-LAST:event_e3KeyTyped

    private void e4KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_e4KeyTyped
        // TODO add your handling code here:
        int[] valores[] = recojeValores();
        prohibidosE4 = new ArrayList<Integer>();

        guardaEnLista(prohibidosE4, valores[4]);
        guardaEnLista(prohibidosE4, new int[]{valores[3][3], valores[3][4], valores[3][5],
            valores[4][3], valores[4][4], valores[4][5], valores[5][3], valores[5][4], valores[5][5]});

    guardaEnLista(prohibidosE4, new int[]{
        valores[1][1], valores[1][4], valores[1][7], valores[4][1], valores[4][4], valores[4][7],
        valores[7][1], valores[7][4], valores[7][7]});

        validaCasillas(e4, evt);
        validaValoresSalidos(prohibidosE4, evt);
    }//GEN-LAST:event_e4KeyTyped

    private void e5KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_e5KeyTyped
        // TODO add your handling code here:
        int[] valores[] = recojeValores();
        prohibidosE5 = new ArrayList<Integer>();

        guardaEnLista(prohibidosE5, valores[4]);
        guardaEnLista(prohibidosE5, new int[]{valores[3][3], valores[3][4], valores[3][5],
            valores[4][3], valores[4][4], valores[4][5], valores[5][3], valores[5][4], valores[5][5]});
    guardaEnLista(prohibidosE5, new int[]{
        valores[1][2], valores[1][5], valores[1][8], valores[4][2], valores[4][5], valores[4][8],
        valores[7][2], valores[7][5], valores[7][8]});
        validaCasillas(e5, evt);
        validaValoresSalidos(prohibidosE5, evt);
    }//GEN-LAST:event_e5KeyTyped

    private void e8KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_e8KeyTyped
        // TODO add your handling code here:
        int[] valores[] = recojeValores();
        prohibidosE8 = new ArrayList<Integer>();

        guardaEnLista(prohibidosE8, valores[4]);
        guardaEnLista(prohibidosE8, new int[]{valores[3][6], valores[3][7], valores[3][8],
            valores[4][6], valores[4][7], valores[4][8], valores[5][6], valores[5][7], valores[5][8]});
    guardaEnLista(prohibidosE8, new int[]{
        valores[1][2], valores[1][5], valores[1][8], valores[4][2], valores[4][5], valores[4][8],
        valores[7][2], valores[7][5], valores[7][8]});
        validaCasillas(e8, evt);
        validaValoresSalidos(prohibidosE8, evt);
    }//GEN-LAST:event_e8KeyTyped

    private void e7KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_e7KeyTyped
        // TODO add your andling code here:
        int[] valores[] = recojeValores();
        prohibidosE7 = new ArrayList<Integer>();

        guardaEnLista(prohibidosE7, valores[4]);
        guardaEnLista(prohibidosE7, new int[]{valores[3][6], valores[3][7], valores[3][8],
            valores[4][6], valores[4][7], valores[4][8], valores[5][6], valores[5][7], valores[5][8]});

    guardaEnLista(prohibidosE7, new int[]{
        valores[1][1], valores[1][4], valores[1][7], valores[4][1], valores[4][4], valores[4][7],
        valores[7][1], valores[7][4], valores[7][7]});
        validaCasillas(e7, evt);
        validaValoresSalidos(prohibidosE7, evt);
    }//GEN-LAST:event_e7KeyTyped

    private void e6KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_e6KeyTyped
        // TODO add your handling code here:
        int[] valores[] = recojeValores();
        prohibidosE6 = new ArrayList<Integer>();

        guardaEnLista(prohibidosE6, valores[4]);
        guardaEnLista(prohibidosE6, new int[]{valores[3][6], valores[3][7], valores[3][8],
            valores[4][6], valores[4][7], valores[4][8], valores[5][6], valores[5][7], valores[5][8]});
    guardaEnLista(prohibidosE6, new int[]{
        valores[1][0], valores[1][3], valores[1][6], valores[4][0], valores[4][3], valores[4][6],
        valores[7][0], valores[7][3], valores[7][6]});

        validaCasillas(e6, evt);
        validaValoresSalidos(prohibidosE6, evt);
    }//GEN-LAST:event_e6KeyTyped

    private void f3KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_f3KeyTyped
        // TODO add your handling code here:
        int[] valores[] = recojeValores();
        prohibidosF3 = new ArrayList<Integer>();

        guardaEnLista(prohibidosF3, valores[5]);
        guardaEnLista(prohibidosF3, new int[]{valores[3][3], valores[3][4], valores[3][5],
            valores[4][3], valores[4][4], valores[4][5], valores[5][3], valores[5][4], valores[5][5]});
    guardaEnLista(prohibidosF3, new int[]{valores[2][0], valores[2][3], valores[2][6],
        valores[5][0], valores[5][3], valores[5][6], valores[8][0], valores[8][3], valores[8][6]});
        validaCasillas(f3, evt);
        validaValoresSalidos(prohibidosF3, evt);
    }//GEN-LAST:event_f3KeyTyped

    private void f4KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_f4KeyTyped
        // TODO add your handling code here:
        int[] valores[] = recojeValores();
        prohibidosF4 = new ArrayList<Integer>();

        guardaEnLista(prohibidosF4, valores[5]);
        guardaEnLista(prohibidosF4, new int[]{valores[3][3], valores[3][4], valores[3][5],
            valores[4][3], valores[4][4], valores[4][5], valores[5][3], valores[5][4], valores[5][5]});
    guardaEnLista(prohibidosF4, new int[]{valores[2][1], valores[2][4], valores[2][7],
        valores[5][1], valores[5][4], valores[5][7], valores[8][1], valores[8][4], valores[8][7]});
        validaCasillas(f4, evt);
        validaValoresSalidos(prohibidosF4, evt);
    }//GEN-LAST:event_f4KeyTyped

    private void f5KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_f5KeyTyped
        // TODO add your handling code here:
        int[] valores[] = recojeValores();
        prohibidosF5 = new ArrayList<Integer>();

        guardaEnLista(prohibidosF5, valores[5]);
        guardaEnLista(prohibidosF5, new int[]{valores[3][3], valores[3][4], valores[3][5],
            valores[4][3], valores[4][4], valores[4][5], valores[5][3], valores[5][4], valores[5][5]});
    guardaEnLista(prohibidosF5, new int[]{valores[2][2], valores[2][5], valores[2][8],
        valores[5][2], valores[5][5], valores[5][8], valores[8][2], valores[8][5], valores[8][8]});
        validaCasillas(f5, evt);
        validaValoresSalidos(prohibidosF5, evt);
    }//GEN-LAST:event_f5KeyTyped

    private void f8KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_f8KeyTyped
        // TODO add your handling code here:
        int[] valores[] = recojeValores();
        prohibidosF8 = new ArrayList<Integer>();

        guardaEnLista(prohibidosF8, valores[5]);
        guardaEnLista(prohibidosF8, new int[]{valores[3][6], valores[3][7], valores[3][8],
            valores[4][6], valores[4][7], valores[4][8], valores[5][6], valores[5][7], valores[5][8]});
    guardaEnLista(prohibidosF8, new int[]{valores[2][2], valores[2][5], valores[2][8],
        valores[5][2], valores[5][5], valores[5][8], valores[8][2], valores[8][5], valores[8][8]});
        validaCasillas(f8, evt);
        validaValoresSalidos(prohibidosF8, evt);
    }//GEN-LAST:event_f8KeyTyped

    private void f7KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_f7KeyTyped
        // TODO add your handling code here:
        int[] valores[] = recojeValores();
        prohibidosF7 = new ArrayList<Integer>();

        guardaEnLista(prohibidosF7, valores[5]);
        guardaEnLista(prohibidosF7, new int[]{valores[3][6], valores[3][7], valores[3][8],
            valores[4][6], valores[4][7], valores[4][8], valores[5][6], valores[5][7], valores[5][8]});
    guardaEnLista(prohibidosF7, new int[]{valores[2][1], valores[2][4], valores[2][7],
        valores[5][1], valores[5][4], valores[5][7], valores[8][1], valores[8][4], valores[8][7]});
        validaCasillas(f7, evt);
        validaValoresSalidos(prohibidosF7, evt);
    }//GEN-LAST:event_f7KeyTyped

    private void f6KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_f6KeyTyped
        // TODO add your handling code here:
        int[] valores[] = recojeValores();
        prohibidosF6 = new ArrayList<Integer>();

        guardaEnLista(prohibidosF6, valores[5]);
        guardaEnLista(prohibidosF6, new int[]{valores[3][6], valores[3][7], valores[3][8],
            valores[4][6], valores[4][7], valores[4][8], valores[5][6], valores[5][7], valores[5][8]});
    guardaEnLista(prohibidosF6, new int[]{valores[2][0], valores[2][3], valores[2][6],
        valores[5][0], valores[5][3], valores[5][6], valores[8][0], valores[8][3], valores[8][6]});
        validaCasillas(f6, evt);
        validaValoresSalidos(prohibidosF6, evt);
    }//GEN-LAST:event_f6KeyTyped

    private void i0KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_i0KeyTyped
        // TODO add your handling code here:
        int[] valores[] = recojeValores();
        prohibidosI0 = new ArrayList<Integer>();

        guardaEnLista(prohibidosI0, valores[8]);
        guardaEnLista(prohibidosI0, new int[]{valores[6][0], valores[6][1], valores[6][2],
            valores[7][0], valores[7][1], valores[7][2], valores[8][0], valores[8][1], valores[8][2]});
    guardaEnLista(prohibidosI0, new int[]{valores[2][0], valores[2][3], valores[2][6],
        valores[5][0], valores[5][3], valores[5][6], valores[8][0], valores[8][3], valores[8][6]});
        validaCasillas(i0, evt);
        validaValoresSalidos(prohibidosI0, evt);
    }//GEN-LAST:event_i0KeyTyped

    private void i1KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_i1KeyTyped
        // TODO add your handling code here:
        int[] valores[] = recojeValores();
        prohibidosI1 = new ArrayList<Integer>();

        guardaEnLista(prohibidosI1, valores[8]);
        guardaEnLista(prohibidosI1, new int[]{valores[6][0], valores[6][1], valores[6][2],
            valores[7][0], valores[7][1], valores[7][2], valores[8][0], valores[8][1], valores[8][2]});
    guardaEnLista(prohibidosI1, new int[]{valores[2][1], valores[2][4], valores[2][7],
        valores[5][1], valores[5][4], valores[5][7], valores[8][1], valores[8][4], valores[8][7]});
        validaCasillas(i1, evt);
        validaValoresSalidos(prohibidosI1, evt);
    }//GEN-LAST:event_i1KeyTyped

    private void i2KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_i2KeyTyped
        // TODO add your handling code here:
        int[] valores[] = recojeValores();
        prohibidosI2 = new ArrayList<Integer>();

        guardaEnLista(prohibidosI2, valores[8]);
        guardaEnLista(prohibidosI2, new int[]{valores[6][0], valores[6][1], valores[6][2],
            valores[7][0], valores[7][1], valores[7][2], valores[8][0], valores[8][1], valores[8][2]});
    guardaEnLista(prohibidosI2, new int[]{valores[2][2], valores[2][5], valores[2][8],
        valores[5][2], valores[5][5], valores[5][8], valores[8][2], valores[8][5], valores[8][8]});
        validaCasillas(i2, evt);
        validaValoresSalidos(prohibidosI2, evt);
    }//GEN-LAST:event_i2KeyTyped

    private void i5KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_i5KeyTyped
        // TODO add your handling code here:
        int[] valores[] = recojeValores();
        prohibidosI5 = new ArrayList<Integer>();

        guardaEnLista(prohibidosI5, valores[8]);
        guardaEnLista(prohibidosI5, new int[]{valores[6][3], valores[6][4], valores[6][5],
            valores[7][3], valores[7][4], valores[7][5], valores[8][3], valores[8][4], valores[8][5]});
    guardaEnLista(prohibidosI5, new int[]{valores[2][2], valores[2][5], valores[2][8],
        valores[5][2], valores[5][5], valores[5][8], valores[8][2], valores[8][5], valores[8][8]});
        validaCasillas(i5, evt);
        validaValoresSalidos(prohibidosI5, evt);
    }//GEN-LAST:event_i5KeyTyped

    private void i4KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_i4KeyTyped
        // TODO add your handling code here:
        int[] valores[] = recojeValores();
        prohibidosI4 = new ArrayList<Integer>();

        guardaEnLista(prohibidosI4, valores[8]);
        guardaEnLista(prohibidosI4, new int[]{valores[6][3], valores[6][4], valores[6][5],
            valores[7][3], valores[7][4], valores[7][5], valores[8][3], valores[8][4], valores[8][5]});
    guardaEnLista(prohibidosI4, new int[]{valores[2][1], valores[2][4], valores[2][7],
        valores[5][1], valores[5][4], valores[5][7], valores[8][1], valores[8][4], valores[8][7]});
        validaCasillas(i4, evt);
        validaValoresSalidos(prohibidosI4, evt);
    }//GEN-LAST:event_i4KeyTyped

    private void i3KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_i3KeyTyped
        // TODO add your handling code here:
        int[] valores[] = recojeValores();
        prohibidosI3 = new ArrayList<Integer>();

        guardaEnLista(prohibidosI3, valores[8]);
        guardaEnLista(prohibidosI3, new int[]{valores[6][3], valores[6][4], valores[6][5],
            valores[7][3], valores[7][4], valores[7][5], valores[8][3], valores[8][4], valores[8][5]});
    guardaEnLista(prohibidosI3, new int[]{valores[2][0], valores[2][3], valores[2][6],
        valores[5][0], valores[5][3], valores[5][6], valores[8][0], valores[8][3], valores[8][6]});
        validaCasillas(i3, evt);
        validaValoresSalidos(prohibidosI3, evt);
    }//GEN-LAST:event_i3KeyTyped

    private void i6KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_i6KeyTyped
        // TODO add your handling code here:
        int[] valores[] = recojeValores();
        prohibidosI6 = new ArrayList<Integer>();

        guardaEnLista(prohibidosI6, valores[8]);
        guardaEnLista(prohibidosI6, new int[]{valores[6][6], valores[6][7], valores[6][8],
            valores[7][6], valores[7][7], valores[7][8], valores[8][6], valores[8][7], valores[8][8]});
    guardaEnLista(prohibidosI6, new int[]{valores[2][0], valores[2][3], valores[2][6],
        valores[5][0], valores[5][3], valores[5][6], valores[8][0], valores[8][3], valores[8][6]});
        validaCasillas(i6, evt);
        validaValoresSalidos(prohibidosI6, evt);
    }//GEN-LAST:event_i6KeyTyped

    private void i7KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_i7KeyTyped
        // TODO add your handling code here:
        int[] valores[] = recojeValores();
        prohibidosI7 = new ArrayList<Integer>();

        guardaEnLista(prohibidosI7, valores[8]);
        guardaEnLista(prohibidosI7, new int[]{valores[6][6], valores[6][7], valores[6][8],
            valores[7][6], valores[7][7], valores[7][8], valores[8][6], valores[8][7], valores[8][8]});
    guardaEnLista(prohibidosI7, new int[]{valores[2][1], valores[2][4], valores[2][7],
        valores[5][1], valores[5][4], valores[5][7], valores[8][1], valores[8][4], valores[8][7]});
        validaCasillas(i7, evt);
        validaValoresSalidos(prohibidosI7, evt);
    }//GEN-LAST:event_i7KeyTyped

    private void i8KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_i8KeyTyped
        // TODO add your handling code here:
        int[] valores[] = recojeValores();
        prohibidosI8 = new ArrayList<Integer>();

        guardaEnLista(prohibidosI8, valores[8]);
        guardaEnLista(prohibidosI8, new int[]{valores[6][6], valores[6][7], valores[6][8],
            valores[7][6], valores[7][7], valores[7][8], valores[8][6], valores[8][7], valores[8][8]});
    guardaEnLista(prohibidosI8, new int[]{valores[2][2], valores[2][5], valores[2][8],
        valores[5][2], valores[5][5], valores[5][8], valores[8][2], valores[8][5], valores[8][8]});

        validaCasillas(i8, evt);
        validaValoresSalidos(prohibidosI8, evt);
    }//GEN-LAST:event_i8KeyTyped

    private void h8KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_h8KeyTyped
        // TODO add your handling code here:
        int[] valores[] = recojeValores();
        prohibidosH8 = new ArrayList<Integer>();

        guardaEnLista(prohibidosH8, valores[7]);
        guardaEnLista(prohibidosH8, new int[]{valores[6][6], valores[6][7], valores[6][8],
            valores[7][6], valores[7][7], valores[7][8], valores[8][6], valores[8][7], valores[8][8]});
    guardaEnLista(prohibidosH8, new int[]{
        valores[1][2], valores[1][5], valores[1][8], valores[4][2], valores[4][5], valores[4][8],
        valores[7][2], valores[7][5], valores[7][8]});
        validaCasillas(h8, evt);
        validaValoresSalidos(prohibidosH8, evt);
    }//GEN-LAST:event_h8KeyTyped

    private void h5KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_h5KeyTyped
        // TODO add your handling code here:
        int[] valores[] = recojeValores();
        prohibidosH5 = new ArrayList<Integer>();

        guardaEnLista(prohibidosH5, valores[7]);
        guardaEnLista(prohibidosH5, new int[]{valores[6][3], valores[6][4], valores[6][5],
            valores[7][3], valores[7][4], valores[7][5], valores[8][3], valores[8][4], valores[8][5]});
    guardaEnLista(prohibidosH5, new int[]{
        valores[1][2], valores[1][5], valores[1][8], valores[4][2], valores[4][5], valores[4][8],
        valores[7][2], valores[7][5], valores[7][8]});
        validaCasillas(h5, evt);
        validaValoresSalidos(prohibidosH5, evt);
    }//GEN-LAST:event_h5KeyTyped

    private void h2KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_h2KeyTyped
        // TODO add your handling code here:
        // TODO add your handling code here:
        int[] valores[] = recojeValores();
        prohibidosH2 = new ArrayList<Integer>();

        guardaEnLista(prohibidosH2, valores[7]);
        guardaEnLista(prohibidosH2, new int[]{valores[6][0], valores[6][1], valores[6][2],
            valores[7][0], valores[7][1], valores[7][2], valores[8][0], valores[8][1], valores[8][2]});
    guardaEnLista(prohibidosH2, new int[]{
        valores[1][2], valores[1][5], valores[1][8], valores[4][2], valores[4][5], valores[4][8],
        valores[7][2], valores[7][5], valores[7][8]});
        validaCasillas(h2, evt);
        validaValoresSalidos(prohibidosH2, evt);
    }//GEN-LAST:event_h2KeyTyped

    private void h1KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_h1KeyTyped
        // TODO add your handling code here:
        int[] valores[] = recojeValores();
        prohibidosH1 = new ArrayList<Integer>();

        guardaEnLista(prohibidosH1, valores[7]);
        guardaEnLista(prohibidosH1, new int[]{valores[6][0], valores[6][1], valores[6][2],
            valores[7][0], valores[7][1], valores[7][2], valores[8][0], valores[8][1], valores[8][2]});
    guardaEnLista(prohibidosH1, new int[]{
        valores[1][1], valores[1][4], valores[1][7], valores[4][1], valores[4][4], valores[4][7],
        valores[7][1], valores[7][4], valores[7][7]});
        validaCasillas(h1, evt);
        validaValoresSalidos(prohibidosH1, evt);
    }//GEN-LAST:event_h1KeyTyped

    private void h0KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_h0KeyTyped
        // TODO add your handling code here:

        int[] valores[] = recojeValores();
        prohibidosH0 = new ArrayList<Integer>();

        guardaEnLista(prohibidosH0, valores[7]);
        guardaEnLista(prohibidosH0, new int[]{valores[6][0], valores[6][1], valores[6][2],
            valores[7][0], valores[7][1], valores[7][2], valores[8][0], valores[8][1], valores[8][2]});
    guardaEnLista(prohibidosH0, new int[]{
        valores[1][0], valores[1][3], valores[1][6], valores[4][0], valores[4][3], valores[4][6],
        valores[7][0], valores[7][3], valores[7][6]});
        validaCasillas(h0, evt);
        validaValoresSalidos(prohibidosH0, evt);
    }//GEN-LAST:event_h0KeyTyped

    private void h3KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_h3KeyTyped
        // TODO add your handling code here:

        int[] valores[] = recojeValores();
        prohibidosH3 = new ArrayList<Integer>();

        guardaEnLista(prohibidosH3, valores[7]);
        guardaEnLista(prohibidosH3, new int[]{valores[6][3], valores[6][4], valores[6][5],
            valores[7][3], valores[7][4], valores[7][5], valores[8][3], valores[8][4], valores[8][5]});
    guardaEnLista(prohibidosH3, new int[]{
        valores[1][0], valores[1][3], valores[1][6], valores[4][0], valores[4][3], valores[4][6],
        valores[7][0], valores[7][3], valores[7][6]});
        validaCasillas(h3, evt);
        validaValoresSalidos(prohibidosH3, evt);
    }//GEN-LAST:event_h3KeyTyped

    private void h4KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_h4KeyTyped
        // TODO add your handling code here:
        int[] valores[] = recojeValores();
        prohibidosH4 = new ArrayList<Integer>();

        guardaEnLista(prohibidosH4, valores[7]);
        guardaEnLista(prohibidosH4, new int[]{valores[6][3], valores[6][4], valores[6][5],
            valores[7][3], valores[7][4], valores[7][5], valores[8][3], valores[8][4], valores[8][5]});
    guardaEnLista(prohibidosH4, new int[]{
        valores[1][1], valores[1][4], valores[1][7], valores[4][1], valores[4][4], valores[4][7],
        valores[7][1], valores[7][4], valores[7][7]});
        validaCasillas(h4, evt);
        validaValoresSalidos(prohibidosH4, evt);
    }//GEN-LAST:event_h4KeyTyped

    private void h7KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_h7KeyTyped
        // TODO add your handling code here:
        int[] valores[] = recojeValores();
        prohibidosH7 = new ArrayList<Integer>();

        guardaEnLista(prohibidosH7, valores[7]);
        guardaEnLista(prohibidosH7, new int[]{valores[6][6], valores[6][7], valores[6][8],
            valores[7][6], valores[7][7], valores[7][8], valores[8][6], valores[8][7], valores[8][8]});
    guardaEnLista(prohibidosH7, new int[]{
        valores[1][1], valores[1][4], valores[1][7], valores[4][1], valores[4][4], valores[4][7],
        valores[7][1], valores[7][4], valores[7][7]});
        validaCasillas(h7, evt);
        validaValoresSalidos(prohibidosH7, evt);
    }//GEN-LAST:event_h7KeyTyped

    private void h6KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_h6KeyTyped
        // TODO add your handling code here:
        int[] valores[] = recojeValores();
        prohibidosH6 = new ArrayList<Integer>();

        guardaEnLista(prohibidosH6, valores[7]);
        guardaEnLista(prohibidosH6, new int[]{valores[6][6], valores[6][7], valores[6][8],
            valores[7][6], valores[7][7], valores[7][8], valores[8][6], valores[8][7], valores[8][8]});
    guardaEnLista(prohibidosH6, new int[]{
        valores[1][0], valores[1][3], valores[1][6], valores[4][0], valores[4][3], valores[4][6],
        valores[7][0], valores[7][3], valores[7][6]});

        validaCasillas(h6, evt);
        validaValoresSalidos(prohibidosH6, evt);
    }//GEN-LAST:event_h6KeyTyped

    private void g8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_g8ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_g8ActionPerformed

    private void g8KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_g8KeyTyped
        // TODO add your handling code here:

        int[] valores[] = recojeValores();
        prohibidosG8 = new ArrayList<Integer>();

        guardaEnLista(prohibidosG8, valores[6]);
        guardaEnLista(prohibidosG8, new int[]{valores[6][6], valores[6][7], valores[6][8],
            valores[7][6], valores[7][7], valores[7][8], valores[8][6], valores[8][7], valores[8][8]});
    guardaEnLista(prohibidosG8, new int[]{valores[0][2], valores[0][5], valores[0][8],
        valores[3][2], valores[3][5], valores[3][8], valores[6][2], valores[6][5], valores[6][8]});
        validaCasillas(g8, evt);
        validaValoresSalidos(prohibidosG8, evt);
    }//GEN-LAST:event_g8KeyTyped

    private void g5KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_g5KeyTyped
        // TODO add your handling code here:

        int[] valores[] = recojeValores();
        prohibidosG5 = new ArrayList<Integer>();

        guardaEnLista(prohibidosG5, valores[6]);
        guardaEnLista(prohibidosG5, new int[]{valores[6][3], valores[6][4], valores[6][5],
            valores[7][3], valores[7][4], valores[7][5], valores[8][3], valores[8][4], valores[8][5]});
    guardaEnLista(prohibidosG5, new int[]{valores[0][2], valores[0][5], valores[0][8],
        valores[3][2], valores[3][5], valores[3][8], valores[6][2], valores[6][5], valores[6][8]});
        validaCasillas(g5, evt);
        validaValoresSalidos(prohibidosG5, evt);
    }//GEN-LAST:event_g5KeyTyped

    private void g2KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_g2KeyTyped
        // TODO add your handling code here:
        int[] valores[] = recojeValores();
        prohibidosG2 = new ArrayList<Integer>();

        guardaEnLista(prohibidosG2, valores[6]);
        guardaEnLista(prohibidosG2, new int[]{valores[6][0], valores[6][1], valores[6][2],
            valores[7][0], valores[7][1], valores[7][2], valores[8][0], valores[8][1], valores[8][2]});

    guardaEnLista(prohibidosG2, new int[]{valores[0][2], valores[0][5], valores[0][8],
        valores[3][2], valores[3][5], valores[3][8], valores[6][2], valores[6][5], valores[6][8]});
        validaCasillas(g2, evt);
        validaValoresSalidos(prohibidosG2, evt);
    }//GEN-LAST:event_g2KeyTyped

    private void g1KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_g1KeyTyped
        // TODO add your handling code here:
        int[] valores[] = recojeValores();
        prohibidosG1 = new ArrayList<Integer>();

        guardaEnLista(prohibidosG1, valores[6]);
        guardaEnLista(prohibidosG1, new int[]{valores[6][0], valores[6][1], valores[6][2],
            valores[7][0], valores[7][1], valores[7][2], valores[8][0], valores[8][1], valores[8][2]});
    guardaEnLista(prohibidosG1, new int[]{
        valores[0][1], valores[0][4], valores[0][7], valores[3][1], valores[3][4], valores[3][7],
        valores[6][1], valores[6][7], valores[6][7]});
        validaCasillas(g1, evt);
        validaValoresSalidos(prohibidosG1, evt);
    }//GEN-LAST:event_g1KeyTyped

    private void g0KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_g0KeyTyped
        // TODO add your handling code here:
        int[] valores[] = recojeValores();
        prohibidosG0 = new ArrayList<Integer>();

        guardaEnLista(prohibidosG0, valores[6]);
        guardaEnLista(prohibidosG0, new int[]{valores[6][0], valores[6][1], valores[6][2],
            valores[7][0], valores[7][1], valores[7][2], valores[8][0], valores[8][1], valores[8][2]});
    guardaEnLista(prohibidosG0, new int[]{
        valores[0][0], valores[0][3], valores[0][6], valores[3][0], valores[3][3], valores[3][6],
        valores[6][0], valores[6][3], valores[6][6]});
        validaCasillas(g0, evt);
        validaValoresSalidos(prohibidosG0, evt);
    }//GEN-LAST:event_g0KeyTyped

    private void g3KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_g3KeyTyped
        // TODO add your handling code here:
        int[] valores[] = recojeValores();
        prohibidosG3 = new ArrayList<Integer>();

        guardaEnLista(prohibidosG3, valores[6]);
        guardaEnLista(prohibidosG3, new int[]{valores[6][3], valores[6][4], valores[6][5],
            valores[7][3], valores[7][4], valores[7][5], valores[8][3], valores[8][4], valores[8][5]});
    guardaEnLista(prohibidosG3, new int[]{
        valores[0][0], valores[0][3], valores[0][6], valores[3][0], valores[3][3], valores[3][6],
        valores[6][0], valores[6][3], valores[6][6]});
        validaCasillas(g3, evt);
        validaValoresSalidos(prohibidosG3, evt);
    }//GEN-LAST:event_g3KeyTyped

    private void g4KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_g4KeyTyped
        // TODO add your handling code here:
        int[] valores[] = recojeValores();
        prohibidosG4 = new ArrayList<Integer>();

        guardaEnLista(prohibidosG4, valores[6]);
        guardaEnLista(prohibidosG4, new int[]{valores[6][3], valores[6][4], valores[6][5],
            valores[7][3], valores[7][4], valores[7][5], valores[8][3], valores[8][4], valores[8][5]});
    guardaEnLista(prohibidosG4, new int[]{
        valores[0][1], valores[0][4], valores[0][7], valores[3][1], valores[3][4], valores[3][7],
        valores[6][1], valores[6][4], valores[6][7]});
        validaCasillas(g4, evt);
        validaValoresSalidos(prohibidosG4, evt);
    }//GEN-LAST:event_g4KeyTyped

    private void g7KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_g7KeyTyped
        // TODO add your handling code here:

        int[] valores[] = recojeValores();
        prohibidosG7 = new ArrayList<Integer>();

        guardaEnLista(prohibidosG7, valores[6]);
        guardaEnLista(prohibidosG7, new int[]{valores[6][6], valores[6][7], valores[6][8],
            valores[7][6], valores[7][7], valores[7][8], valores[8][6], valores[8][7], valores[8][8]});
    guardaEnLista(prohibidosG7, new int[]{
        valores[0][1], valores[0][4], valores[0][7], valores[3][1], valores[3][4], valores[3][7],
        valores[6][1], valores[6][4], valores[6][7]});
        validaCasillas(g7, evt);
        validaValoresSalidos(prohibidosG7, evt);
    }//GEN-LAST:event_g7KeyTyped

    private void g6KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_g6KeyTyped
        // TODO add your handling code here:

        int[] valores[] = recojeValores();
        prohibidosG6 = new ArrayList<Integer>();

        guardaEnLista(prohibidosG6, valores[6]);
        guardaEnLista(prohibidosG6, new int[]{valores[6][6], valores[6][7], valores[6][8],
            valores[7][6], valores[7][7], valores[7][8], valores[8][6], valores[8][7], valores[8][8]});
    guardaEnLista(prohibidosG6, new int[]{
        valores[0][0], valores[0][3], valores[0][6], valores[3][0], valores[3][3], valores[3][6],
        valores[6][0], valores[6][3], valores[6][6]});
        validaCasillas(g6, evt);
        validaValoresSalidos(prohibidosG6, evt);
    }//GEN-LAST:event_g6KeyTyped

    public  void pararEjecucionSudoku(){
        resolv.stop();
    }
    
    private void btnPararActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPararActionPerformed
        // TODO add your handling code here:
        // para el hilo
        resolv.stop();
        // y lo destruye
        //   resolv.destroy();
        // se vuelven a visualizar las imágenes
        imgCargando.setVisible(false);
        btnParar.setVisible(false);

        activaBotones();
        cambiaColorTextoAzul();
        lblTiempo.setText("Tiempo: ");
    }//GEN-LAST:event_btnPararActionPerformed

    private void btnLimpiarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLimpiarActionPerformed
        // TODO add your handling code here:

        limpiarSudoku();
        cambiaColorTextoAzul();
    }//GEN-LAST:event_btnLimpiarActionPerformed

    private void btnResolverActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnResolverActionPerformed

        // GUARDA LOS VALORES DEL LAS CAJAS DE TEXTO
        int[][] valores = recojeValores();

       

        // CREA UN SUDOKU CON LOS VALORES DE LAS CAJAS DE TEXTO
        Sudoku s = new Sudoku(valores);


        // SI EL SUDOKU NO ESTÁ COMPLETO
        if(!s.estaCompleto()){

            if(!s.estaVacio()){
      
               cambiaColorTextoAzul();
              cambiaColorTextoNegro();
                // CREA UN OBJETO PRINCIPAL CON EL SUDOKU, Y EL TABLERO
                Principal resolvedor = new Principal(s, this);
                
                     
                resolv = resolvedor;
       

                // INVISIVILIZA LOS COMPONENTES INTERACTUABLES
                btnParar.setVisible(true);
                imgCargando.setVisible(true);
                desactivarBotones();

                // CAMBIA LA PRIORIDAD DEL HILO A LA MAXIMA
                resolv.setPriority(10);
                // COMIENZA EL HILO
                resolv.start();
            } else{

                JOptionPane.showMessageDialog(null, "Debes introducir al menos un valor");
            }

        }
        else{
            // MUESTRA MENSAJE
            JOptionPane.showMessageDialog(null, "El sudoku ya esta resuelto");
        }
    }//GEN-LAST:event_btnResolverActionPerformed

    
 
    // DEVUELVE LA ETIQUETA TIEMPO
    public javax.swing.JLabel getLblTiempo() {
        return lblTiempo;
    }

    
    @Override
    public Image getIconImage() {
        Image retValue = Toolkit.getDefaultToolkit().
                getImage(ClassLoader.getSystemResource("imagenes/icono3.png"));


        return retValue;
    }
    
   
    
  
    /*
    /**
     * @param args the command line arguments
     */
    
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Tablero.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Tablero.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Tablero.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Tablero.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Tablero().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField a0;
    private javax.swing.JTextField a1;
    private javax.swing.JTextField a2;
    private javax.swing.JTextField a3;
    private javax.swing.JTextField a4;
    private javax.swing.JTextField a5;
    private javax.swing.JTextField a6;
    private javax.swing.JTextField a7;
    private javax.swing.JTextField a8;
    private javax.swing.JTextField b0;
    private javax.swing.JTextField b1;
    private javax.swing.JTextField b2;
    private javax.swing.JTextField b3;
    private javax.swing.JTextField b4;
    private javax.swing.JTextField b5;
    private javax.swing.JTextField b6;
    private javax.swing.JTextField b7;
    private javax.swing.JTextField b8;
    private javax.swing.JButton btnLimpiar;
    private javax.swing.JButton btnParar;
    private javax.swing.JButton btnResolver;
    private javax.swing.JTextField c0;
    private javax.swing.JTextField c1;
    private javax.swing.JTextField c2;
    private javax.swing.JTextField c3;
    private javax.swing.JTextField c4;
    private javax.swing.JTextField c5;
    private javax.swing.JTextField c6;
    private javax.swing.JTextField c7;
    private javax.swing.JTextField c8;
    private javax.swing.JTextField d0;
    private javax.swing.JTextField d1;
    private javax.swing.JTextField d2;
    private javax.swing.JTextField d3;
    private javax.swing.JTextField d4;
    private javax.swing.JTextField d5;
    private javax.swing.JTextField d6;
    private javax.swing.JTextField d7;
    private javax.swing.JTextField d8;
    private javax.swing.JTextField e0;
    private javax.swing.JTextField e1;
    private javax.swing.JTextField e2;
    private javax.swing.JTextField e3;
    private javax.swing.JTextField e4;
    private javax.swing.JTextField e5;
    private javax.swing.JTextField e6;
    private javax.swing.JTextField e7;
    private javax.swing.JTextField e8;
    private javax.swing.JTextField f0;
    private javax.swing.JTextField f1;
    private javax.swing.JTextField f2;
    private javax.swing.JTextField f3;
    private javax.swing.JTextField f4;
    private javax.swing.JTextField f5;
    private javax.swing.JTextField f6;
    private javax.swing.JTextField f7;
    private javax.swing.JTextField f8;
    private javax.swing.JTextField g0;
    private javax.swing.JTextField g1;
    private javax.swing.JTextField g2;
    private javax.swing.JTextField g3;
    private javax.swing.JTextField g4;
    private javax.swing.JTextField g5;
    private javax.swing.JTextField g6;
    private javax.swing.JTextField g7;
    private javax.swing.JTextField g8;
    private javax.swing.JTextField h0;
    private javax.swing.JTextField h1;
    private javax.swing.JTextField h2;
    private javax.swing.JTextField h3;
    private javax.swing.JTextField h4;
    private javax.swing.JTextField h5;
    private javax.swing.JTextField h6;
    private javax.swing.JTextField h7;
    private javax.swing.JTextField h8;
    private javax.swing.JTextField i0;
    private javax.swing.JTextField i1;
    private javax.swing.JTextField i2;
    private javax.swing.JTextField i3;
    private javax.swing.JTextField i4;
    private javax.swing.JTextField i5;
    private javax.swing.JTextField i6;
    private javax.swing.JTextField i7;
    private javax.swing.JTextField i8;
    private javax.swing.JLabel imgCargando;
    private javax.swing.JLabel lblCargando;
    private javax.swing.JLabel lblFondoNegro;
    private javax.swing.JLabel lblTiempo;
    // End of variables declaration//GEN-END:variables
}
