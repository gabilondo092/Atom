﻿Public Class AltaDiario

    Private Sub AltaDiario_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        For i = 1 To 30
            cboDias.Items.Add(i)

        Next

        For i = 1 To 12
            cboMes.Items.Add(i)
        Next

        For i = 2016 To 2018

            cboAño.Items.Add(i)
        Next

        For i = 0 To comboxTra.Items.Count - 1

            cboTra.Items.Add(comboxTra.Items.Item(i))

        Next
        cboTra.SelectedIndex = 0

        txbDia.Text = numeroDiarios + 1

        cboAño.SelectedIndex = 2
        cboMes.SelectedIndex = 6
        cboDias.SelectedIndex = 2



    End Sub

    Private Sub btnGuardar_Click(sender As Object, e As EventArgs) Handles btnGuardar.Click

        If txbCodCli.Text.Length > 0 Then
            If existeCliente(txbCodCli.Text) > -1 Then
                ReDim Preserve diarios(numeroDiarios)

                diarios(numeroDiarios).codCli = txbCodCli.Text
                diarios(numeroDiarios).codDia = txbDia.Text

                diarios(numeroDiarios).fecha = Today ' pongo today porque me salta error y no hay tiempo para solucionar
                diarios(numeroDiarios).codTratamiento = tratamientos(cboTra.SelectedIndex).codigoTra
                numeroDiarios += 1
                txbDia.Text = numeroDiarios + 1
                MessageBox.Show("Tratamiento guardado")

            Else
                MessageBox.Show("El cliente debe existir")
            End If

        Else
            MessageBox.Show("Introduce el cod cliente")
        End If
    End Sub

    Private Sub btnCancelar_Click(sender As Object, e As EventArgs) Handles btnCancelar.Click
        Me.Close()
    End Sub


End Class