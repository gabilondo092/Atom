﻿Public Class Factura
    Private Sub Factura_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        For i = 1 To 12
            cboMes.Items.Add(i)
        Next
        cboMes.SelectedIndex = 1

    End Sub

    Private Sub btnBuscar_Click(sender As Object, e As EventArgs) Handles btnBuscar.Click
        RichTextBox1.Text = "Codigo cli     nombre           tipo             mes"

        If txbCodCli.Text.Length > 0 Then
            Dim ind As Integer = existeCliente(txbCodCli.Text)
            If ind > -1 Then
                Dim cli As Cliente = clientes.Item(ind)
                RichTextBox1.Text = ""
                RichTextBox1.Text = "Nombre: " & cli.nombre & vbCrLf
                RichTextBox1.Text += "Tipo: " & cli.tipo & vbCrLf


            Else

                MessageBox.Show("El cliente no existe")
            End If


        End If


    End Sub
End Class