﻿Public Class Cliente

    Private codigocli As String
    Private nombreCli As String
    Private emailcli As String
    Private telefonoCli As String
    Private tipoCli As String


    Sub New(co As String, nom As String, email As String, tel As Double, tipoc As String)
        codigocli = co
        nombreCli = nom
        emailcli = email
        telefono = tel
        tipoCli = tipoc
    End Sub

    Friend Property codigo() As String
        Get
            Return codigocli
        End Get
        Set(value As String)
            codigocli = value
        End Set
    End Property

    Friend Property nombre() As String
        Get
            Return nombreCli
        End Get
        Set(value As String)
            nombreCli = value
        End Set
    End Property

    Friend Property email() As String
        Get
            Return emailcli
        End Get
        Set(value As String)
            emailcli = value
        End Set
    End Property


    Friend Property telefono() As Double
        Get
            Return telefonoCli
        End Get
        Set(value As Double)
            telefonoCli = value
        End Set
    End Property


    Friend Property tipo() As String
        Get
            Return tipoCli
        End Get
        Set(value As String)
            tipoCli = value
        End Set
    End Property



End Class
