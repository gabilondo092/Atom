﻿Public Class AltaTratamientos
    Private Sub AltaTratamientos_Load(sender As Object, e As EventArgs) Handles MyBase.Load



    End Sub
End Class