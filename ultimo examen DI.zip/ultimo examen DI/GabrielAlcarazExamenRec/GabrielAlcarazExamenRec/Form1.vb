﻿Public Class Form1
    Private Sub ClientesToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ClientesToolStripMenuItem.Click
        AltaCliente.Show()
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        CreaTratamientos()
    End Sub


    ' AQUI SE CREAN LOS TRATAMIENTOS FIJARSE EN IDENTIICADORES
    Private Sub CreaTratamientos()

        For i = 0 To 4
            ReDim Preserve tratamientos(numeroTratamientos)
            tratamientos(numeroTratamientos).codigoTra = i
            tratamientos(numeroTratamientos).nombreTra = "tra" & i
            tratamientos(numeroTratamientos).precioTra = (i + 2) * 2
            comboxTra.Items.Add(tratamientos(numeroTratamientos).nombreTra)
            comboxTraId.Items.Add(tratamientos(numeroTratamientos).codigoTra)
            numeroTratamientos += 1
        Next

    End Sub

    Private Sub TratamientosToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles TratamientosToolStripMenuItem.Click
        AltaDiario.Show()
    End Sub

    Private Sub ConsultaToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ConsultaToolStripMenuItem.Click
        Consultar.Show()
    End Sub

    Private Sub FacturaToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles FacturaToolStripMenuItem.Click
        Factura.Show()
    End Sub

    Private Sub ClientesToolStripMenuItem1_Click(sender As Object, e As EventArgs) Handles ClientesToolStripMenuItem1.Click
        ListadoClientes.Show()
    End Sub

    Private Sub SalirToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SalirToolStripMenuItem.Click
        Me.Close()
    End Sub
End Class
