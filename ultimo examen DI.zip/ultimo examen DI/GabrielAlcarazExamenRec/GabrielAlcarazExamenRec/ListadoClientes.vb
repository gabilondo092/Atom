﻿Public Class ListadoClientes
    Private Sub ListadoClientes_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        For i = 0 To comboxTra.Items.Count - 1

            ComboBox1.Items.Add(comboxTra.Items.Item(i))

        Next
        ComboBox1.SelectedIndex = 0
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Me.Close()
    End Sub

    Private Sub btnGuardar_Click(sender As Object, e As EventArgs) Handles btnConsultar.Click

        Dim tra As Tratamiento = tratamientos(ComboBox1.SelectedIndex)
        RichTextBox1.Text = tra.codigoTra & vbCrLf
        For Each dir As Diario In diarios

            If dir.codTratamiento = tra.codigoTra Then

                For Each c As Cliente In clientes

                    If c.codigo = dir.codCli Then

                        RichTextBox1.Text += c.codigo & "      " & c.nombre & "   " & c.tipo & vbCrLf

                    End If

                Next


            End If

        Next




    End Sub


    Public Sub guardar1()

        Dim tra As Tratamiento = tratamientos(existeTra(ComboBox1.SelectedIndex))
        '     RichTextBox1.Text = tra.codigoTra & "   " & tra.nombreTra

        RichTextBox1.Text = "Codigo tratamiento      Nombre cli           tipo    "
        For Each dir As Diario In diarios
            If dir.codTratamiento = tra.codigoTra Then

                Dim idCli As Integer = dir.codCli
                Dim cli As Cliente = clientes.Item(idCli)

                RichTextBox1.Text += cli.codigo & "      " & cli.nombre & "   " & cli.tipo & vbCrLf


            End If
        Next
    End Sub

End Class