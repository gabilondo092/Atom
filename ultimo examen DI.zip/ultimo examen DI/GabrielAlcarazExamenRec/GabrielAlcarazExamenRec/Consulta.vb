﻿Public Class Consultar
    Private Sub btnBuscar_Click(sender As Object, e As EventArgs) Handles btnBuscar.Click
        If txbCodCli.Text.Length > 0 Then
            Dim ind As Integer = existeCliente(txbCodCli.Text)
            If ind > -1 Then
                Dim cli As Cliente = clientes.Item(ind)
                RichTextBox1.Text = ""
                RichTextBox1.Text = "Nombre: " & cli.nombre & vbCrLf
                RichTextBox1.Text += "Tipo: " & cli.tipo & vbCrLf

                RichTextBox1.Text += "Tratamientos: " & vbCrLf

                For Each dir As Diario In diarios

                    If dir.codCli = cli.codigo Then

                        Dim numTra As Integer = dir.codTratamiento

                        For Each tra As Tratamiento In tratamientos

                            If tra.codigoTra = numTra Then
                                RichTextBox1.Text += tra.nombreTra & vbCrLf
                            End If

                        Next




                    End If

                Next




            Else

                MessageBox.Show("El cliente no existe")
            End If


        End If
    End Sub


    Private Sub btnCancelar_Click(sender As Object, e As EventArgs) Handles btnCancelar.Click
        Me.Close()
    End Sub


End Class