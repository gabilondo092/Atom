﻿Imports System.ComponentModel
Public Class AltaCliente

    Dim erCod As New ErrorProvider
    Dim erNom As New ErrorProvider
    Dim erTel As New ErrorProvider
    Dim erEma As New ErrorProvider
    Dim tipCod As New ToolTip
    Dim tipNom As New ToolTip
    Dim tipTel As New ToolTip
    Dim tipEma As New ToolTip


    Private Sub btnCancelar_Click(sender As Object, e As EventArgs) Handles btnCancelar.Click
        Dim cambios As Boolean = False


        If txbCodigo.Text.Length > 0 Then
            cambios = True
        End If

        If txbNombre.Text.Length > 0 Then
            cambios = True
        End If


        If txbTelefono.Text.Length > 0 Then
            cambios = True
        End If

        If txbEmail.Text.Length > 0 Then
            cambios = True
        End If

        If Not cambios Then

            Me.Close()

        Else
            Dim result As DialogResult = MessageBox.Show("Ha habido cambios desea cerrar", “¿cerrar?”, MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button1)

            If result = DialogResult.Yes Then

                Me.Close()

            End If

        End If




    End Sub

    Private Sub AltaCliente_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        cboTipo.Items.Add("nor")
        cboTipo.Items.Add("way")
        cboTipo.Items.Add("vip")
        cboTipo.SelectedIndex = 0
    End Sub


    Private Sub guardar()

        If txbCodigo.Text.Length > 0 Then
            If txbNombre.Text.Length > 0 Then

                If txbTelefono.Text.Length > 0 Then

                    If txbEmail.Text.Length > 0 Then

                        clientes.Add(New Cliente(txbCodigo.Text, txbNombre.Text, txbEmail.Text, txbTelefono.Text, cboTipo.SelectedItem), txbCodigo.Text)

                        Dim result As DialogResult = MessageBox.Show("¿Desea seguir dando de alta?", “cliente guardado”, MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button1)

                        If result = DialogResult.Yes Then

                            txbCodigo.Text = ""
                            txbEmail.Text = ""
                            txbNombre.Text = ""
                            txbTelefono.Text = ""


                        Else
                            Me.Close()


                        End If


                    Else

                        MessageBox.Show("Introduce el email")

                    End If

                Else
                    MessageBox.Show("Introduce el telefono")
                End If


            Else
                MessageBox.Show("Introduce el nombre")
            End If


        Else
            MessageBox.Show("Debes introducir el código")

        End If

    End Sub

    Private Sub btnGuardar_Click(sender As Object, e As EventArgs) Handles btnGuardar.Click
        guardar()
    End Sub





    Private Sub txbCodigo_Validating(sender As Object, e As CancelEventArgs) Handles txbCodigo.Validating

        If IsNumeric(txbCodigo.Text) Then

            erCod.SetError(txbCodigo, "debe ser texto")
            e.Cancel = True

        Else
            If existeCliente(txbCodigo.Text) > -1 Then
                erCod.SetError(txbCodigo, "El cliente ya existe escoje otro")
                e.Cancel = True

            Else

                erCod.SetError(txbCodigo, "")

            End If




        End If


    End Sub

    Private Sub txbNombre_Validating(sender As Object, e As CancelEventArgs) Handles txbNombre.Validating
        If IsNumeric(txbNombre.Text) Then

            erNom.SetError(txbNombre, "debe ser texto")
            e.Cancel = True

        Else

            erNom.SetError(txbNombre, "")

        End If
    End Sub

    Private Sub txbTelefono_Validating(sender As Object, e As CancelEventArgs) Handles txbTelefono.Validating
        If Not IsNumeric(txbTelefono.Text) Then
            erTel.SetError(txbTelefono, "debe ser numerico")
            e.Cancel = True

        Else

            erTel.SetError(txbTelefono, "")

        End If
    End Sub

    Private Sub txbEmail_Validating(sender As Object, e As CancelEventArgs) Handles txbEmail.Validating
        If IsNumeric(txbEmail.Text) Then

            erEma.SetError(txbEmail, "debe ser texto")
            e.Cancel = True

        Else

            erEma.SetError(txbEmail, "")

        End If
    End Sub

    Private Sub txbCodigo_MouseUp(sender As Object, e As MouseEventArgs) Handles txbCodigo.MouseUp
        tipCod.SetToolTip(txbCodigo, "Introduce texto")
    End Sub

    Private Sub txbNombre_MouseUp(sender As Object, e As MouseEventArgs) Handles txbNombre.MouseUp
        tipNom.SetToolTip(txbNombre, "Introduce texto")
    End Sub

    Private Sub txbTelefono_MouseUp(sender As Object, e As MouseEventArgs) Handles txbTelefono.MouseUp
        tipTel.SetToolTip(txbTelefono, "Introduce numericos")
    End Sub

    Private Sub txbEmail_MouseUp(sender As Object, e As MouseEventArgs) Handles txbEmail.MouseUp
        tipEma.SetToolTip(txbEmail, "Introduce texto")
    End Sub
End Class