﻿Module Module1

    Structure Diario

        Dim codDia As Integer
        Dim codCli As String
        Dim codTratamiento As Integer
        Dim fecha As Date

    End Structure


    Structure Tratamiento
        Dim codigoTra As Integer
        Dim nombreTra As String
        Dim precioTra As Single
    End Structure

    Friend clientes As New Collection
    Friend tratamientos() As Tratamiento
    Friend diarios() As Diario
    Friend numeroTratamientos As Integer = 0
    Friend numeroDiarios As Integer = 0
    Friend comboxTra As New ComboBox
    Friend comboxTraId As New ComboBox


    Friend Function existeCliente(cod As String) As Integer

        For i = 1 To clientes.Count
            Dim cli As Cliente = clientes.Item(i)
            If cli.codigo = cod Then
                Return i
            End If

        Next
        Return -1
    End Function



    Friend Function existeTra(cod As String) As Integer
        For i = 0 To tratamientos.Count
            Dim tra As Tratamiento = tratamientos(i)
            If tra.codigoTra = cod Then
                Return i
            End If

        Next
        Return -1
    End Function



End Module
