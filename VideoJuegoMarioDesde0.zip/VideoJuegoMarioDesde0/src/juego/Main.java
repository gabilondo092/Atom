package juego;

import java.awt.Graphics;
import java.awt.Point;
import java.util.HashMap;

import loaders.ImagesLoader;
import loaders.SoundsLoader;




public class Main extends Stage {
	
	static String g;
	// For load images, sounds and maps.
		private ImagesLoader loader;
		private SoundsLoader sounds;
	//	private Map map;

		// Gravedad del escenario. Defecto 0.2
		private float gravity = 0.07F;

		Point pointCursor = new Point(-1,-1);

		public Main(boolean applet) {
			super(CANVAS);
			setFPS(80);
			setSize(960, 640);
			// Creamos el mapa en el mundo=1 nivel=1.
		//	map = new Map(this, 1, 1);
			// Creamos los cargadores pero de momento
			// no cargamos nada.
		//	loader = new ImagesLoader("res/img", "loader");
		//	sounds = new SoundsLoader("res/sounds", "loader");
			// A�adimos los cargadores de sonido y de
			// imagen a el objeto Stage (superclase).
		//	setImagesLoader(loader);
		//	setSoundsLoader(sounds);
		}
		
		public Main() {
			super(JFRAME);
			setFPS(80);
			setSize(960-6, 640-6);
			window.setResizable(false);
			// Creamos el mapa en el mundo=1 nivel=1.
		//	map = new Map(this, 1, 1);
			// Creamos los cargadores pero de momento
			// no cargamos nada.
			loader = new ImagesLoader("res/img", "loader");
			sounds = new SoundsLoader("res/sounds", "loader");
			// A�adimos los cargadores de sonido y de
			// imagen a el objeto Stage (superclase).
			setImagesLoader(loader);
			setSoundsLoader(sounds);
		}

	public static void main(String[] args) {
		/*
		
		Main p = new Main();
		p.getWindow().setVisible(true);
		p.startGame();
		*/
		// g = getClass().getClassLoader().getResource("").getPath();
		
		HashMap<String, Object> loaded = new HashMap<String,Object>();
		loaded.put("0", "ola");
		System.out.println(loaded.get("0"));
		

	}
	

	@Override
	public void updateStage() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void renderStage(Graphics g) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void initStage() {
		// TODO Auto-generated method stub
		
	}

}
