package util

import java.nio.file.Paths

import com.telefonica.onhr.controller.{DataFrameController, HDFSController, HiveController, JDBCController, SparkController}
import com.telefonica.onhr.entity.Extraction
import com.telefonica.onhr.util.Constants.{HDFSConf, HiveConf}
import com.telefonica.onhr.util.{Constants, MetadataParser}
import org.apache.log4j.PropertyConfigurator
import org.apache.spark.sql.functions.hash
import org.apache.spark.sql.types.StructType
import org.apache.spark.sql.{DataFrame, SparkSession}

trait Settings {

  val propertiesFile = "src/test/resources/conf/properties.json"
  PropertyConfigurator.configure("src/test/resources/conf/log4j.properties")
  Constants.setPropertiesFile(propertiesFile)
  this.updateHDFSConf()

  lazy val spark: SparkSession = new SparkController("SparkTest", true).getSparkSession
  //    spark.sparkContext.setLogLevel("DEBUG")

  lazy val dfController: DataFrameController = new DataFrameController(spark)
  lazy val hiveController: HiveController = new HiveController(spark)
  lazy val JDBCController: JDBCController = new JDBCController
  lazy val HDFSController: HDFSController = new HDFSController

  def getExtraction(extractionName: String): Extraction = {
    new MetadataParser(dfController.readJSON(extractionName)).getExtraction
  }

  def readCsv(fileName: String): DataFrame = {
    dfController.readDataFrame(dfController.getSourcePath(fileName))
  }

  def readExpectedCsv(fileName: String, schema: StructType): DataFrame = {
    val path = Paths.get("src/test/resources/expected", fileName).toString
    var df = this.spark.read.option("header", "true")
                       .option("sep", HDFSConf.defaultSeparator)
                       .option("timestampFormat", HiveConf.timestampFormat)
                       .csv(path)
    schema.foreach { field =>
      df = df.withColumn(field.name, df(field.name).cast(field.dataType))
    }
    df
  }

  def readParquet(extractionName: String): DataFrame = {
    dfController.readDataFrame(dfController.getTargetPath(extractionName), format = "parquet")
  }

  def readDataFrameExtraction(extractionName: String)(implicit extraction: Extraction): DataFrame = {
    dfController.readDataFrameExtraction(extractionName = extractionName)
  }

  def readExtraction(extractionName: String): DataFrame = {
    implicit val extraction: Extraction = this.getExtraction(extractionName)
    dfController.readDataFrameExtraction(extractionName = extractionName)
  }

  def hashColumnDF(df: DataFrame): DataFrame = {
    df.withColumn("col", hash(df.columns.sorted.map(column => df.col(column)): _*))
  }

  def compare(resultDF: DataFrame, expectDF: DataFrame): DataFrame = {
    val hashResult = hashColumnDF(resultDF)
    val hashExpect = hashColumnDF(expectDF)
    hashResult.join(hashExpect, hashResult.col("col").equalTo(hashExpect.col("col")), "left_anti")
  }

  private def updateHDFSConf(): Unit = {
    if (!HDFSConf.rootPath.startsWith("/")) {
      val finalPath = Paths.get(System.getProperty("user.dir"), HDFSConf.rootPath).toString
      HDFSConf.rootPath = finalPath
    }
  }

}
