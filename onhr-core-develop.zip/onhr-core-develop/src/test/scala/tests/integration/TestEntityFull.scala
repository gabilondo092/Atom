package tests.integration

import com.telefonica.onhr.entity.{Entity, Extraction}
import com.telefonica.onhr.util.PathNotExistException
import org.apache.spark.sql.DataFrame
import org.junit.runner.RunWith
import org.scalatest.{BeforeAndAfterAll, BeforeAndAfterEach, FunSuite}
import org.scalatestplus.junit.JUnitRunner
import util.Settings

@RunWith(classOf[JUnitRunner])
class TestEntityFull extends FunSuite with Settings with BeforeAndAfterEach with BeforeAndAfterAll {
  var extractionName: String = _
  var extraction: Extraction = _
  var entity: Entity = _
  var df_expect: DataFrame = _
  var df_result: DataFrame = _
  var hivedf: DataFrame = _
  var extractionNameExpect: String = _


  // Preparando Entorno
  override def beforeAll(): Unit = {
    extractionName = "FOPayRange"
    extraction = getExtraction(extractionName)
    hiveController.runHQLStatement("CREATE SCHEMA onhr_global")
    hiveController.runHQLStatement("CREATE SCHEMA onhr_entity")
  }

  override def afterAll(): Unit = {
    hiveController.runHQLStatement("DROP SCHEMA onhr_global CASCADE")
    hiveController.runHQLStatement("DROP SCHEMA onhr_entity CASCADE")
  }

  // Carga Entidad
//  test("TEST [Carga Entidad] - Leer Entidad / Escribir Parquet") {
//    df_result = readDataFrameExtraction(extractionName = extractionName)(extraction)
//    dfController.writeDataFrame(df_result, isCatalog = true)(extraction)
//    hiveController.runHQLStatement(hiveController.getHQL(df_result, isCatalog = true)(extraction = extraction))
//  }
//
//  test("TEST [Carga Entidad] - Leer CSV / Leer Parquet / Count") {
//    df_expect = readCsv(extractionName)
//    entity = extraction.getEntity(extractionName)
//    hivedf = dfController.readEntity(extractionName)(entity)
//    assert(hivedf.count() == df_expect.count())
//  }
//
//  test("TEST [Carga Entidad] - Leer CSV / Leer Parquet / Contar Columnas") {
//    assert(hivedf.columns.length == df_expect.columns.length)
//  }
//
//  // Columna Extra
//  test("TEST [Columna Extra] - Leer Entidad / Escribir Parquet") {
//    extractionName = "FOPayRangeColMas"
//    extraction = getExtraction(extractionName)
//    df_result = readDataFrameExtraction(extractionName = extractionName)(extraction)
//    dfController.writeDataFrame(df_result, isCatalog = true)(extraction)
//    hiveController.runHQLStatement(hiveController.getHQL(df_result, isCatalog = true)(extraction = extraction))
//  }
//  test("TEST [Columna Extra] - Leer CSV / Leer Parquet / Count") {
//    extractionName = "FOPayRange"
//    extractionNameExpect = "FOPayRangeColMas"
//    df_expect = readCsv(extractionNameExpect)
//    hivedf = dfController.readEntity(extractionName)(entity)
//    assert(hivedf.count() == df_expect.count())
//  }
//
//  test("TEST [Columna Extra] - Leer CSV / Leer Parquet / Contar Columnas") {
//    assert(hivedf.columns.length == df_expect.columns.length)
//  }
//
//  // Columna Menos
//  test("TEST [Columna Menos] - Leer Entidad / Escribir Parquet") {
//    extractionName = "FOPayRangeColMenos"
//    extraction = getExtraction(extractionName)
//    df_result = readDataFrameExtraction(extractionName = extractionName)(extraction)
//    dfController.writeDataFrame(df_result, isCatalog = true)(extraction)
//    hiveController.runHQLStatement(hiveController.getHQL(df_result, isCatalog = true)(extraction = extraction))
//  }
//  test("TEST [Columna Menos] - Leer CSV / Leer Parquet / Count") {
//    extractionName = "FOPayRange"
//    extractionNameExpect = "FOPayRangeColMenos"
//    df_expect = readCsv(extractionNameExpect)
//    hivedf = dfController.readEntity(extractionName)(entity)
//    assert(hivedf.count() == df_expect.count())
//  }
//
//  test("TEST [Columna Menos] - Leer CSV / Leer Parquet / Contar Columnas") {
//    assert(hivedf.columns.length == df_expect.columns.length)
//  }
//
//  // Columna Cambio Tipo
//  test("TEST [Columna Tipo] - Leer Entidad / Escribir Parquet") {
//    extractionName = "FOPayRangeTypeCol"
//    extraction = getExtraction(extractionName)
//    df_result = readDataFrameExtraction(extractionName = extractionName)(extraction)
//    dfController.writeDataFrame(df_result, isCatalog = true)(extraction)
//    hiveController.runHQLStatement(hiveController.getHQL(df_result, isCatalog = true)(extraction = extraction))
//  }
//  test("TEST [Columna Tipo] - Leer CSV / Leer Parquet / Count") {
//    extractionName = "FOPayRange"
//    extractionNameExpect = "FOPayRangeTypeCol"
//    df_expect = readCsv(extractionNameExpect)
//    hivedf = dfController.readEntity(extractionName)(entity)
//    assert(hivedf.count() == df_expect.count())
//  }
//
//  test("TEST [Columna Tipo] - Leer CSV / Leer Parquet / Contar Columnas") {
//    assert(hivedf.columns.length == df_expect.columns.length)
//  }
//
//  // Carga Entidad
//  test("TEST [Carga Entidad Denormalizada] - Leer Entidad / Escribir Parquet") {
//    extractionName = "DENORM"
//    extraction = getExtraction(extractionName)
//    df_result = readDataFrameExtraction(extractionName = extractionName)(extraction)
//
////    if (extraction.needDenormalize) {
////      extraction.getColumnsToDenormalize.foreach { field =>
////        dfController.writeDenormDataFrame(dfController.denormalize(df_result, field), field)(extraction.extractionEntities.head)
////      }
////    }
//  }

  test("Path Fail") {
    assertThrows[PathNotExistException] { // Result type: Assertion
      dfController.getSourcePath("FICHERO_QUE_NO_EXISTE")
    }
  }

}
