package tests.integration

import com.telefonica.onhr.entity.{Entity, Extraction}
import com.telefonica.onhr.util.Constants.EntityProcess
import org.apache.spark.sql.DataFrame
import org.junit.runner.RunWith
import org.scalatest.{BeforeAndAfterAll, BeforeAndAfterEach, FunSuite}
import org.scalatestplus.junit.JUnitRunner
import util.Settings

@RunWith(classOf[JUnitRunner])
class ExtractionTest extends FunSuite with Settings with BeforeAndAfterEach with BeforeAndAfterAll {

  final val ExtractionName = "SFSF_ONHR_EC_PAY_RANGE_TEST"
  implicit var extraction: Extraction = _
  var extractionDF: DataFrame = _

  var maxCount = 0

  override def beforeAll(): Unit = {
    hiveController.runHQLStatement("DROP SCHEMA IF EXISTS onhr_global CASCADE")
    hiveController.runHQLStatement("DROP SCHEMA IF EXISTS onhr_global_anonymised CASCADE")
    hiveController.runHQLStatement("DROP SCHEMA IF EXISTS onhr_entity CASCADE")
    hiveController.runHQLStatement("CREATE SCHEMA onhr_entity")
    hiveController.runHQLStatement("CREATE SCHEMA onhr_global")
    hiveController.runHQLStatement("CREATE SCHEMA onhr_global_anonymised")

    List("Entidad1").foreach { entityName =>
      implicit val extraction: Extraction = getExtraction(entityName)
      extraction.setProcessType(EntityProcess)
      val df = readDataFrameExtraction(entityName)
      implicit val entity: Entity = extraction.getMajorEntity
      val countNum = df.count().toInt
      maxCount = if (countNum > maxCount) countNum else maxCount
      dfController.writeDataFrame(df, isCatalog = true)
      hiveController.runHQLStatement(hiveController.getHQL(df, isCatalog = true))
      println(extraction.needDenormalize)
      if (extraction.needDenormalize) {
        extraction.getColumnsToDenormalize.foreach { case (tableName, fieldList) =>
          dfController.writeDenormDataFrame(dfController.denormalize(extractionDF, fieldList), tableName)
        }
      }
    }
  }

//  test("Write") {
//    extraction = getExtraction(ExtractionName)
//    extraction.setProcessType(ExtractionProcess)
//    extractionDF = dfController.consolidate(extraction)
//    dfController.writeDataFrame(extractionDF)
//    hiveController.runHQLStatement(hiveController.getHQL(extractionDF))
//  }

//  test("Write Anon") {
//    var anonExtractionDF = extractionDF
//
//    if (extraction.hasToApplyHash)
//      anonExtractionDF = dfController.applyHash(anonExtractionDF, extraction.getColumnsToApplyHash)
//
//    if (extraction.hasToApplyNull)
//      anonExtractionDF = dfController.applyNull(anonExtractionDF, extraction.getColumnsToApplyNull)
//
//    dfController.writeDataFrame(anonExtractionDF, isAnonymised = true)
//
//    hiveController.runHQLStatement(hiveController.getHQL(anonExtractionDF, isAnonymised = true))
//    assert(extraction.hasToApplyAnon)
//  }
//
////  test("Count") {
////    assert(maxCount == spark.sql(s"SELECT * FROM onhr_global.$ExtractionName").count())
////  }
//
//  test("SQL") {
//    val expectedQuery = f"""DROP TABLE IF EXISTS onhr_global.SFSF_ONHR_EC_PAY_RANGE_TEST;
//                          |CREATE TABLE IF NOT EXISTS onhr_global.SFSF_ONHR_EC_PAY_RANGE_TEST (
//                          |\tCREATEDBY VARCHAR(256),
//                          |\tCREATEDDATETIME DATETIME,
//                          |\tCREATEDON DATETIME,
//                          |\tCURRENCY VARCHAR(256),
//                          |\tENDDATE DATETIME,
//                          |\tEXTERNALCODE VARCHAR(256),
//                          |\tFREQUENCYCODE VARCHAR(256),
//                          |\tGEOZONEFLX VARCHAR(256),
//                          |\tLASTMODIFIEDBY VARCHAR(256),
//                          |\tLASTMODIFIEDDATETIME DATETIME,
//                          |\tLASTMODIFIEDON DATETIME,
//                          |\tMAXIMUMPAY DOUBLE,
//                          |\tMIDPOINT DOUBLE,
//                          |\tMINIMUMPAY DOUBLE,
//                          |\tNAME VARCHAR(256),
//                          |\tPAYGRADEFLX VARCHAR(256),
//                          |\tSTARTDATE DATETIME,
//                          |\tSTATUS VARCHAR(256),
//                          |\tCOMPANYFLXNAV_EXTERNALCODE VARCHAR(256),
//                          |\tCOMPANYFLXNAV_STARTDATE VARCHAR(256),
//                          |\tFREQUENCYCODENAV_EXTERNALCODE VARCHAR(256),
//                          |\tGEOZONEFLXNAV_EXTERNALCODE VARCHAR(256),
//                          |\tGEOZONEFLXNAV_STARTDATE VARCHAR(256),
//                          |\tJOBFUNCTIONFLXNAV_EXTERNALCODE VARCHAR(256),
//                          |\tJOBFUNCTIONFLXNAV_STARTDATE VARCHAR(256),
//                          |\tNAMETRANSLATIONNAV_EXTERNALCODE VARCHAR(256),
//                          |\tPAYGRADEFLXNAV_EXTERNALCODE VARCHAR(256),
//                          |\tPAYGRADEFLXNAV_STARTDATE VARCHAR(256),
//                          |\tJOB_FUNCTION_ID VARCHAR(256),
//                          |\tJOB_FUNCTION_NAME VARCHAR(256),
//                          |\tJOB_FUNCTION_START_DATE DATETIME
//                          |);""".stripMargin
//    val expectedAnonQuery = f"""DROP TABLE IF EXISTS onhr_global_anonymised.SFSF_ONHR_EC_PAY_RANGE_TEST;
//                           |CREATE TABLE IF NOT EXISTS onhr_global_anonymised.SFSF_ONHR_EC_PAY_RANGE_TEST (
//                           |\tCREATEDBY VARCHAR(256),
//                           |\tCREATEDDATETIME DATETIME,
//                           |\tCREATEDON DATETIME,
//                           |\tCURRENCY VARCHAR(256),
//                           |\tENDDATE DATETIME,
//                           |\tEXTERNALCODE VARCHAR(256),
//                           |\tFREQUENCYCODE VARCHAR(256),
//                           |\tGEOZONEFLX VARCHAR(256),
//                           |\tLASTMODIFIEDBY VARCHAR(256),
//                           |\tLASTMODIFIEDDATETIME DATETIME,
//                           |\tLASTMODIFIEDON DATETIME,
//                           |\tMAXIMUMPAY DOUBLE,
//                           |\tMIDPOINT DOUBLE,
//                           |\tMINIMUMPAY DOUBLE,
//                           |\tNAME VARCHAR(256),
//                           |\tPAYGRADEFLX VARCHAR(256),
//                           |\tSTARTDATE DATETIME,
//                           |\tSTATUS VARCHAR(256),
//                           |\tCOMPANYFLXNAV_EXTERNALCODE VARCHAR(256),
//                           |\tCOMPANYFLXNAV_STARTDATE VARCHAR(256),
//                           |\tFREQUENCYCODENAV_EXTERNALCODE VARCHAR(256),
//                           |\tGEOZONEFLXNAV_EXTERNALCODE VARCHAR(256),
//                           |\tGEOZONEFLXNAV_STARTDATE VARCHAR(256),
//                           |\tJOBFUNCTIONFLXNAV_EXTERNALCODE VARCHAR(256),
//                           |\tJOBFUNCTIONFLXNAV_STARTDATE VARCHAR(256),
//                           |\tNAMETRANSLATIONNAV_EXTERNALCODE VARCHAR(256),
//                           |\tPAYGRADEFLXNAV_EXTERNALCODE VARCHAR(256),
//                           |\tPAYGRADEFLXNAV_STARTDATE VARCHAR(256),
//                           |\tJOB_FUNCTION_ID VARCHAR(256),
//                           |\tJOB_FUNCTION_NAME VARCHAR(256),
//                           |\tJOB_FUNCTION_START_DATE DATETIME
//                           |);""".stripMargin
//
//    val currentQuery = JDBCController.getSQL(extractionDF)
//    val currentAnonQuery = JDBCController.getSQL(extractionDF, isAnonymised = true)
//    assert(currentQuery.hashCode.equals(expectedQuery.hashCode))
//    assert(currentAnonQuery.hashCode.equals(expectedAnonQuery.hashCode))
//  }
//
//  test("Indexes") {
//    val expectedIndexes = "CREATE INDEX IX_ONHR_SFSF_ONHR_EC_PAY_RANGE_TEST_CREATEDBY ON onhr_global.SFSF_ONHR_EC_PAY_RANGE_TEST (CREATEDBY);CREATE INDEX IX_ONHR_SFSF_ONHR_EC_PAY_RANGE_TEST_PAYGRADEFLXNAV_EXTERNALCODE ON onhr_global.SFSF_ONHR_EC_PAY_RANGE_TEST (PAYGRADEFLXNAV_EXTERNALCODE);CREATE INDEX IX_ONHR_SFSF_ONHR_EC_PAY_RANGE_TEST_JOB_FUNCTION_ID ON onhr_global.SFSF_ONHR_EC_PAY_RANGE_TEST (JOB_FUNCTION_ID);CREATE INDEX IX_ONHR_SFSF_ONHR_EC_PAY_RANGE_TEST_JOB_FUNCTION_START_DATE ON onhr_global.SFSF_ONHR_EC_PAY_RANGE_TEST (JOB_FUNCTION_START_DATE);"
//    val currentIndexes = JDBCController.getIndexes()
//    assert(extraction.hasToCreateIndex)
//    assert(expectedIndexes.hashCode.equals(currentIndexes.hashCode))
//  }
//
//  test("Nulls") {
//    val expected = new EntityField(fieldName = "JOB_FUNCTION_START_DATE",
//      fieldType = "Edm.DateTime",
//      anonType = "null",
//      alias = "",
//      isIndex = true,
//      isKey = false,
//      cardinality = false,
//      referencedField = "",
//      toOverwrite = false,
//      show = Some(false))
//    assert(expected.toString == extraction.getColumnsToApplyNull.head.toString)
//  }
//
//  test("Hash") {
//    val expected = new EntityField(fieldName = "JOB_FUNCTION_NAME",
//                                   fieldType = "Edm.String",
//                                   anonType = "hashing",
//                                   alias = "",
//                                   isIndex = false,
//                                   isKey = false,
//                                   cardinality = false,
//                                   referencedField = "",
//                                   toOverwrite = false,
//                                   show = Some(false))
//
//    assert(expected.toString == extraction.getColumnsToApplyHash.head.toString)
//  }

  //  test("Compare"){
  //    val df1 = readParquet(ExtractionName)
  //    val df2 = readExpectedCsv(ExtractionName, df1.schema)
  //    println(df1.where("externalcode = 'PR84850'").head)
  //    println(df2.where("externalcode = 'PR84850'").head)
  //    println(compare(df1, df2).count())
  //  }

  override def afterAll(): Unit = {
    hiveController.runHQLStatement("DROP SCHEMA IF EXISTS onhr_global CASCADE")
    hiveController.runHQLStatement("DROP SCHEMA IF EXISTS onhr_global_anonymised CASCADE")
    hiveController.runHQLStatement("DROP SCHEMA IF EXISTS onhr_entity CASCADE")
  }

}
