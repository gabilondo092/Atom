package tests.unit.controller

import org.junit.runner.RunWith
import org.scalatest.FunSuite
import org.scalatestplus.junit.JUnitRunner
import util.Settings

@RunWith(classOf[JUnitRunner])
class HDFSControllerTest extends FunSuite with Settings {

  test("getSourcePath") {
    assert("/mnt/d/Users/STR_SMM/Documents/Stratesys/Clientes/Telefonica-OnHR/onhr-core/src/test/resources/input/FOPayRange/*.csv" == HDFSController.getSourcePath("FOPayRange"))
  }
}
