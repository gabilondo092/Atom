package com.telefonica.onhr.util

import net.liftweb.json.MappingException
import org.apache.spark.sql.AnalysisException

class PropertiesException(message: String = "", cause: Exception = None.orNull) extends MappingException(message, cause)

class InvalidFilterOperatorException(message: String = "Filter conditions must be OR or AND") extends Exception(message)

class FieldNotInEntityException(message: String) extends Exception(message)

class EmptyDataFrameException(message: String) extends Exception(message)

class SchemaDoesNotExistsException(message: String) extends Exception(message)

class MetadataMismatchException(metadataColNumber: Int, dataFrameColNumber: Int) extends AnalysisException("") {
  override val message: String = f"Mismatched fields. JSON: $metadataColNumber, CSV: $dataFrameColNumber"
}

class PathNotExistException(path: String) extends AnalysisException("") {
  val remotePath: String = path
  override val message: String = f"Path does not exist. Path readed: $remotePath"
}