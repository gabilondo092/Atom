package com.telefonica.onhr.controller

import java.nio.file.Paths

import com.telefonica.onhr.util.Constants.{HDFSConf,clientPropertiesPath}
import org.apache.log4j.Logger
import org.apache.spark.sql.SparkSession


/** SparkController is a wrapper for Spark.
  * This class implements methods to interact with Spark, HDFS and HIVE,
  * such and read, write and transform data.
  *
  * @param processName [[String]] parameter used to define the process name shown in YARN UI
  */
class SparkController(processName: String, local: Boolean = false) {

  private lazy val spark: SparkSession = createSparkSession
  private lazy val logger: Logger = getSparkLogger

  private def createSparkSession: SparkSession = {
    this.logger.info("Initializing SparkSession...")
    val sparkSess = SparkSession.builder
                                .appName(this.processName)
                                .enableHiveSupport()

    if (local)
      sparkSess.config("spark.master", "local")
               .config("spark.sql.warehouse.dir", Paths.get(HDFSConf.rootPath, "spark-warehouse").toString)

    sparkSess.getOrCreate()
  }

  /**
   * Method that return the [[SparkSession]] object initialized
   * with the process name passed by parameter.
   *
   * @return [[SparkSession]] for the current process.
   */
  def getSparkSession: SparkSession = {
    this.spark
  }

  /**
   * Method that return the [[Logger]] object used to log in YARN, configured for onHR.
   * See resources/conf/log4j.properties file.
   *
   * @return [[Logger]] for the current class.
   */
  def getSparkLogger: Logger = {
    Logger.getLogger("onhr." + this.getClass.getSimpleName)
  }
  def getProperties(properties: String): String =
    if (spark.sparkContext.deployMode.equalsIgnoreCase("client")) clientPropertiesPath.concat(properties)
    else "./".concat(properties)

  /**
   * Close the current [[SparkSession]] object.
   */
  def terminate(): Unit = {
    this.spark.close()
    this.logger.info("SparkSession closed")
  }

}