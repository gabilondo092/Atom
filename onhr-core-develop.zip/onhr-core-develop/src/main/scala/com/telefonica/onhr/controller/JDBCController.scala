package com.telefonica.onhr.controller

import java.sql.{Connection, DriverManager}

import com.telefonica.onhr.entity.Extraction
import com.telefonica.onhr.util.Constants.{JDBCMappingTypes, OnHRConf}
import com.telefonica.onhr.util.JDBCConnection
import org.apache.log4j.Logger
import org.apache.spark.sql.DataFrame

import scala.collection.mutable

class JDBCController {

  private lazy val logger: Logger = Logger.getLogger("onhr." + this.getClass.getSimpleName)

  def runSQLStatement(SQLStatement: String, jdbcConnection: JDBCConnection): Unit = {
    var connection: Connection = null
    val connectionURL = s"jdbc:${jdbcConnection.dbType}://${jdbcConnection.host}:${jdbcConnection.port}/"
    this.logger.info("Running SQL statements on target DB")

    try {

      Class.forName(jdbcConnection.driver)
      connection = DriverManager.getConnection(connectionURL, jdbcConnection.username, jdbcConnection.password)

      SQLStatement.split(";").foreach { statement =>
        this.logger.debug("Statement dump:")
        this.logger.debug(statement)
        connection.createStatement.executeUpdate(statement)
      }

    } catch {
      case e: Exception => e.printStackTrace()
    } finally {
      if (connection != null) connection.close()
    }

  }

  /**
    * Create a Table on MySQL from a dataframe
    *
    * @param dataFrame     [[DataFrame]] to create the MySQL table
    * @param workspace     [[String]] Target workspace on hive. Used to choose the final workspace.
    * @param isAnonymised  [[Boolean]]. Used to choose the final workspace.
    * @param hasPartitions [[Boolean]]. Marks if a repair or a refresh is needed.
    * @param extraction    [[Extraction]] Implicit parameter to extract the [[Extraction.extractionName]]
    * @return [[String]] containing the needed statement to map a parquet file to a Hive External Table
    */
  def getSQL(dataFrame: DataFrame,
             workspace: String = "global",
             isAnonymised: Boolean = false,
             hasPartitions: Boolean = false,
             isCatalog: Boolean = false)(implicit extraction: Extraction): String = {

    this.logger.info("Generating JDBC SQL CREATE TABLE...")

    // fieldData to collect format: FIELD TYPE
    var fieldDataSql = mutable.ArrayBuffer[String]()

    val targetSchema = if (isCatalog) OnHRConf.getSchema(OnHRConf.entitySchema) else OnHRConf.getSchema(workspace)

    // extract the field name and field type, translating into mysql types
    dataFrame.schema.foreach {
      field =>

        val dataType = if (field.metadata.contains("cardinality") && field.metadata.getBoolean("cardinality")) "TEXT" else JDBCMappingTypes(field.dataType)
        val stringField = f"`${field.name.toUpperCase()}` ${if (dataType.contains("VARCHAR")) dataType.format(extraction.getField(field.name).getStringSize) else dataType}  ${if (dataType.contains("VARCHAR") || dataType.contains("TEXT")) "COLLATE utf8_bin" else ""}"

        fieldDataSql += stringField
    }
    // create table

    val currentSQL =
      f"""|DROP TABLE IF EXISTS ${targetSchema.getSchemaName(isAnonymised)}%s.${extraction.extractionName.toUpperCase}%s;
          |CREATE TABLE IF NOT EXISTS ${targetSchema.getSchemaName(isAnonymised)}%s.${extraction.extractionName.toUpperCase}%s (
          |\t${fieldDataSql.mkString(",\n\t")}%s
          |);""".stripMargin

    this.logger.debug("SQL dump:")
    this.logger.debug(currentSQL)
    currentSQL
  }

  def getIndexes(workspace: String = "global", isAnonymised: Boolean = false, jdbcConnection: JDBCConnection)(implicit extraction: Extraction): String = {
    val targetSchema = OnHRConf.getSchema(workspace)
    var indexesString: String = ""
    extraction.getColumnsToApplyIndex.foreach { field =>
      indexesString += s"CREATE INDEX ${jdbcConnection.indexPrefix}_${extraction.extractionName.toUpperCase}_${field.fieldName.toUpperCase} ON ${targetSchema.getSchemaName(isAnonymised)}.${extraction.extractionName.toUpperCase} (${field.fieldName.toUpperCase});"
    }
    indexesString
  }

}
