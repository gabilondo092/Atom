package com.telefonica.onhr.util

import net.liftweb.json
import org.apache.log4j.Logger

import scala.io.{BufferedSource, Source}

class Properties(private val filePath: String) {

  private implicit val formats: json.Formats = json.DefaultFormats

  private val logger: Logger = Logger.getLogger("onhr." + this.getClass.getSimpleName.split("\\$").last)

  private val jsonFile: BufferedSource = Source.fromFile(filePath)
  private val jsonContent = json.parse(jsonFile.mkString)

  def getHDFSProperties: HDFSProperties = {
    getProperties[HDFSProperties](jsonKey = "hdfs")
  }

  def getJDBCProperties: JDBCProperties = {
    getProperties[JDBCProperties](jsonKey = "jdbc")
  }

  def getHiveProperties: HiveProperties = {
    getProperties[HiveProperties](jsonKey = "hive")
  }

  def getOnHRProperties: OnHRProperties = {
    getProperties[OnHRProperties](jsonKey = "onhr")
  }

  private final def getProperties[T](jsonKey: String)(implicit m: Manifest[T]): T = {
    try {
      logger.debug(s"Getting ${m.runtimeClass.asInstanceOf[Class[T]].getName} Object...")
      (this.jsonContent \ jsonKey).extract[T]
    } catch {
      case me: net.liftweb.json.MappingException => throw new PropertiesException(me.msg, me.cause)
    }
  }

}