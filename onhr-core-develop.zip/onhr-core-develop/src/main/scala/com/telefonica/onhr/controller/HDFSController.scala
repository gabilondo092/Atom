package com.telefonica.onhr.controller

import java.nio.file.Paths

import com.telefonica.onhr.util.Constants.{HDFSConf, NewSuffix, Success}
import com.telefonica.onhr.util.PathNotExistException
import org.apache.hadoop.conf.Configuration
import org.apache.hadoop.fs.{FileSystem, Path}
import org.apache.log4j.Logger

class HDFSController {

  lazy val logger: Logger = Logger.getLogger("onhr." + this.getClass.getSimpleName)
  lazy val fs: FileSystem = FileSystem.get(new Configuration())

  def getSourcePath(extractionName: String,
                    fileName: String = "*.csv"): String = {
    val sourcePath = Paths.get(HDFSConf.rootPath, HDFSConf.sourcePath, extractionName, fileName).toString
    this.logger.debug(s"Path calculated: $sourcePath")
    this.pathExists(sourcePath)
    sourcePath
  }

  def getTargetPath(extractionName: String,
                    workspace: String = "global",
                    isAnonymised: Boolean = false,
                    isCatalog: Boolean = false): String = {

    val targetPath = Paths.get(HDFSConf.rootPath,
                               HDFSConf.processedPath,
                               if (isCatalog) HDFSConf.catalogPath else workspace,
                               if (isAnonymised) HDFSConf.anonymisedPath else HDFSConf.nonAnonymisedPath,
                               extractionName.toUpperCase()).toString

    this.logger.debug(s"Path calculated: $targetPath")
    // this.pathExists(targetPath)
    targetPath
  }

  def getCatalogPath(entityName: String): String = {
    val targetPath = Paths.get(HDFSConf.rootPath,
                               HDFSConf.processedPath,
                               HDFSConf.catalogPath,
                               entityName.toUpperCase()).toString

    this.logger.debug(s"Path calculated: $targetPath")
    // this.pathExists(targetPath)
    targetPath
  }

  def pathExists(path: String, throwException: Boolean = true): Boolean = {
    val status = this.fs.exists(new Path(path)) || this.listRecursive(path).nonEmpty
    if (!status && throwException)
      throw new PathNotExistException(path)
    status
  }

  def pathTmpNew(remotePath: String): String = {
    val pathSrc = new Path(remotePath)
    val headNew = pathSrc.getName.concat(NewSuffix)
    Paths.get(pathSrc.getParent.toString,headNew).toString
  }

  def renamePath(remotePath: String):Boolean={
    val pathSrc = new Path(remotePath)
    val pathNew = new Path(this.pathTmpNew(remotePath))
    this.fs.delete(pathSrc,true)
    this.fs.rename(pathNew,pathSrc)
  }

  def listRecursive(path: String): List[String] = {
    val fileList = this.fs.globStatus(new Path(path))
    if (fileList == null) {
      List()
    } else {
      fileList.map(_.getPath.toString).toList
    }
  }

  def isParquetEmpty(path: String): Boolean = {
    val targetPath = if (path.endsWith("/*")) path else path.concat("/*")
    val fileList = this.listRecursive(targetPath)
    fileList.size.equals(1) && fileList.head.split("/").last.equals(Success)
  }

  def deletePath(path: String, recursive: Boolean = true): Boolean = {
    this.fs.delete(new Path(path), recursive)
  }
}
