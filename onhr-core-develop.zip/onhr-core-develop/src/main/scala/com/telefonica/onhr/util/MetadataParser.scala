package com.telefonica.onhr.util

import com.telefonica.onhr.entity.{Entity, EntityField, Extraction}
import net.liftweb.json.{DefaultFormats, _}
import org.apache.log4j.Logger

import scala.collection.mutable.ListBuffer

/**
  * Parse a metadata file onto the entities defined on [[com.telefonica.onhr.entity]]
  *
  * @param metadataContent [[String]] metadata content.
  */
class MetadataParser(val metadataContent: String) {

  private implicit val formats: Formats = DefaultFormats

  private lazy val logger: Logger = Logger.getLogger("onhr." + this.getClass.getSimpleName)
  private val jsonContent = parse(metadataContent)

  def getExtraction: Extraction = {
    this.logger.debug("Parsing Metadata JSON...")
    val extractionName = (jsonContent \ "extractionName").extract[String]
    val extractionType = (jsonContent \ "extractionType").extract[String]
    val dateFilter = (jsonContent \ "dateFilter").extract[String]
    val fieldFilter = (jsonContent \ "fieldFilter").extract[String]

    val entitiesNames = (jsonContent \\ "entityName").children
    val entitiesAlias = (jsonContent \\ "entityAlias").children
    val entitiesFields = (jsonContent \\ "fieldList").children
    var entityList = ListBuffer[Entity]()

    // For every entity create the needed Entity object
    (entitiesNames, entitiesAlias, entitiesFields).zipped.foreach { (entName, entAlias, entFields) =>
      this.logger.debug(s"Mapping ${entName.extract[String]} entity...")
      entityList += new Entity(entityName = entName.extract[String],
                               entityAlias = entAlias.extract[String],
                               fieldList = entFields.extract[List[EntityField]])
    }

    // Object to be retrieved
    this.logger.debug("Parsed [OK]")
    val extraction = new Extraction(extractionName = extractionName,
                                    extractionEntities = entityList.toList,
                                    extractionType = extractionType,
                                    dateFilter = dateFilter,
                                    fieldFilter = fieldFilter)

    this.logger.debug("Extraction object dump:")
    this.logger.debug(extraction)

    extraction
  }
}
