package com.telefonica.onhr.util

import org.apache.spark.sql.types._

import scala.util.matching.Regex

object Constants {

  private var properties: Properties = _

  final lazy val OnHRConf: OnHRProperties = properties.getOnHRProperties

  final lazy val HDFSConf: HDFSProperties = properties.getHDFSProperties
  final lazy val HiveConf: HiveProperties = properties.getHiveProperties
  final lazy val JDBCConf: JDBCProperties = properties.getJDBCProperties

  final val DefaultStringSize = 256

  final val Left = "left"
  final val LeftSemi = "leftsemi"

  final val EntityProcess = "entity"
  final val ExtractionProcess = "extraction"

  final val OldSuffix = "_OLD"
  final val OrigSuffix = "_ORIG"
  final val NewSuffix = "_NEW"
  final val Success = "_SUCCESS"
  final val clientPropertiesPath = "conf/"

  final val HiveMappingTypes: Map[String, DataType] = Map("Edm.SByte" -> 	ByteType,
                                                          "Edm.Byte" -> 	ByteType,
                                                          "Edm.Binary" -> BinaryType,
                                                          "Edm.String" -> StringType,
                                                          "Edm.Int16" -> ShortType,
                                                          "Edm.Int32" -> IntegerType,
                                                          "Edm.Int64" -> LongType,
                                                          "Edm.Single" -> FloatType,
                                                          "Edm.Time" -> TimestampType,
                                                          "Edm.Double" -> DoubleType,
                                                          "Edm.Decimal" -> DoubleType,
                                                          "Edm.Boolean" -> BooleanType,
                                                          "Edm.DateTimeOffset" -> TimestampType,
                                                          "Edm.DateTime" -> TimestampType,
                                                          "string" -> StringType,
                                                          "date" -> TimestampType,
                                                          "int" -> IntegerType)

  final val JDBCMappingTypes: Map[DataType, String] = Map(ByteType -> "TINYINT",
                                                          StringType -> "VARCHAR(%s)",
                                                          BinaryType -> "BLOB",
                                                          ShortType -> "SMALLINT",
                                                          IntegerType -> "INT",
                                                          LongType -> "BIGINT",
                                                          FloatType -> "FLOAT",
                                                          DoubleType -> "DOUBLE",
                                                          BooleanType -> "BOOLEAN",
                                                          TimestampType -> "DATETIME")

  final val FilterConditions: Map[String, String] = Map("to upper case is equal to" -> "UPPER(%s) = '%s'",
                                                        "to lower case is equal to" -> "LOWER(%s) = '%s'",
                                                        "is contained in" -> "%s in (%s)",
                                                        "is equal to" -> "%s = '%s'",
                                                        "is not equal to" -> "%s != '%s'",
                                                        "is greater than or equal to" -> "%s >= %s",
                                                        "is greater than" -> "%s > %s",
                                                        "is less than or equal to" -> "%s <= %s",
                                                        "is less than" -> "%s < %s",
                                                        "is like" -> "%s like '%s'")

  final lazy val DistributionProcess: Map[Int, String] = Map(1 -> "GBU",
                                                             2 -> s"LEGAL_ENTITY by $WorkspacesOriginColumnName column",
                                                             3 -> s"LEGAL_ENTITY by $WorkspacesSecondaryOriginColumnName column",
                                                             4 -> s"LEGAL_ENTITY by ${OnHRConf.relationWithMidTable.targetTable} table",
                                                             0 -> "None")

  final val StringTypeRegex: Regex = "Edm\\.String\\((\\d+)\\)".r

  final val OperatorsFilterRegex: String = "( or | OR | AND | and )"
  final val AndFilterRegex: String = "( AND | and )"
  final val OrFilterRegex: String = "( OR | or )"

  final val FiltersRegex: String = "(^\\(.*\\)$)"
  final val ConditionRegex: Regex = s"(${FilterConditions.keys.mkString("|")})(.*)".r
  final val EntityRegex: Regex = "([a-zA-Z0-9_]*)\\.([a-zA-Z0-9_]*)".r.unanchored
  final val EntityNdConditionRegex = f"([a-zA-Z0-9_]*)\\.([a-zA-Z0-9_]*)\\s+(${FilterConditions.keys.mkString("|")})".r.unanchored

  final val WorkspacesOriginColumnName: String = "LEGAL_ENTITY_CODE"
  final val WorkspacesSecondaryOriginColumnName: String = "COMPANY_CODE"
  final val WorkspacesTargetColumnName: String = "FOCOMPANY_EXTERNALCODE"

  final val WorkspacesTableName: String = "FOCOMPANY"
  final val WorkspacesRepartitionColumnName: String = "FOCOMPANY_COUNTRY"
  final lazy val ExcludedTablesRegex = s"^(${OnHRConf.relationWithMidTable.originTables.mkString("|")})$$".r

  final val PartitionFieldMap : Map[String, DataType] = Map("FECHA_CARGA" -> LongType)
  final val timestampFormat: String = "yyyyMMddHHmmss"

  /**
    * Default enum that contains the allowed anon types
    */
  final object anonTypes extends Enumeration {
    final val HASH = "hashing"
    final val NULL = "null"
  }

  final object executionTypes extends Enumeration {
    final val HIVE = "HIVE"
    final val JDBC = "JDBC"
  }


  def setPropertiesFile(propertiesFile: String): Unit = {
    this.properties = new Properties(propertiesFile)
  }
}
