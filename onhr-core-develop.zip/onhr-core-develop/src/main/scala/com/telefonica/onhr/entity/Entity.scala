package com.telefonica.onhr.entity

import com.telefonica.onhr.util.Constants.anonTypes
import net.liftweb.json
import org.apache.spark.sql.functions.max
import org.apache.spark.sql.{Column, DataFrame}

class Entity(val entityName: String,
             val entityAlias: String,
             var fieldList: List[EntityField]) {

  private implicit val formats: json.Formats = json.DefaultFormats
  var df: DataFrame = _

  def getColumnsWithAlias: Map[String, String] = {
    this.fieldList.filter(field => field.hasAlias).map(field => field.fieldName -> field.alias).toMap
  }

  def getColumnsToApplyHash: List[EntityField] = {
    this.getColumnsByAnonType(anonTypes.HASH).filter(field => field.fieldType != "Edm.Int64")
  }

  def getColumnsToApplyNull: List[EntityField] = {
    this.getColumnsByAnonType(anonTypes.NULL)
  }

  def getColumnsToDenormalize: Map[String, List[EntityField]] = {
    this.fieldList.filter(field => field.cardinality && field.hasReference)
                  .map{ field =>
                    val tableName = s"${entityName}_${field.getNavigationValue}_REL".toUpperCase
                    tableName -> field
                  }
                  .groupBy(_._1)
                  .map { case (tableName, fieldList) => (tableName, fieldList.map(_._2))}
  }

  def getColumnsToApplyIndex: List[EntityField] = {
    this.fieldList.filter(field => !field.fieldType.equals("Edm.Int64") && (field.isKey || field.isIndex))
  }

  def getReferences: Map[EntityField, String] = {
    this.fieldList.filter(field => field.hasReference).map(field => field -> field.referencedField).toMap
  }

  def getField(fieldName: String, caseSensitive: Boolean = true): EntityField = {
    if (caseSensitive) {
      this.fieldList.filter(field => field.fieldName == fieldName).head
    } else {
      this.fieldList.filter(field => field.fieldName.toLowerCase == fieldName.toLowerCase).head
    }
  }

  def getFieldsToShowAsList: List[String] = {
    this.fieldList.filter(x => x.show.isEmpty && x.referencedField.isEmpty).map(_.fieldName)
  }

  def getFieldsAsList: List[String] = {
    this.fieldList.map(_.fieldName)
  }

  def needDenormalize: Boolean = {
    this.fieldList.exists(_.cardinality)
  }

  def hasReferences: Boolean = {
    this.getReferences.nonEmpty
  }

  def hasEndDate: Boolean = {
    this.fieldList.map(_.fieldName.toLowerCase).contains(s"${entityName.toLowerCase}_enddate") && this.getEndDateField.isKey
  }

  def hasStartDate: Boolean = {
    this.fieldList.map(_.fieldName.toLowerCase).contains(s"${entityName.toLowerCase}_startdate") && this.getStartDateField.isKey
  }

  def updateFields(): Unit = {
    this.getFieldsToUpdate.foreach{ field =>
      field.fieldType = this.df.schema.filter(_.name == field.fieldName).head.metadata.getString("fieldType")
    }
  }

  def getPKColumnsName: List[String] = fieldList.filter(field => field.toOverwrite).map(field => field.fieldName)

  def getPKColumns: List[Column] = getPKColumnsName.map(field => this.df(field))

  def getMatchEntity(keyPartition: String): DataFrame={
    val dfPKColumns = this.getPKColumns
    df.groupBy(dfPKColumns:_*).agg(max(keyPartition).alias(keyPartition))
  }

  def getEndDateField: EntityField = {
    this.getField(s"${entityName.toLowerCase}_enddate", caseSensitive = false)
  }

  def getStartDateField: EntityField = {
    this.getField(s"${entityName.toLowerCase}_startdate", caseSensitive = false)
  }

  private def getFieldsToUpdate: List[EntityField] = {
    this.fieldList.filter(_.show.isDefined)
  }

  private def getColumnsByAnonType(anonType: String): List[EntityField] = {
    this.fieldList.filter(field => !field.fieldType.toLowerCase.contains("boolean") && field.show.isEmpty && field.referencedField.isEmpty && field.isAnonymised && field.anonType.equals(anonType)).map(field => field)
  }

  override def toString: String = json.Serialization.write(this)
}
