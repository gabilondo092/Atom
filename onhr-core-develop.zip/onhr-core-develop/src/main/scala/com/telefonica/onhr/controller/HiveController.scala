package com.telefonica.onhr.controller

import com.telefonica.onhr.entity.Extraction
import com.telefonica.onhr.util.Constants.OnHRConf
import org.apache.spark.sql.{DataFrame, SparkSession}

import scala.collection.mutable

class HiveController(spark: SparkSession) extends HDFSController {

  /**
    * Execute HQL statements on the current [[SparkSession]]
    *
    * @param HQLStatement Statements to run on SparkSQL
    */
  def runHQLStatement(HQLStatement: String): Unit = {
    this.logger.info("Running HQL statements")

    HQLStatement.split(";").foreach { statement =>
      this.logger.debug("Statement dump:")
      this.logger.debug(statement)
      this.spark.sql(statement)
    }
  }

  /**
    * Returns the HQL statements needed to create a new table on Hive.
    *
    * @param dataFrame     [[DataFrame]] to extract the schema in order to replicate it on Hive.
    * @param workspace     [[String]]. Target workspace on hive. Used to choose the final workspace.
    * @param isAnonymised  [[Boolean]]. Used to choose the final workspace.
    * @param hasPartitions [[Boolean]]. Marks if a repair or a refresh is needed.
    * @param extraction    [[Extraction]] Implicit parameter to extract the [[Extraction.extractionName]]
    * @return [[String]] containing the needed statement to map a parquet file to a Hive External Table
    */
  def getHQL(dataFrame: DataFrame,
             workspace: String = "global",
             isAnonymised: Boolean = false,
             hasPartitions: Boolean = false,
             isCatalog: Boolean = false)
            (implicit extraction: Extraction): String = {

    this.logger.info("Generating Hive HQL CREATE TABLE...")

    var fieldData = mutable.ArrayBuffer[String]()
    val targetSchema = if (isCatalog) OnHRConf.getSchema(OnHRConf.entitySchema) else OnHRConf.getSchema(workspace)

    // From dataframe schema extract the field name and field type
    dataFrame.schema.foreach { field =>
      fieldData += field.name.toUpperCase() + " " + field.dataType.simpleString.toUpperCase()
    }

    var currentHQL =
      f"""|DROP TABLE IF EXISTS ${targetSchema.getSchemaName(isAnonymised)}%s.${extraction.extractionName.toUpperCase}%s;
          |CREATE EXTERNAL TABLE IF NOT EXISTS ${targetSchema.getSchemaName(isAnonymised)}%s.${extraction.extractionName.toUpperCase}%s (
          |\t${fieldData.mkString(",\n\t")}%s
          |) STORED AS PARQUET
          |LOCATION "${if (isCatalog) getCatalogPath(extraction.extractionName) else getTargetPath(extraction.extractionName, workspace, isAnonymised)}%s";""".stripMargin

    if (hasPartitions) currentHQL += "\nMSCK REPAIR TABLE '${extraction.extractionName}%s';"

    this.logger.debug("HQL dump:")
    this.logger.debug(currentHQL)

    currentHQL
  }

}
