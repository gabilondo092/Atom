package com.telefonica.onhr.entity

import com.telefonica.onhr.util.Constants.{HiveMappingTypes, StringTypeRegex, DefaultStringSize}
import net.liftweb.json
import org.apache.spark.sql.types.DataType

class EntityField(var fieldName: String,
                  var fieldType: String,
                  val anonType: String,
                  var alias: String,
                  val isIndex: Boolean,
                  val isKey: Boolean,
                  val cardinality: Boolean,
                  val referencedField: String,
                  val toOverwrite: Boolean,
                  val show: Option[Boolean]) {

  private implicit val formats: json.Formats = json.DefaultFormats

  def isAnonymised: Boolean = {
    anonType.nonEmpty
  }

  def hasAlias: Boolean = {
    alias.nonEmpty
  }

  def hasReference: Boolean = {
    referencedField.nonEmpty
  }

  def getEntityReference: String = {
    referencedField.split("\\.")(0)
  }

  def getFieldReference: String = {
    referencedField.split("\\.")(1)
  }

  def getNavigationValue: String = {
    val navigationValue = this.fieldName.replace(this.getFieldReference, "")
    if (navigationValue.endsWith("_")) navigationValue.dropRight(1) else navigationValue
  }

  def getHiveType: DataType = {
    HiveMappingTypes(if (this.fieldType.toLowerCase.contains("string")) "string" else this.fieldType)
  }

  def getFinalName: String = {
    if (hasAlias) alias else fieldName
  }

  def getStringSize: Int = {
    var size = 0
    if (this.hasSize) {
      size = StringTypeRegex.findAllIn(this.fieldType).matchData.map(_.group(1)).toList.head.toInt
    } else {
      size = DefaultStringSize
    }
    size
  }

  def hasSize: Boolean = {
    this.fieldType.matches(StringTypeRegex.toString())
  }

  def applyAlias() {
    this.fieldName = this.alias
    this.alias = ""
  }

  override def toString: String = json.Serialization.write(this)
}
