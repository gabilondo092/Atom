package com.telefonica.onhr.controller

import java.util.{Properties => JavaProperties}

import com.telefonica.onhr.entity.{Entity, EntityField, Extraction}
import com.telefonica.onhr.util.Constants._
import com.telefonica.onhr.util.{EmptyDataFrameException, FieldNotInEntityException, JDBCConnection, MetadataMismatchException, WorkspaceProperties}
import net.liftweb.json.JsonParser.parse
import net.liftweb.json.{DefaultFormats, Formats}
import org.apache.spark.sql._
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.{Metadata, StringType, StructField, StructType}

/**
  * This class works with DataFrames applying transformations and actions
  *
  * @param spark Initialized [[SparkSession]]
  */
class DataFrameController(spark: SparkSession) extends HDFSController {

  private final val WriteOk = "Written [OK]"
  private lazy val FOCompanyDataFrame: DataFrame = getFOCompany
  private lazy val UserDataFrame: DataFrame = getUser
  private implicit val formats: Formats = DefaultFormats
  private val keyPartition: String = PartitionFieldMap.keys.head

  /**
    * Generate the DataFrame Schema from a [[Extraction]] metadata.
    */
  def getDataFrameSchema(withNav: Boolean = true, alias: Boolean = false)(implicit extraction: Extraction): StructType = {

    this.logger.info("Generating DataFrame schema from Extraction...")

    var fieldList: List[EntityField] = if (withNav) extraction.fieldList else extraction.fieldList.filter(!_.hasReference)

    if (alias) {
      fieldList = extraction.fieldList.filter(field => !field.hasReference && field.hasAlias)
    } else {
      fieldList = fieldList
    }

    val structFieldList = fieldList.map { field =>
      val fieldName = if (alias) field.alias else field.fieldName
      val fieldType = if (field.cardinality) StringType else field.getHiveType
      val metadata = Metadata.fromJson(field.toString)
      StructField(fieldName, fieldType, metadata = metadata)
    }

    val schema = StructType(structFieldList)

    this.logger.debug("Schema dump:")
    this.logger.debug(schema)

    schema
  }

  def createEmptyDataFrame(dataFrameSchema: StructType): DataFrame = {
    this.addPartitionField(this.spark.createDataFrame(this.spark.sparkContext.emptyRDD[Row], dataFrameSchema))
  }

  def getMergedSchema(entityName: String): StructType = {
    var finalSchema = spark.read.parquet(this.getCatalogPath(entityName)).schema

    this.listRecursive(this.getCatalogPath(entityName).concat("/*")).filter(_.contains(PartitionFieldMap.keys.head)).foreach{ path =>
      spark.read.parquet(path).schema.diff(finalSchema).foreach{field =>
        finalSchema = finalSchema.add(field)
      }
    }
    finalSchema
  }

  /**
    * Method that read an Extraction, the extraction name must be passed as parameter.
    *
    * @param    remotePath Extraction name.
    * @param    format     Extension of the file.
    * @return [[DataFrame]] that contains the current extraction data.
    */
  def readDataFrame(remotePath: String, format: String = "csv", schema: StructType = null): DataFrame = {
    this.logger.info(f"Reading remote file from $remotePath%s...")
    var dataFrame: DataFrame = null
    pathExists(remotePath)
    if (format.equalsIgnoreCase("csv")) {
      this.logger.debug(s"File list: ${this.listRecursive(remotePath)}")
      dataFrame = this.spark.read.option("header", "true")
                                 .option("sep", HDFSConf.defaultSeparator)
                                 .option("timestampFormat", HiveConf.timestampFormat)
                                 .csv(remotePath)
    } else if (schema == null) {
      if (this.isParquetEmpty(remotePath)) throw new EmptyDataFrameException(s"The following table is empty: $remotePath ")
      dataFrame = this.spark.read.parquet(remotePath)
    } else {
      this.logger.debug(s"Applying merged schema: $schema")
      if (this.isParquetEmpty(remotePath)) throw new EmptyDataFrameException(s"The following table is empty: $remotePath ")
      dataFrame = this.spark.read.schema(schema).parquet(remotePath)
    }
    dataFrame
  }

  /**
    * Method that read an Extraction with the schema inferred from Metadata file.
    *
    * @return [[DataFrame]] that contains the current extraction data.
    */
  def readDataFrameExtraction(extractionName: String)(implicit extraction: Extraction): DataFrame = {
    var extractionDF = this.readDataFrame(this.getSourcePath(extractionName)).selectExpr(extraction.getMajorEntity.getFieldsAsList: _*)

    val orderedDataFrameColumns = extractionDF.columns
    val metadataColumns = extraction.fieldList

    if (!orderedDataFrameColumns.length.equals(metadataColumns.length)) {
      this.logger.debug(s"Metadata Columns: $metadataColumns")
      this.logger.debug(s"CSV Columns: ${orderedDataFrameColumns.toList}")
      throw new MetadataMismatchException(metadataColumns.length, orderedDataFrameColumns.length)
    }

    this.getDataFrameSchema().foreach { field =>
      extractionDF = extractionDF.withColumn(field.name, extractionDF(field.name).cast(field.dataType).as(field.name, metadata = field.metadata))
    }

    this.addPartitionField(extractionDF.selectExpr(orderedDataFrameColumns: _*))
  }

  def getConditionsJoin(dataFrame: DataFrame, relEntity: DataFrame): Array[Column] = {
    val columns = relEntity.columns
    val columnsRelEntity = columns.map(col => relEntity(col))
    val columnsDataFrame = columns.map(col => dataFrame(col))
    columnsDataFrame.zip(columnsRelEntity).map { case (columnPK, relColumnPK) => columnPK.equalTo(relColumnPK) }
  }

  def updateEntity(entity: Entity): DataFrame = {
    val dataFrame = entity.df
    val relDataFrame = entity.getMatchEntity(keyPartition)
    val conditionsSentences = getConditionsJoin(dataFrame, relDataFrame)
    dataFrame.join(relDataFrame, dataFrame.col(keyPartition).equalTo(relDataFrame.col(keyPartition)).and(conditionsSentences.reduce(_ and _)), LeftSemi)
  }

  def getUpdatedEntity(entityName: String): DataFrame = {
    val entity = getEntityObjectFromParquet(entityName)
    entity.df = this.readDataFrame(this.getCatalogPath(entity.entityName), format = "parquet")
    updateEntity(entity)
  }

  def readEntity(entityName: String)(implicit entity: Entity): DataFrame = {
    var df = getUpdatedEntity(entityName)

    if (entity.needDenormalize) {
      entity.getColumnsToDenormalize.foreach { case (tableName, fieldList) =>

        this.logger.info(s"Joining with denormalized table: $tableName")

        val relDF = this.readDataFrame(this.getCatalogPath(tableName), format = "parquet")

        fieldList.foreach(field => df = df.withColumnRenamed(field.fieldName, field.fieldName.concat(OldSuffix)))

          val joinCondition = fieldList.map{field =>
                                              df.col(field.fieldName.concat(OldSuffix)).equalTo(relDF.col(field.fieldName.concat(OrigSuffix)))}
                                       .reduce(_ and _)

          this.logger.debug(joinCondition)
          df = df.join(relDF, joinCondition, Left)
                 .drop(fieldList.map(_.fieldName.concat(OldSuffix)): _*)
                 .drop(fieldList.map(_.fieldName.concat(OrigSuffix)): _*)
      }
    }
    df
  }

  def readEntity(entityName: String, columns: List[String])(implicit entity: Entity): DataFrame = {
    this.readEntity(entityName).selectExpr(columns: _*)
  }

  /**
    * Read the metadata JSON associated to an Extraction.
    *
    * @param    extractionName Extraction name.
    * @return Metadata content as [[String]]
    */
  def readJSON(extractionName: String): String = {
    this.spark.read.json(getSourcePath(extractionName = extractionName,
      fileName = extractionName.concat(".json"))).toJSON.first()
  }

  /**
    * Writes a [[DataFrame]] on HDFS.
    */
  def writePartitionedDataFrame(dataFrame: DataFrame,
                                remotePath: String,
                                keyPartition: String = PartitionFieldMap.keys.head,
                                isEntity: Boolean = true)(implicit extraction: Extraction): Unit = {

    var saveType: SaveMode = SaveMode.Overwrite
    if (extraction.extractionType.toUpperCase != "FULL" && extraction.extractionType.toUpperCase != "INIT" && isEntity) saveType = SaveMode.Append

    this.logger.debug(s"Repartition value: ${extraction.repartitionValue}")
    this.logger.debug(s"SaveMode value: $saveType")

    if (extraction.repartitionValue == 1) {
      dataFrame.repartition(extraction.repartitionValue).write.mode(saveType).parquet(remotePath)
    } else {
      dataFrame.repartition(extraction.repartitionValue).write.mode(saveType).partitionBy(keyPartition).parquet(remotePath)
    }
  }

  def writeDataFrame(dataFrame: DataFrame,
                     workspace: String = "global",
                     isAnonymised: Boolean = false,
                     isCatalog: Boolean = false)(implicit extraction: Extraction): Unit = {

    this.logger.info("Writing parquet file...")

    val remotePath = if (isCatalog)
      this.getCatalogPath(extraction.extractionName)
    else
      this.getTargetPath(extraction.extractionName,
                         workspace,
                         isAnonymised)

    writePartitionedDataFrame(dataFrame, remotePath, isEntity = isCatalog)
    this.logger.info(WriteOk)
  }

  def writeDenormDataFrame(dataFrame: DataFrame,
                           tableName: String,
                           saveMode: String = "full")(implicit entity: Entity): Unit = {
    this.logger.info("Writing denormalized parquet file...")
    val remotePath = this.getCatalogPath(tableName)

    val writeMode = SaveMode.Overwrite
    dataFrame.write.mode(writeMode).parquet(remotePath)
    this.logger.info(WriteOk)
  }

  /**
    * Writes a [[DataFrame]] on JDBC.
    *
    * @param dataFrame [[DataFrame]] DF to write
    * @param workspace [[String]] target database schema
    */
  def writeOnJDBC(dataFrame: DataFrame,
                  jdbcConnection: JDBCConnection,
                  saveMode: SaveMode = SaveMode.Overwrite,
                  workspace: String = "global",
                  isAnonymised: Boolean = false,
                  hasPartitions: Boolean = false,
                  isCatalog: Boolean = false)(implicit extraction: Extraction): Unit = {

    this.logger.info("Writing on JDBC...")

    val targetSchema = if (isCatalog) OnHRConf.getSchema(OnHRConf.entitySchema) else OnHRConf.getSchema(workspace)

    // class with the connection properties
    val connectionProperties = new JavaProperties()

    val connectionURL = s"jdbc:${jdbcConnection.dbType}://${jdbcConnection.host}:${jdbcConnection.port}/${targetSchema.getSchemaName(isAnonymised)}?sessionVariables=sql_mode=''&jdbcCompliantTruncation=false"

    this.logger.debug(s"Connection string: $connectionURL")
    connectionProperties.setProperty("user", jdbcConnection.username)
    connectionProperties.setProperty("password", jdbcConnection.password)
    connectionProperties.setProperty("driver", jdbcConnection.driver)

    dataFrame.write.mode(saveMode)
                   .option("truncate", value = true)
                   .jdbc(url = connectionURL,
                         table = f"${targetSchema.getSchemaName(isAnonymised)}.${extraction.extractionName.toUpperCase}",
                         connectionProperties = connectionProperties)

    this.logger.info(WriteOk)
  }

  def join(leftDataFrame: DataFrame, rightDataFrame: DataFrame, joinCondition: Column, joinType: String = Left): DataFrame = {
    leftDataFrame.join(rightDataFrame, joinCondition, joinType)
  }

  def applyHash(dataFrame: DataFrame, dataFrameColumns: List[EntityField]): DataFrame = {
    var newDataFrame = dataFrame
    dataFrameColumns.foreach { field =>
      this.logger.info(s"Applying hash to: ${field.fieldName.toUpperCase}")
      newDataFrame = newDataFrame.withColumn(field.fieldName,
                                             sha2(sha2(dataFrame.col(field.fieldName), numBits = 256), numBits = 256))}
    newDataFrame
  }

  def applyNull(dataFrame: DataFrame, dataFrameColumns: List[EntityField]): DataFrame = {
    var newDataFrame = dataFrame
    dataFrameColumns.foreach { field =>
      this.logger.info(s"Applying null to: ${field.fieldName.toUpperCase}")
      newDataFrame = newDataFrame.withColumn(field.fieldName,
                                             lit(null).cast(field.getHiveType))}
    newDataFrame
  }

  def applyAlias(dataFrame: DataFrame, originalName: String, aliasName: String): DataFrame = {
    this.logger.debug(s"Applying alias: $originalName to $aliasName")
    dataFrame.withColumnRenamed(originalName, aliasName)
  }

  def applyDateFilter(dataFrame: DataFrame, columnName: String, dateMin: String, dateMax: String): DataFrame = {
    dataFrame.where(dataFrame.col(columnName).between(dateMin, dateMax))
  }

  def applyWhereFilter(dataFrame: DataFrame, SQLFilter: String): DataFrame = {
    this.logger.debug(s"Applying: $SQLFilter")
    dataFrame.where(SQLFilter)
  }

  def getCountryInfo(tableName: String,
                     dataFrame: DataFrame,
                     workspace: WorkspaceProperties,
                     distributionProcess: Int): DataFrame = {

    distributionProcess match {
      case 0 =>
        dataFrame
      case 1 =>
        val gbuProperties = OnHRConf.gbuMapping(tableName)
        var relDataFrame = this.readDataFrame(this.getTargetPath(gbuProperties.targetTable), format = "parquet").selectExpr(List(gbuProperties.targetField.toUpperCase, gbuProperties.gbuField.toUpperCase):_*)
        relDataFrame = relDataFrame.where(relDataFrame.col(gbuProperties.gbuField).isin(OnHRConf.gbuValues:_*)).withColumnRenamed(gbuProperties.targetField, gbuProperties.targetField.concat("_REL"))

        if (!relDataFrame.columns.map(_.toLowerCase).contains(gbuProperties.gbuField.toLowerCase))
          throw new FieldNotInEntityException(s"${gbuProperties.gbuField} needed for apply the distribution. Aborting")

        dataFrame.where(dataFrame.col(gbuProperties.originField).isNotNull)
                 .join(relDataFrame,
                       dataFrame.col(gbuProperties.originField).equalTo(relDataFrame.col(gbuProperties.targetField.concat("_REL"))),
                       Left)
                 .drop(relDataFrame.col(gbuProperties.targetField.concat("_REL")))
                 .drop(relDataFrame.col(gbuProperties.gbuField.toUpperCase))

      case 2 =>
        val repartitionField: String = WorkspacesOriginColumnName
        dataFrame.where(dataFrame.col(repartitionField).isNotNull)
                 .join(FOCompanyDataFrame,
                       dataFrame.col(repartitionField).equalTo(FOCompanyDataFrame.col(WorkspacesTargetColumnName)),
                       Left)
                 .where(workspace.countryCodes.map(country => FOCompanyDataFrame.col(WorkspacesRepartitionColumnName).equalTo(lit(country.toUpperCase)))
                                              .reduce(_ or _))
                 .drop(FOCompanyDataFrame.col(WorkspacesTargetColumnName))
                 .drop(FOCompanyDataFrame.col(WorkspacesRepartitionColumnName))
      case 3 =>
        val repartitionField: String = WorkspacesSecondaryOriginColumnName
        dataFrame.where(dataFrame.col(repartitionField).isNotNull)
                 .join(FOCompanyDataFrame,
                       dataFrame.col(repartitionField).equalTo(FOCompanyDataFrame.col(WorkspacesTargetColumnName)),
                       Left)
                 .where(workspace.countryCodes.map(country => FOCompanyDataFrame.col(WorkspacesRepartitionColumnName).equalTo(lit(country.toUpperCase)))
                                              .reduce(_ or _))
                 .drop(FOCompanyDataFrame.col(WorkspacesTargetColumnName))
                 .drop(FOCompanyDataFrame.col(WorkspacesRepartitionColumnName))
      case 4 =>
        val repartitionField: String = WorkspacesSecondaryOriginColumnName
        dataFrame.where(dataFrame.col(OnHRConf.relationWithMidTable.originField).isNotNull)
                 .join(UserDataFrame,
                       dataFrame.col(OnHRConf.relationWithMidTable.originField).equalTo(UserDataFrame.col(OnHRConf.relationWithMidTable.originField)),
                       Left)
                 .where(UserDataFrame.col(repartitionField).isNotNull)
                 .join(FOCompanyDataFrame,
                       UserDataFrame.col(repartitionField).equalTo(FOCompanyDataFrame.col(WorkspacesTargetColumnName)),
                       Left)
                 .where(workspace.countryCodes.map(country => FOCompanyDataFrame.col(WorkspacesRepartitionColumnName).equalTo(lit(country.toUpperCase)))
                                              .reduce(_ or _))
                  .drop(FOCompanyDataFrame.col(WorkspacesTargetColumnName))
                  .drop(FOCompanyDataFrame.col(WorkspacesRepartitionColumnName))
                  .drop(UserDataFrame.col(OnHRConf.relationWithMidTable.originField))
                  .drop(UserDataFrame.col(repartitionField))
    }
  }

  def denormalize(dataFrame: DataFrame, fieldList: List[EntityField]): DataFrame = {
    import spark.implicits._
    val splitValue = OnHRConf.denormSeparator

    var finalDf = dataFrame.selectExpr(fieldList.map(_.fieldName):_*)
                           .where(fieldList.map(field => dataFrame.col(field.fieldName).isNotNull).reduce(_ and _))
                           .distinct()
    
    // TODO Rehacer de forma generica
    fieldList.length match {
        
      case 1 => finalDf = finalDf.map(row => row.getString(0) -> row.getString(0).split(splitValue))
                                 .select($"_1".alias(fieldList.head.fieldName.concat(OrigSuffix)), explode($"_2").alias(fieldList.head.fieldName))
                                 .withColumn(fieldList.head.fieldName, $"${fieldList.head.fieldName}".cast(fieldList.head.getHiveType))
                                 .withColumn(fieldList.head.fieldName.concat(OrigSuffix), $"${fieldList.head.fieldName.concat(OrigSuffix)}".cast(StringType))

      case 2 => finalDf = finalDf.flatMap(row => {
                                    row.getString(0).split(splitValue).zip(row.getString(1).split(splitValue)).map{ case (x, y) =>
                                      (row.getString(0), row.getString(1), x, y)
                                    }
                                  })
                                 .withColumnRenamed("_1", fieldList.head.fieldName.concat(OrigSuffix))
                                 .withColumnRenamed("_2", fieldList(1).fieldName.concat(OrigSuffix))
                                 .withColumnRenamed("_3", fieldList.head.fieldName)
                                 .withColumnRenamed("_4", fieldList(1).fieldName)
                                 .withColumn(fieldList.head.fieldName.concat(OrigSuffix), $"${fieldList.head.fieldName.concat(OrigSuffix)}".cast(StringType))
                                 .withColumn(fieldList.head.fieldName, $"${fieldList.head.fieldName}".cast(fieldList.head.getHiveType))
                                 .withColumn(fieldList(1).fieldName.concat(OrigSuffix), $"${fieldList(1).fieldName.concat(OrigSuffix)}".cast(StringType))
                                 .withColumn(fieldList(1).fieldName, $"${fieldList(1).fieldName}".cast(fieldList(1).getHiveType))
        
      case 3 => finalDf = finalDf.flatMap(row => {
                                    row.getString(0).split(splitValue).zip(row.getString(1).split(splitValue)).zip(row.getString(2).split(splitValue)).map{case (x, y) =>
                                      (row.getString(0), row.getString(1), row.getString(2), x.asInstanceOf[(String, String)]._1, x.asInstanceOf[(String, String)]._2, y)
                                    }
                                  })
                                  .withColumnRenamed("_1", fieldList.head.fieldName.concat(OrigSuffix))
                                  .withColumnRenamed("_2", fieldList(1).fieldName.concat(OrigSuffix))
                                  .withColumnRenamed("_3", fieldList(2).fieldName.concat(OrigSuffix))
                                  .withColumnRenamed("_4", fieldList.head.fieldName)
                                  .withColumnRenamed("_5", fieldList(1).fieldName)
                                  .withColumnRenamed("_6", fieldList(2).fieldName)
                                  .withColumn(fieldList.head.fieldName.concat(OrigSuffix), $"${fieldList.head.fieldName.concat(OrigSuffix)}".cast(StringType))
                                  .withColumn(fieldList.head.fieldName, $"${fieldList.head.fieldName}".cast(fieldList.head.getHiveType))
                                  .withColumn(fieldList(1).fieldName.concat(OrigSuffix), $"${fieldList(1).fieldName.concat(OrigSuffix)}".cast(StringType))
                                  .withColumn(fieldList(1).fieldName, $"${fieldList(1).fieldName}".cast(fieldList(1).getHiveType))
                                  .withColumn(fieldList(2).fieldName.concat(OrigSuffix), $"${fieldList(2).fieldName.concat(OrigSuffix)}".cast(StringType))
                                  .withColumn(fieldList(2).fieldName, $"${fieldList(2).fieldName}".cast(fieldList(2).getHiveType))
        
      case 4 => finalDf = finalDf.flatMap(row => {
                                    row.getString(0).split(splitValue).zip(row.getString(1).split(splitValue)).zip(row.getString(2).split(splitValue).zip(row.getString(3).split(splitValue))).map{case (x, y) =>
                                      (row.getString(0), row.getString(1), row.getString(2), row.getString(3), x.asInstanceOf[(String, String)]._1, x.asInstanceOf[(String, String)]._2, y.asInstanceOf[(String, String)]._1, y.asInstanceOf[(String, String)]._2)
                                    }
                                  })
                                  .withColumnRenamed("_1", fieldList.head.fieldName.concat(OrigSuffix))
                                  .withColumnRenamed("_2", fieldList(1).fieldName.concat(OrigSuffix))
                                  .withColumnRenamed("_3", fieldList(2).fieldName.concat(OrigSuffix))
                                  .withColumnRenamed("_4", fieldList(3).fieldName.concat(OrigSuffix))
                                  .withColumnRenamed("_5", fieldList.head.fieldName)
                                  .withColumnRenamed("_6", fieldList(1).fieldName)
                                  .withColumnRenamed("_7", fieldList(2).fieldName)
                                  .withColumnRenamed("_8", fieldList(3).fieldName)
                                  .withColumn(fieldList.head.fieldName.concat(OrigSuffix), $"${fieldList.head.fieldName.concat(OrigSuffix)}".cast(StringType))
                                  .withColumn(fieldList.head.fieldName, $"${fieldList.head.fieldName}".cast(fieldList.head.getHiveType))
                                  .withColumn(fieldList(1).fieldName.concat(OrigSuffix), $"${fieldList(1).fieldName.concat(OrigSuffix)}".cast(StringType))
                                  .withColumn(fieldList(1).fieldName, $"${fieldList(1).fieldName}".cast(fieldList(1).getHiveType))
                                  .withColumn(fieldList(2).fieldName.concat(OrigSuffix), $"${fieldList(2).fieldName.concat(OrigSuffix)}".cast(StringType))
                                  .withColumn(fieldList(2).fieldName, $"${fieldList(2).fieldName}".cast(fieldList(2).getHiveType))
                                  .withColumn(fieldList(3).fieldName.concat(OrigSuffix), $"${fieldList(3).fieldName.concat(OrigSuffix)}".cast(StringType))
                                  .withColumn(fieldList(3).fieldName, $"${fieldList(3).fieldName}".cast(fieldList(3).getHiveType))

      // val df =spark.read.option("sep", "|").option("header", true).csv("file:///opt/software/onhr/onhr-core/files/09032020/entities/EmpCompensation_20201505231517/EmpCompensation_20201505231517_0.csv")
      // df.selectExpr("empPayCompRecurringNav_payComponent", "empPayCompRecurringNav_seqNumber", "empPayCompRecurringNav_startDate", "empPayCompRecurringNav_userId", "empPayCompRecurringNav_endDate").distinct.show(false)
      case 5 => finalDf = finalDf.flatMap(row => {
                                    row.getString(0).split(splitValue).zip(row.getString(1).split(splitValue)).zip(row.getString(2).split(splitValue).zip(row.getString(3).split(splitValue))).zip(row.getString(4).split(splitValue)).map{case (x, y) =>
                                      (row.getString(0),
                                        row.getString(1),
                                        row.getString(2),
                                        row.getString(3),
                                        row.getString(4),
                                        x.asInstanceOf[((String, String), (String, String))]._1._1,
                                        x.asInstanceOf[((String, String), (String, String))]._1._2,
                                        x.asInstanceOf[((String, String), (String, String))]._2._1,
                                        x.asInstanceOf[((String, String), (String, String))]._2._2,
                                        y)
                                    }
                                  })
                                 .withColumnRenamed("_1", fieldList.head.fieldName.concat(OrigSuffix))
                                 .withColumnRenamed("_2", fieldList(1).fieldName.concat(OrigSuffix))
                                 .withColumnRenamed("_3", fieldList(2).fieldName.concat(OrigSuffix))
                                 .withColumnRenamed("_4", fieldList(3).fieldName.concat(OrigSuffix))
                                 .withColumnRenamed("_5", fieldList(4).fieldName.concat(OrigSuffix))
                                 .withColumnRenamed("_6", fieldList.head.fieldName)
                                 .withColumnRenamed("_7", fieldList(1).fieldName)
                                 .withColumnRenamed("_8", fieldList(2).fieldName)
                                 .withColumnRenamed("_9", fieldList(3).fieldName)
                                 .withColumnRenamed("_10", fieldList(4).fieldName)
                                 .withColumn(fieldList.head.fieldName.concat(OrigSuffix), $"${fieldList.head.fieldName.concat(OrigSuffix)}".cast(StringType))
                                 .withColumn(fieldList.head.fieldName, $"${fieldList.head.fieldName}".cast(fieldList.head.getHiveType))
                                 .withColumn(fieldList(1).fieldName.concat(OrigSuffix), $"${fieldList(1).fieldName.concat(OrigSuffix)}".cast(StringType))
                                 .withColumn(fieldList(1).fieldName, $"${fieldList(1).fieldName}".cast(fieldList(1).getHiveType))
                                 .withColumn(fieldList(2).fieldName.concat(OrigSuffix), $"${fieldList(2).fieldName.concat(OrigSuffix)}".cast(StringType))
                                 .withColumn(fieldList(2).fieldName, $"${fieldList(2).fieldName}".cast(fieldList(2).getHiveType))
                                 .withColumn(fieldList(3).fieldName.concat(OrigSuffix), $"${fieldList(3).fieldName.concat(OrigSuffix)}".cast(StringType))
                                 .withColumn(fieldList(3).fieldName, $"${fieldList(3).fieldName}".cast(fieldList(3).getHiveType))
                                 .withColumn(fieldList(4).fieldName.concat(OrigSuffix), $"${fieldList(4).fieldName.concat(OrigSuffix)}".cast(StringType))
                                 .withColumn(fieldList(4).fieldName, $"${fieldList(4).fieldName}".cast(fieldList(4).getHiveType))
    }
    finalDf
  }

  def consolidate(extraction: Extraction): DataFrame = {

    // Read every entity contained on extraction.extractionEntities
    this.readEntitiesDataFrame(extraction)
    var SQLConditions = ""
    var SQLDateIntersection = ""
    val hasDateFilter: Boolean = extraction.needToApplyDateFilter

    if (extraction.fieldFilter.nonEmpty) {
      // Parse the field filter as SQL clause
      SQLConditions = extraction.getFieldFilterAsSQL
      this.logger.info(f"Parsed filter to apply: $SQLConditions")
    }

    if (hasDateFilter) {
      // Parse the field filter as SQL clause
      SQLDateIntersection = extraction.getDateIntersectionAsSQL
      this.logger.info(f"Parsed intersection to apply: $SQLDateIntersection")
    }

    // For each entity, resolve the references
    // We apply a reverse to resolve first the last joins, when we reach the root entity (the first one)
    // everything will be previously joined
    extraction.extractionEntities.filter(entity => entity.hasReferences).reverse.foreach { entity =>

      // Stores the target entity and the joinCondition
      var entityColumnJoin: scala.collection.mutable.Map[Entity, Column] = scala.collection.mutable.Map[Entity, Column]()

      // Extract the references
      entity.getReferences.foreach { case (field, referenceEntity) =>

        // Split the string to get the entity and the field
        val entityNdField = referenceEntity.split("\\.")

        try {

          // Extract the entity and the field
          // This code throw an Exception if the entity is not in the extraction.extractionEntities list
          // If is in the list means we navigate to the entity as child
          val refEntity = extraction.getEntity(entityNdField(0))
          val refField = refEntity.getField(f"${refEntity.entityName}_${entityNdField(1)}")

          this.logger.debug(s"Joining ${field.fieldName} with ${refField.fieldName}")
          // Resolve the alias of the fields to relate
          if (field.hasAlias) {
            entity.df = this.applyAlias(entity.df, field.fieldName, field.alias)
            field.applyAlias()
          }

          if (refField.hasAlias) {
            refEntity.df = this.applyAlias(refEntity.df, refField.fieldName, refField.alias)
            refField.applyAlias()
          }
          // Build the Column object
          val joinCondition = entity.df.col(field.fieldName).equalTo(refEntity.df.col(refField.fieldName))

          // If the entity is not contained on the map is a simple join
          // If not we must to add the new condition as a compound join using the AND operator
          if (!entityColumnJoin.contains(refEntity)) {
            entityColumnJoin += (refEntity -> joinCondition)
          } else {
            entityColumnJoin(refEntity) = entityColumnJoin(refEntity).and(joinCondition)
          }

        } catch {
          // Throw the exception if a field contains a referencedField related with a entity not contained on the current JSON
          case _: java.util.NoSuchElementException =>
            this.logger.warn(f"${entityNdField(0).toUpperCase} NOT FOUND IN CURRENT METADATA")
        }
      }

      // Apply the conditions
      entityColumnJoin.foreach { case (refEntity, condition) =>
        this.logger.debug(s"Join condition: $condition")
        this.resolveEntityAlias(refEntity)
        entity.df = this.join(entity.df, refEntity.df, condition)
      }
    }

    // Get the root entity, already joined
    val consolidatedExtraction = extraction.extractionEntities.head

    if (extraction.dateFilter.nonEmpty) {
      // Extract date filter
      val Array(dateMin, dateField, dateMax) = extraction.getDateFilter
      // Apply date filter
      consolidatedExtraction.df = this.applyDateFilter(consolidatedExtraction.df, dateField, dateMin, dateMax)
    }

    this.resolveEntityAlias(consolidatedExtraction)

    if (hasDateFilter) {
      consolidatedExtraction.df = this.applyWhereFilter(consolidatedExtraction.df, SQLDateIntersection.toUpperCase)
    }

    // Apply field filter
    if (extraction.fieldFilter.nonEmpty) {
      consolidatedExtraction.df = this.applyWhereFilter(consolidatedExtraction.df, SQLConditions)
    }

    this.addPartitionField(consolidatedExtraction.df.selectExpr(extraction.getFieldsToShowAsList: _*).distinct())
  }

  /**
    * Read the dataframe of the entities contained on the extraction.
    *
    * @param extraction [[Extraction]] contains the metadata of the current extraction.
    */
  private def readEntitiesDataFrame(extraction: Extraction): Unit = {
    extraction.extractionEntities.foreach { entity =>
      this.logger.debug(s"ENTITY FIELDS: ${entity.getFieldsToShowAsList}")
      entity.df = this.readEntity(entity.entityName)(entity)

      if (OnHRConf.defaultTableFilters.contains(entity.entityName.toUpperCase)) {

        val field = OnHRConf.defaultTableFilters(entity.entityName.toUpperCase).head._1
        val value = OnHRConf.defaultTableFilters(entity.entityName.toUpperCase).head._2

        val filter = entity.df.col(field).equalTo(lit(value))

        this.logger.info(s"Applying default filter to ${entity.entityName}: $filter")

        entity.df = entity.df.where(filter)
      }

      if (OnHRConf.defaultTableFieldReplace.contains(entity.entityName.toUpperCase)) {
        val originField = OnHRConf.defaultTableFieldReplace(entity.entityName.toUpperCase).originField
        val replaceField = OnHRConf.defaultTableFieldReplace(entity.entityName.toUpperCase).replaceField

        entity.df = entity.df.withColumn(originField,
                                         when(entity.df.col(originField).isNull, entity.df.col(replaceField)).otherwise(entity.df.col(originField)))

        this.logger.info(s"Applying default null replace. Null values of $originField will be replaces with the values of $replaceField")

      }

      entity.df = entity.df.selectExpr(entity.getFieldsAsList: _*)
      entity.updateFields()
    }
  }

  /**
    * Apply all alias on the entity fields
    *
    * @param entity [[Entity]] object that contains the entity data
    */
  private def resolveEntityAlias(entity: Entity): Unit = {
    entity.fieldList.filter(_.hasAlias).foreach { field =>
      entity.df = this.applyAlias(entity.df, field.fieldName, field.alias)
      field.applyAlias()
    }
  }

  def getEntityObjectFromParquet(entityName: String): Entity = {
    val dataFrame = this.readDataFrame(this.getCatalogPath(entityName), format = "parquet", schema = getMergedSchema(entityName))
    new Entity(entityName = entityName,
              entityAlias = entityName,
              fieldList = dataFrame.schema.filterNot(field => field.name.equals(keyPartition)).map( field => parse(field.metadata.json).extract[EntityField]).toList)
  }

  private def addPartitionField(dataFrame: DataFrame): DataFrame = {
    dataFrame.withColumn(keyPartition, from_unixtime(unix_timestamp(), timestampFormat).cast(PartitionFieldMap(keyPartition)))
  }

  private def getFOCompany: DataFrame = {
    this.getEntityDataFrame(WorkspacesTableName, List(WorkspacesTargetColumnName, WorkspacesRepartitionColumnName))
  }

  private def getUser: DataFrame = {
    this.readDataFrame(this.getTargetPath(OnHRConf.relationWithMidTable.targetTable), format = "parquet").selectExpr(OnHRConf.relationWithMidTable.targetColumns:_*).distinct
  }

  private def getEntityDataFrame(entityName: String, entityColumns: List[String]): DataFrame = {
    implicit val entity: Entity = this.getEntityObjectFromParquet(entityName)
    this.readEntity(entityName, entityColumns).distinct()
  }
}

