package com.telefonica.onhr.entity

import com.telefonica.onhr.util.Constants._
import com.telefonica.onhr.util.InvalidFilterOperatorException
import net.liftweb.json

/**
  * SuccessFactors extraction that need to be replicated in RDBMS
  *
  * @constructor create a new Extraction object with name, fields and type of the extraction
  * @param extractionName     Name of the extraction
  * @param extractionEntities List of [[Entity]] object
  * @param extractionType     The extraction type defines the way to write the table
  */

class Extraction(var extractionName: String,
                 val extractionEntities: List[Entity],
                 val extractionType: String = "FULL",
                 val dateFilter: String,
                 val fieldFilter: String) {

  this.cleanName()
  private implicit val formats: json.Formats = json.DefaultFormats
  var processType: String = ExtractionProcess
  var repartitionValue: Int = 200
  lazy val fieldList: List[EntityField] = getFieldList

  def setProcessType(processType: String): Unit = {
    this.processType = processType
  }

  def getMajorEntity: Entity = {
    this.getEntity(extractionName, target = "name")
  }

  def getRootEntity: Entity = {
    val entitiesNavigated = this.extractionEntities.flatMap(_.fieldList).filter(_.hasReference).map(_.getEntityReference).distinct
    this.getEntity(this.extractionEntities.map(_.entityAlias).diff(entitiesNavigated).head)
  }

  def getNamesNdTypes: List[(String, String)] = {
    this.fieldList.map { field =>
      (if (field.hasAlias) field.alias else field.fieldName) -> (if (field.fieldType.equalsIgnoreCase("entity")) this.getFieldType(field.referencedField) else field.fieldType)
    }
  }

  def getFieldsToShowAsList: List[String] = {
    this.extractionEntities.flatMap(_.getFieldsToShowAsList)
  }

  def getDateFilter: Array[String] = {
    this.dateFilter.trim.split(" < ")
  }

  def getEntitiesNames: List[String] = {
    this.extractionEntities.map(entity => entity.entityName)
  }

  def getEntity(entityName: String, target: String = "alias"): Entity = {

    var entity: Entity = null

    if (target.equalsIgnoreCase("alias")) {
      entity = this.extractionEntities.filter(entity => entity.entityAlias == entityName).head
    } else {
      entity = this.extractionEntities.filter(entity => entity.entityName == entityName).head
    }
    entity
  }

  def getField(fieldName: String): EntityField = {
    this.extractionEntities.flatMap(_.fieldList.filter(field => field.fieldName == fieldName)).head
  }

  def getColumnsWithAlias: Map[String, String] = {
    this.extractionEntities.flatMap(_.getColumnsWithAlias).toMap
  }

  def getColumnsToApplyHash: List[EntityField] = {
    this.extractionEntities.flatMap(_.getColumnsToApplyHash)
  }

  def getColumnsToApplyNull: List[EntityField] = {
    this.extractionEntities.flatMap(_.getColumnsToApplyNull)
  }

  def getColumnsToApplyIndex: List[EntityField] = {
    this.extractionEntities.flatMap(_.getColumnsToApplyIndex)
  }

  def getColumnsToDenormalize: Map[String, List[EntityField]] = {
    this.extractionEntities.flatMap(_.getColumnsToDenormalize).toMap
  }

  def hasToApplyAnon: Boolean = {
    this.getColumnsToApplyNull.nonEmpty || this.getColumnsToApplyHash.nonEmpty
  }

  def hasToApplyNull: Boolean = {
    this.getColumnsToApplyNull.nonEmpty
  }

  def hasToApplyHash: Boolean = {
    this.getColumnsToApplyHash.nonEmpty
  }

  def hasToCreateIndex: Boolean = {
    this.getColumnsToApplyIndex.nonEmpty
  }

  def needDenormalize: Boolean = {
    this.fieldList.exists(_.cardinality)
  }

  def needToApplyDateFilter: Boolean = {
    val hasRootEntityDateFields = this.getRootEntity.hasEndDate && this.getRootEntity.hasStartDate
    val hasNavEntityDateFields = this.extractionEntities.filter(entity => entity != this.getRootEntity && entity.needDenormalize)
                                                        .flatMap(_.fieldList.filter(_.cardinality)).map(_.getEntityReference).distinct
                                                        .map(this.getEntity(_))
                                                        .exists(entity => entity.hasStartDate && entity.hasEndDate)
    hasRootEntityDateFields && hasNavEntityDateFields
  }

  def getDistributionProcess(country: String): Int = {
    if (ExcludedTablesRegex.findAllIn(this.extractionName).nonEmpty && !country.equalsIgnoreCase("gbu")) {
      4
    } else if (country.equalsIgnoreCase("gbu") && OnHRConf.gbuMapping.keys.exists(_ == this.extractionName)) {
      1
    } else if (this.fieldList.map(_.getFinalName).contains(WorkspacesOriginColumnName) && !country.equalsIgnoreCase("gbu")) {
      2
    } else if (this.fieldList.map(_.getFinalName).contains(WorkspacesSecondaryOriginColumnName) && !country.equalsIgnoreCase("gbu")) {
      3
    } else {
      0
    }
  }

  def getDateIntersectionAsSQL: String = {
    val rootEntity = this.getRootEntity

    val rootStartDate = rootEntity.getField(s"${rootEntity.entityName}_startDate")
    val rootEndDate = rootEntity.getField(s"${rootEntity.entityName}_endDate")

    // Filtramos y nos quedamos con las entidades que no sean la padre y que tengan relacion NM (tablas de la izquierda en la relacion)
    // Nos quedamos con la lista de nombres de las entidades a navegar (tablas de la derecha de la relacion)
    // Recuperamos los objetos de las entidades (tablas de la derecha de la relacion)
    // Filtramos las entidades por las que tengan campo de fecha de inicio y fin

    val navigatedEntities = this.extractionEntities.filter(entity => entity != rootEntity && entity.needDenormalize)
                                                   .flatMap(_.fieldList.filter(_.cardinality).map(_.getEntityReference)).distinct
                                                   .map(this.getEntity(_))
                                                   .filter(entity => entity.hasStartDate && entity.hasEndDate)

    navigatedEntities.map { entity =>
      s"(${rootStartDate.alias} <= ${entity.getEndDateField.alias} AND ${rootEndDate.alias} >= ${entity.getStartDateField.alias})"
    }.mkString(" AND ")
  }

  def getFieldFilterAsSQL: String = {
    val filterConditionType = this.getConditionType

    this.getConditionsAsList(filterConditionType).map { expression =>

      val EntityRegex(entity, field) = expression
      val targetEntity = this.getEntity(entity.trim)
      val targetField = targetEntity.getField(f"${targetEntity.entityName}_${field.trim}")
      val simpleExpression = expression.replaceAll(EntityRegex.toString, "").trim

      val operatorList = OperatorsFilterRegex.r.findAllIn(simpleExpression).map(_.trim).toList
      val expressionList = simpleExpression.split(OperatorsFilterRegex).map(_.trim)

      var SQLCondition: String = "("
      expressionList.zipAll(operatorList, "", "").foreach { case (expressionCase, conditionType) =>
        val ConditionRegex(filter, value) = expressionCase

        var formattedValue = value.replace("'", "").trim

        if (filter.toLowerCase.contains("contained")) {
          formattedValue = value.split(",").map(value => f"'${value.replace("'", "").trim}'").mkString(",")
        }

        var filterCondition = FilterConditions(filter.trim).format(if (targetField.hasAlias) targetField.alias else targetField.fieldName,
          formattedValue)

        if (targetField.fieldType.toLowerCase.contains("boolean")) {
          filterCondition = filterCondition.replace("'", "")
        }

        if (formattedValue.equalsIgnoreCase("null")) {
          filterCondition = filterCondition.replace("'", "")
                                           .replace("!=", "is not")
                                           .replace("=", "is")
        }

        SQLCondition += filterCondition
        if (conditionType.nonEmpty)
          SQLCondition += f" $conditionType"

        SQLCondition += " "
      }
      SQLCondition.trim.concat(")")
    }.mkString(f" $filterConditionType ")
  }

  private def getConditionsAsList(conditionType: String): List[String] = {
    val conditionRegexMap: Map[String, String] = Map("AND" -> f"\\)$AndFilterRegex\\(",
      "OR" -> f"\\)$OrFilterRegex\\(")
    if (conditionRegexMap.contains(conditionType))
      this.fieldFilter.split(conditionRegexMap(conditionType)).map(_.replaceAll("[(|)]", "")).toList
    else
      List(this.fieldFilter.replaceAll("[(|)]", ""))
  }

  private def getConditionType: String = {

    val andRegex = f"\\)$AndFilterRegex\\(".r.unanchored
    val orRegex = f"\\)$OrFilterRegex\\(".r.unanchored
    val filterRegex = FiltersRegex.r

    this.fieldFilter match {
      case andRegex(_) => "AND"
      case orRegex(_) => "OR"
      case filterRegex(_) => ""
      case _ => throw new InvalidFilterOperatorException
    }
  }

  private def getFieldType(fieldName: String): String = {
    try {
      this.fieldList.filter(field => field.fieldName.equalsIgnoreCase(fieldName)).head.fieldType
    } catch {
      case _: java.util.NoSuchElementException => "string"
    }
  }

  private def getFieldList: List[EntityField] = {
    if (this.processType.equalsIgnoreCase("EXTRACTION")) {
      this.extractionEntities.flatMap(entity => entity.fieldList)
    } else {
      this.getMajorEntity.fieldList
    }
  }

  private def cleanName(): Unit = {
    this.extractionName = extractionName.replace("-", "_")
  }

  override def toString: String = json.Serialization.write(this)

}
