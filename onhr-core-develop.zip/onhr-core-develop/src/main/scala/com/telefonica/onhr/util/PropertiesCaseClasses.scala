package com.telefonica.onhr.util

trait customProperties {}

case class WorkspaceProperties(name: String,
                               default: Boolean,
                               anonymised: Boolean,
                               hiveIngest: Boolean,
                               MySQLIngest: Boolean,
                               JDBCConns: List[String],
                               countryCodes: List[String])  {

  final def getSchemaName(anonymised: Boolean = false): String = {
    if (anonymised) {
      this.name.concat("_anonymised")
    } else {
      this.name
    }
  }

}

case class GbuMap(originField: String,
                  targetTable: String,
                  targetField: String,
                  gbuField: String)

case class MidTableProperties(originTables: List[String],
                              originField: String,
                              targetTable: String,
                              targetColumns: List[String])

case class TableFieldReplace(originField: String,
                             replaceField: String)

case class OnHRProperties(schemas: Map[String, WorkspaceProperties],
                          entitySchema: String,
                          globalSchema: String,
                          denormSeparator: String,
                          defaultTableFilters: Map[String, Map[String, String]],
                          relationWithMidTable: MidTableProperties,
                          gbuValues: List[String],
                          defaultTableFieldReplace: Map[String, TableFieldReplace],
                          gbuMapping: Map[String, GbuMap]) extends customProperties {

  final def getSchemas: Map[String, WorkspaceProperties] = {
    this.schemas.filter(item => item._1 != this.entitySchema && item._1 != this.globalSchema)
  }

  final def getSchema(schema: String): WorkspaceProperties = {
    this.schemas.getOrElse(schema, throw new SchemaDoesNotExistsException(s"The following schema is not contained on properties file: $schema"))
  }
}

case class HDFSProperties(var rootPath: String,
                          sourcePath: String,
                          processedPath: String,
                          anonymisedPath: String,
                          nonAnonymisedPath: String,
                          catalogPath: String,
                          defaultSeparator: String) extends customProperties

case class JDBCConnection(dbType: String,
                          driver: String,
                          username: String,
                          password: String,
                          host: String,
                          port: String,
                          timestampFormat: String,
                          indexPrefix: String) {}

case class JDBCProperties(jdbcConnections: Map[String, JDBCConnection]) extends customProperties {

  final def getConnection(connection: String): JDBCConnection = {
    this.jdbcConnections.getOrElse(connection, null)
  }
}

case class HiveProperties(timestampFormat: String,
                          schemaPrefix: String,
                          anonymisedSuffix: String) extends customProperties