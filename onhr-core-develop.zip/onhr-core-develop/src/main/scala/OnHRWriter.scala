
import java.io.File

import com.telefonica.onhr.controller._
import com.telefonica.onhr.entity.{Entity, EntityField, Extraction}
import com.telefonica.onhr.util.Constants._
import com.telefonica.onhr.util._
import org.apache.log4j.Logger
import org.apache.spark.sql.DataFrame

/**
  * Main class for onhr-core project.
  * Read, process and store an Extraction from HDFS to Hive and MySQL.
  */
object OnHRWriter extends App {
  // Initialize the logger
  val logger = Logger.getLogger("onhr." + this.getClass.getSimpleName.split("\\$").last)

  // The extraction name must be passed as parameter
  if (args.length < 4) {
    throw new IllegalArgumentException("Not enough arguments to run.")
  }


  val processType = new File(args(1)).toString
  val folderName = new File(args(2)).toString
  var executionType: String = new File(args(3)).toString
  var workspace: String = _

  var PROCESS_NAME: String = _


  logger.info(f"Process type: $processType%s")
  logger.info(f"Folder name: $folderName%s")
  logger.info(f"Execution type: $executionType%s")

  PROCESS_NAME = s"onHR-core_${processType}_${folderName}_$executionType".toUpperCase

  if (!processType.equalsIgnoreCase(EntityProcess)) {
    if (args.length < 5) {
      throw new IllegalArgumentException("Not enough arguments to run.")
    }

    workspace = new File(args(4)).toString.toLowerCase
    logger.info(f"Workspace: $workspace%s")

    PROCESS_NAME = s"onHR-core_${processType}_${folderName}_${executionType}_$workspace".toUpperCase
  }

  logger.info("Initializing process...")

  // Initializing each controller to interact
  val sparkController: SparkController = new SparkController(PROCESS_NAME)
  val propertiesFile = new File(sparkController.getProperties(args(0))).toString
  logger.info(f"Properties files: $propertiesFile%s")

  try {

    Constants.setPropertiesFile(propertiesFile)

    lazy val hiveController: HiveController = new HiveController(sparkController.getSparkSession)
    lazy val dfController: DataFrameController = new DataFrameController(sparkController.getSparkSession)
    lazy val JDBCController: JDBCController = new JDBCController

    implicit val extraction: Extraction = new MetadataParser(dfController.readJSON(folderName)).getExtraction

    var extractionDF: DataFrame = null

    if (processType.equalsIgnoreCase(EntityProcess)) {
      extraction.setProcessType(processType)

      val entitySchemaProperties = OnHRConf.getSchema(OnHRConf.entitySchema)
      implicit val entity: Entity = extraction.getMajorEntity

      if (executionType.equalsIgnoreCase(executionTypes.HIVE)) {
        // Retrieve a DataFrame that contains the Extraction data
        extractionDF = dfController.readDataFrameExtraction(extractionName = folderName)

        val hasContent = extractionDF.head(1).nonEmpty

        if (extraction.extractionType.equalsIgnoreCase("full") || extraction.extractionType.equalsIgnoreCase("init") || hasContent) {

          extraction.repartitionValue = if (!hasContent) 1 else extraction.repartitionValue

          // Write the Extraction with parquet format on HDFS
          dfController.writeDataFrame(extractionDF, isCatalog = true)

          if (entitySchemaProperties.hiveIngest && entitySchemaProperties.default) {
            hiveController.runHQLStatement(hiveController.getHQL(extractionDF, isCatalog = true))
          }

          if (dfController.isParquetEmpty(dfController.getCatalogPath(extraction.extractionName))) {
            extractionDF = dfController.createEmptyDataFrame(dfController.getDataFrameSchema())
          } else {
            extractionDF = dfController.getUpdatedEntity(entity.entityName)
          }

          if (extraction.needDenormalize) {
            extraction.getColumnsToDenormalize.foreach { case (tableName, fieldList) =>
              dfController.writeDenormDataFrame(dfController.denormalize(extractionDF, fieldList), tableName, extraction.extractionType)
            }
          }
        }
      } else {

        if (entitySchemaProperties.MySQLIngest && entitySchemaProperties.default) {

          if (dfController.isParquetEmpty(dfController.getCatalogPath(extraction.extractionName))) {
            extractionDF = dfController.createEmptyDataFrame(dfController.getDataFrameSchema())
          } else {
            extractionDF = dfController.getUpdatedEntity(entity.entityName)
          }

          entitySchemaProperties.JDBCConns.foreach { entityConn =>
            JDBCController.runSQLStatement(JDBCController.getSQL(extractionDF, isCatalog = true),
              JDBCConf.getConnection(entityConn))
            dfController.writeOnJDBC(extractionDF, isCatalog = true, jdbcConnection = JDBCConf.getConnection(entityConn))
          }
        }
      }

    } else {

      val schema = OnHRConf.getSchema(workspace)

      if (executionType.equalsIgnoreCase(executionTypes.HIVE)) {

        if (workspace.equalsIgnoreCase(OnHRConf.globalSchema)) {

          EntityNdConditionRegex.findAllIn(extraction.fieldFilter).matchData.foreach { filter =>
            val entity = extraction.getEntity(filter.group(1).trim)
            val field = f"${entity.entityName}_${filter.group(2)}"

            if (!entity.fieldList.map(_.fieldName).contains(field)) {
              val newField = new EntityField(fieldName = field,
                fieldType = "STRING",
                anonType = "",
                alias = "",
                isIndex = false,
                isKey = false,
                cardinality = false,
                referencedField = "",
                toOverwrite = false,
                show = Some(false))

              entity.fieldList = newField :: entity.fieldList
            }
          }

          // Consolidate a extraction applying joins and filters
          extractionDF = dfController.consolidate(extraction)

        } else {

          this.logger.debug(s"Checking workspace distribution for: $workspace")
          val distributionProcessCode = extraction.getDistributionProcess(workspace)

          this.logger.debug(s"Applying ${DistributionProcess(distributionProcessCode)} distribution for: $workspace")

          if (dfController.isParquetEmpty(dfController.getTargetPath(extraction.extractionName))) {
            extractionDF = dfController.createEmptyDataFrame(dfController.getDataFrameSchema(withNav = false, alias = true))
          } else {
            extractionDF = dfController.readDataFrame(dfController.getTargetPath(extraction.extractionName), format = "parquet")
          }

          extraction.extractionEntities.foreach(entity => entity.fieldList.foreach(field => if (field.hasAlias) field.applyAlias()))

          try {

            extractionDF = dfController.getCountryInfo(extraction.extractionName, extractionDF, schema, distributionProcessCode)

          }catch {
            case ent: PathNotExistException =>
              logger.warn(s"The following table is required for workspace distribution: ${ent.remotePath}. Aborting")
            case fne: FieldNotInEntityException =>
              logger.warn(fne.getMessage.concat(". Aborting"))
            case edfe: EmptyDataFrameException =>
              logger.warn(edfe.getMessage.concat(". Aborting"))
          }
        }

        if (schema.default && (schema.hiveIngest || schema.MySQLIngest)) {
          // Write the Extraction with parquet format on HDFS
          dfController.writeDataFrame(extractionDF, workspace = workspace)

          if (schema.hiveIngest) {
            // Create the HQL statement to be able to access data from Hive
            hiveController.runHQLStatement(hiveController.getHQL(extractionDF, workspace = workspace))
          }

        }

        if ((schema.hiveIngest || schema.MySQLIngest) & extraction.hasToApplyAnon && schema.anonymised) {
          // Copy the dataframe
          var anonExtractionDF = extractionDF

          // Apply hash process
          if (extraction.hasToApplyHash)
            anonExtractionDF = dfController.applyHash(anonExtractionDF, extraction.getColumnsToApplyHash)

          // Apply null process
          if (extraction.hasToApplyNull)
            anonExtractionDF = dfController.applyNull(anonExtractionDF, extraction.getColumnsToApplyNull)

            // Write the Extraction with parquet format on HDFS
            dfController.writeDataFrame(anonExtractionDF, isAnonymised = true, workspace = workspace)

          if (schema.hiveIngest) {
            // Create the HQL statement to be able to access data from Hive
            hiveController.runHQLStatement(hiveController.getHQL(anonExtractionDF, isAnonymised = true, workspace = workspace))
          }

        }

      } else if (executionType.equalsIgnoreCase(executionTypes.JDBC)) {

        extraction.extractionEntities.foreach(entity => entity.fieldList.foreach(field => if (field.hasAlias) field.applyAlias()))

        val conns = schema.JDBCConns.map(JDBCConf.getConnection)

        if (schema.default && schema.MySQLIngest) {

          if (dfController.isParquetEmpty(dfController.getTargetPath(extraction.extractionName, workspace = workspace))) {
            extractionDF = dfController.createEmptyDataFrame(dfController.getDataFrameSchema(withNav = false, alias = true))
          } else {
            extractionDF = dfController.readDataFrame(dfController.getTargetPath(extraction.extractionName, workspace = workspace), format = "parquet")
          }

          conns.foreach { connection =>
            // Create the SQL statement to be able to access data from MySQL
            JDBCController.runSQLStatement(JDBCController.getSQL(extractionDF, workspace = workspace), connection)

            // Writing on database
            dfController.writeOnJDBC(extractionDF, jdbcConnection = connection, workspace = workspace)

            // Create target indexes
            if (extraction.hasToCreateIndex) {
              this.logger.info("Creating indexes for non-anonymised data.")
              JDBCController.runSQLStatement(JDBCController.getIndexes(jdbcConnection = connection, workspace = workspace), connection)
            }
          }

          if (!schema.hiveIngest) {
            this.logger.info(s"Deleting path: ${dfController.getTargetPath(extraction.extractionName, workspace = workspace)}")
            dfController.deletePath(dfController.getTargetPath(extraction.extractionName, workspace = workspace))
          }
        }

        if (extraction.hasToApplyAnon && schema.anonymised && schema.MySQLIngest) {

          if (dfController.isParquetEmpty(dfController.getTargetPath(extraction.extractionName, workspace = workspace, isAnonymised = true))) {
            extractionDF = dfController.createEmptyDataFrame(dfController.getDataFrameSchema(withNav = false, alias = true))
          } else {
            extractionDF = dfController.readDataFrame(dfController.getTargetPath(extraction.extractionName, workspace = workspace, isAnonymised = true), format = "parquet")
          }

          conns.foreach { connection =>
            // Create the SQL statement to be able to access data from MySQL
            JDBCController.runSQLStatement(JDBCController.getSQL(extractionDF, isAnonymised = true, workspace = workspace), connection)

            // Writing on database
            dfController.writeOnJDBC(extractionDF, isAnonymised = true, jdbcConnection = connection, workspace = workspace)

            // Create target indexes
            if (extraction.hasToCreateIndex) {
              this.logger.info("Creating indexes for anonymised data.")
              JDBCController.runSQLStatement(JDBCController.getIndexes(isAnonymised = true, jdbcConnection = connection, workspace = workspace), connection)
            }
          }

          if (!schema.hiveIngest) {
            this.logger.info(s"Deleting path: ${dfController.getTargetPath(extraction.extractionName, isAnonymised = true, workspace = workspace)}")
            dfController.deletePath(dfController.getTargetPath(extraction.extractionName, isAnonymised = true, workspace = workspace))
          }
        }

      } else {
        this.logger.error("Unknown execution type. Aborting.")
      }
    }
  } catch {
    case iae: IllegalArgumentException =>
      logger.error("Error parsing arguments:")
      logger.error(iae.getMessage)
      throw iae

    case pe: PropertiesException =>
      logger.error("Error parsing configurations:")
      logger.error(pe.getMessage)
      throw pe

    case me: net.liftweb.json.MappingException =>
      logger.error("Error parsing metadata:")
      logger.error(me.getMessage)
      throw me

    case mm: MetadataMismatchException =>
      logger.error("Error with metadata file:")
      logger.error(mm.getMessage)
      throw mm

    case ent: PathNotExistException =>
      logger.error("File does not exists:")
      logger.error(ent.getMessage)
      throw ent

    case e: Exception =>
      logger.error("Unknown error:")
      throw e

  } finally {
    // Close the current SparkSession
    sparkController.terminate()
  }
}
