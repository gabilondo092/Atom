from base64 import b64encode
from datetime import timedelta
from os import path

from airflow import DAG
from airflow import configuration
from airflow.contrib.hooks.ssh_hook import SSHHook
from airflow.contrib.operators.ssh_operator import SSHOperator
from airflow.exceptions import AirflowException
from airflow.hooks.base_hook import BaseHook
from airflow.models import Variable
from airflow.operators.python_operator import BranchPythonOperator
from airflow.utils.dates import days_ago
from airflow.utils.decorators import apply_defaults
from airflow.utils.trigger_rule import TriggerRule
from select import select


class CustomSSHOperator(SSHOperator):
    template_fields = ('remote_host', 'extraction', 'extraction_type')

    @apply_defaults
    def __init__(self, extraction, extraction_type, *args, **kwargs):
        super(CustomSSHOperator, self).__init__(*args, **kwargs)
        self.extraction_type = extraction_type
        self.extraction = extraction
        # self.command = super(CustomSSHOperator, self).command % folder

    def execute(self, context):
        if self.command:
            self.extraction = 'entities/%s' % self.extraction if self.extraction_type == "ENTITY" else 'extractions/%s' % self.extraction
            self.command = self.command.replace('ONHR_EXTRACTION', self.extraction)
        try:
            if self.ssh_conn_id:
                if self.ssh_hook and isinstance(self.ssh_hook, SSHHook):
                    self.log.info("ssh_conn_id is ignored when ssh_hook is provided.")
                else:
                    self.log.info("ssh_hook is not provided or invalid. " +
                                  "Trying ssh_conn_id to create SSHHook.")
                    self.ssh_hook = SSHHook(ssh_conn_id=self.ssh_conn_id,
                                            timeout=self.timeout)

            if not self.ssh_hook:
                raise AirflowException("Cannot operate without ssh_hook or ssh_conn_id.")

            if self.remote_host is not None:
                self.log.info("remote_host is provided explicitly. " +
                              "It will replace the remote_host which was defined " +
                              "in ssh_hook or predefined in connection of ssh_conn_id.")
                self.ssh_hook.remote_host = self.remote_host

            if not self.command:
                raise AirflowException("SSH command not specified. Aborting.")

            with self.ssh_hook.get_conn() as ssh_client:
                # Auto apply tty when its required in case of sudo
                get_pty = False
                if self.command.startswith('sudo'):
                    get_pty = True

                # set timeout taken as params
                stdin, stdout, stderr = ssh_client.exec_command(command=self.command,
                                                                get_pty=get_pty,
                                                                timeout=self.timeout
                                                                )
                # get channels
                channel = stdout.channel

                # closing stdin
                stdin.close()
                channel.shutdown_write()

                agg_stdout = b''
                agg_stderr = b''

                # capture any initial output in case channel is closed already
                stdout_buffer_length = len(stdout.channel.in_buffer)

                if stdout_buffer_length > 0:
                    agg_stdout += stdout.channel.recv(stdout_buffer_length)

                # read from both stdout and stderr
                while not channel.closed or \
                        channel.recv_ready() or \
                        channel.recv_stderr_ready():
                    readq, _, _ = select([channel], [], [], self.timeout)
                    for c in readq:
                        if c.recv_ready():
                            line = stdout.channel.recv(len(c.in_buffer))
                            line = line
                            agg_stdout += line
                            self.log.info(line.decode('utf-8').strip('\n'))
                        if c.recv_stderr_ready():
                            line = stderr.channel.recv_stderr(len(c.in_stderr_buffer))
                            line = line
                            agg_stderr += line
                            self.log.warning(line.decode('utf-8').strip('\n'))
                    if stdout.channel.exit_status_ready() \
                            and not stderr.channel.recv_stderr_ready() \
                            and not stdout.channel.recv_ready():
                        stdout.channel.shutdown_read()
                        stdout.channel.close()
                        break

                stdout.close()
                stderr.close()

                exit_status = stdout.channel.recv_exit_status()
                if exit_status == 0:
                    # returning output if do_xcom_push is set
                    if self.do_xcom_push:
                        enable_pickling = configuration.conf.getboolean(
                            'core', 'enable_xcom_pickling'
                        )
                        if enable_pickling:
                            return agg_stdout
                        else:
                            return b64encode(agg_stdout).decode('utf-8')

                else:
                    error_msg = agg_stderr.decode('utf-8')
                    raise AirflowException("error running cmd: {0}, error: {1}"
                                           .format(self.command, error_msg))

        except Exception as e:
            raise AirflowException("SSH operator error: {0}".format(str(e)))

        return True


EXTRACTION_NAME = '{{ dag_run.conf["folder_name"] }}'
EXTRACTION_TYPE = '{{ dag_run.conf["folder_type"] }}'

# Set airflow connections names
SSH_CONN_NODE = "ssh_onhr_node"
SSH_CONN_SFTP = "ssh_onhr_sftp"

MONITOR_VAR = "TASK_MONITOR"

# Extract process variables from Airflow
ONHR_CORE_PATH = Variable.get("ONHR-CORE_PATH")

LANDING_PATH_SFTP = Variable.get("LANDING_PATH_SFTP")
LANDING_PATH_HDFS = Variable.get("LANDING_PATH_HDFS")

STAGING_PATH_NODE = Variable.get("STAGING_PATH_NODE")

FILE_SEPARATOR = Variable.get("FILE_SEPARATOR")

SCHEMA_LIST = map(lambda item: item.strip(), Variable.get("SCHEMA_LIST").split(','))

NODE_FOLDER = path.join(STAGING_PATH_NODE, EXTRACTION_NAME)
DATA_FILE = path.join(NODE_FOLDER, EXTRACTION_NAME + '*.csv')
METADATA_FILE = path.join(NODE_FOLDER, EXTRACTION_NAME + '.json')

sftp_conn = BaseHook.get_connection(SSH_CONN_SFTP)

SPARK_TASK_NAME = "spark-submit-onHR"

# spark-submit properties
SPARK_PROPERTIES_LOW = Variable.get(key="SPARK_PROPERTIES_LOW",
                                    deserialize_json=True)

SPARK_SUBMIT_PROPERTIES_LOW = list()
for key in SPARK_PROPERTIES_LOW.keys():
    if key != "FIXED_PARAMETERS":
        SPARK_SUBMIT_PROPERTIES_LOW.append("--%s %s" % (key, SPARK_PROPERTIES_LOW[key]))

# spark-submit properties
SPARK_PROPERTIES_MEDIUM = Variable.get(key="SPARK_PROPERTIES_MEDIUM",
                                       deserialize_json=True)
SPARK_SUBMIT_PROPERTIES_MEDIUM = list()
for key in SPARK_PROPERTIES_MEDIUM.keys():
    if key != "FIXED_PARAMETERS":
        SPARK_SUBMIT_PROPERTIES_MEDIUM.append("--%s %s" % (key, SPARK_PROPERTIES_MEDIUM[key]))

lftp_command = "lftp -p {port} sftp://{user}:{passwd}@{host} -e \"%s {path}/ONHR_EXTRACTION; bye\"".format(
    port=sftp_conn.port,
    user=sftp_conn.login,
    passwd=sftp_conn.password,
    host=sftp_conn.host,
    path=LANDING_PATH_SFTP)

cd_to_path = "cd {path}".format(path=STAGING_PATH_NODE)

SFTP_DOWNLOAD_COMMAND_LIST = [cd_to_path,
                              lftp_command % "mirror"]

SFTP_REMOVE_COMMAND_LIST = [cd_to_path,
                            lftp_command % "rm -r"]

# HDFS command to upload the extraction
HDFS_PUT_COMMAND = "hadoop fs -put -f {node_folder} {hdfs_folder}".format(node_folder=NODE_FOLDER,
                                                                          hdfs_folder=LANDING_PATH_HDFS)

HDFS_RM_COMMAND = "hadoop fs -rm -r -f {hdfs_folder}".format(hdfs_folder="%s/%s" % (LANDING_PATH_HDFS, EXTRACTION_NAME))

NODE_RM_COMMAND = "rm -r -f {node_folder}".format(node_folder=NODE_FOLDER)

CLEAN_COMMAND_LIST = ["FILE_PATH=\"%s\"" % DATA_FILE,
                      "SEP='%s'" % FILE_SEPARATOR,
                      "sed -i -e 's/\\\|\\\//g' ${FILE_PATH}",
                      "for line in $(ls -1 ${FILE_PATH})",
                      "do echo \"$line\"",
                      "COLUMNS_LEN=$(awk -F\"$SEP\" '{print NF; exit}' \"$line\")",
                      "awk -F\"$SEP\" -v col=\"$COLUMNS_LEN\" '{if(NF==col) {print $0}}' \"$line\" > \"$line\"_new",
                      "mv \"$line\"_new \"$line\"",
                      "done",
                      "awk -v RS= '{$1=$1}1' %s > %s_clean" % (METADATA_FILE, METADATA_FILE),
                      "mv %s_clean %s" % (METADATA_FILE, METADATA_FILE)]


def success_callback(context):
    task_dict = Variable.get(key=MONITOR_VAR,
                             deserialize_json=True)

    if context['dag_run'].conf['folder_type'] == "ENTITY":
        task_dict['entities'].remove(context['dag_run'].conf['folder_name'])
    else:
        task_dict['extractions'].remove(context['dag_run'].conf['folder_name'])

    Variable.set(key=MONITOR_VAR,
                 value=task_dict,
                 serialize_json=True)


def failure_callback(context):
    task_dict = Variable.get(key=MONITOR_VAR,
                             deserialize_json=True)

    if context['dag_run'].conf['folder_type'] == "ENTITY":
        task_dict['entities'].remove(context['dag_run'].conf['folder_name'])
    else:
        task_dict['extractions'].remove(context['dag_run'].conf['folder_name'])

    task_dict['failed'].append(context['dag_run'].conf['folder_name'])

    Variable.set(key=MONITOR_VAR,
                 value=task_dict,
                 serialize_json=True)


def get_operators_to_run(**kwargs):
    operators_to_run = ["%s-jdbc" % SPARK_TASK_NAME]

    if kwargs['dag_run'].conf['folder_type'] != "ENTITY":
        for schema_name in list(map(lambda item: item.strip(), Variable.get("SCHEMA_LIST").split(','))):
            operators_to_run.append("%s-hive-%s" % (SPARK_TASK_NAME, schema_name))

    return operators_to_run


my_args = {
    'owner': 'airflow',
    'email_on_failure': False,
    'on_failure_callback': failure_callback
}

dag = DAG(dag_id='onHR_ETL',
          schedule_interval=None,
          start_date=days_ago(2),
          default_args=my_args,
          max_active_runs=5,
          concurrency=25)

sftp_folder_download = CustomSSHOperator(task_id="sftp_folder_download",
                                         ssh_conn_id=SSH_CONN_NODE,
                                         command=';'.join(SFTP_DOWNLOAD_COMMAND_LIST),
                                         extraction=EXTRACTION_NAME,
                                         extraction_type=EXTRACTION_TYPE,
                                         dag=dag)

# Upload the file from the tmp folder to HDFS
clean_files = SSHOperator(task_id="clean_files",
                          ssh_conn_id=SSH_CONN_NODE,
                          command=';'.join(CLEAN_COMMAND_LIST),
                          dag=dag)

# Upload the file from the tmp folder to HDFS
node_to_hdfs = SSHOperator(task_id="node_to_hdfs",
                           ssh_conn_id=SSH_CONN_NODE,
                           command=';'.join([HDFS_RM_COMMAND, HDFS_PUT_COMMAND]),
                           dag=dag)

node_folder_remove = SSHOperator(task_id="node_folder_remove",
                                 ssh_conn_id=SSH_CONN_NODE,
                                 command=NODE_RM_COMMAND,
                                 dag=dag)

sftp_folder_remove = CustomSSHOperator(task_id="sftp_folder_remove",
                                       ssh_conn_id=SSH_CONN_NODE,
                                       command=';'.join(SFTP_REMOVE_COMMAND_LIST),
                                       extraction=EXTRACTION_NAME,
                                       on_success_callback=success_callback,
                                       extraction_type=EXTRACTION_TYPE,
                                       trigger_rule=TriggerRule.NONE_FAILED,
                                       dag=dag)

hdfs_folder_remove = SSHOperator(task_id="hdfs_folder_remove",
                                 ssh_conn_id=SSH_CONN_NODE,
                                 command=HDFS_RM_COMMAND,
                                 dag=dag)

JAR_PARAMETERS = SPARK_PROPERTIES_MEDIUM["FIXED_PARAMETERS"] + [EXTRACTION_TYPE, EXTRACTION_NAME, "HIVE", "GLOBAL"]

# Commands to be executed in the remote machine
SPARK_COMMAND_LIST = ["export SPARK_MAJOR_VERSION=2",  # Set spark version to pick, 2.+
                      "cd {path}".format(path=ONHR_CORE_PATH),  # Change directory to project root
                      "spark-submit {properties} {parameters}".format(
                          properties=' '.join(SPARK_SUBMIT_PROPERTIES_MEDIUM),
                          parameters=' '.join(JAR_PARAMETERS))]

# Execute the spark-submit process via ssh on the remote node
spark_submit_onHR_hive = SSHOperator(task_id="%s-hive" % SPARK_TASK_NAME,
                                     ssh_conn_id=SSH_CONN_NODE,
                                     command=';'.join(SPARK_COMMAND_LIST),
                                     retries=1,
                                     execution_timeout=timedelta(minutes=180),
                                     dag=dag)

JAR_PARAMETERS = SPARK_PROPERTIES_LOW["FIXED_PARAMETERS"] + [EXTRACTION_TYPE, EXTRACTION_NAME, "JDBC", "GLOBAL"]

# Commands to be executed in the remote machine
SPARK_COMMAND_LIST = ["export SPARK_MAJOR_VERSION=2",  # Set spark version to pick, 2.+
                      "cd {path}".format(path=ONHR_CORE_PATH),  # Change directory to project root
                      "spark-submit {properties} {parameters}".format(properties=' '.join(SPARK_SUBMIT_PROPERTIES_LOW),
                                                                      parameters=' '.join(JAR_PARAMETERS))]
# Execute the spark-submit process via ssh on the remote node
spark_submit_onHR_jdbc = SSHOperator(task_id="%s-jdbc" % SPARK_TASK_NAME,
                                     ssh_conn_id=SSH_CONN_NODE,
                                     command=';'.join(SPARK_COMMAND_LIST),
                                     retries=1,
                                     execution_timeout=timedelta(minutes=180),
                                     trigger_rule=TriggerRule.NONE_FAILED,
                                     dag=dag)

branch_job = BranchPythonOperator(task_id='get_operators_to_run',
                                  provide_context=True,
                                  python_callable=get_operators_to_run,
                                  dag=dag,
                                  )

for schema in SCHEMA_LIST:
    JAR_PARAMETERS_MEDIUM = SPARK_PROPERTIES_MEDIUM["FIXED_PARAMETERS"] + [EXTRACTION_TYPE, EXTRACTION_NAME, "HIVE",
                                                                           schema]

    # Commands to be executed in the remote machine
    SPARK_COMMAND_LIST_MEDIUM = ["export SPARK_MAJOR_VERSION=2",  # Set spark version to pick, 2.+
                                 "cd {path}".format(path=ONHR_CORE_PATH),  # Change directory to project root
                                 "spark-submit {properties} {parameters}".format(
                                     properties=' '.join(SPARK_SUBMIT_PROPERTIES_MEDIUM),
                                     parameters=' '.join(JAR_PARAMETERS_MEDIUM))]

    # Execute the spark-submit process via ssh on the remote node
    spark_submit_onHR_hive_schema = SSHOperator(task_id="%s-hive-%s" % (SPARK_TASK_NAME, schema),
                                                ssh_conn_id=SSH_CONN_NODE,
                                                command=';'.join(SPARK_COMMAND_LIST_MEDIUM),
                                                retries=1,
                                                execution_timeout=timedelta(minutes=180),
                                                dag=dag)

    JAR_PARAMETERS_LOW = SPARK_PROPERTIES_LOW["FIXED_PARAMETERS"] + [EXTRACTION_TYPE, EXTRACTION_NAME, "JDBC", schema]

    # Commands to be executed in the remote machine
    SPARK_COMMAND_LIST_LOW = ["export SPARK_MAJOR_VERSION=2",  # Set spark version to pick, 2.+
                              "cd {path}".format(path=ONHR_CORE_PATH),  # Change directory to project root
                              "spark-submit {properties} {parameters}".format(
                                  properties=' '.join(SPARK_SUBMIT_PROPERTIES_LOW),
                                  parameters=' '.join(JAR_PARAMETERS_LOW))]

    # Execute the spark-submit process via ssh on the remote node
    spark_submit_onHR_jdbc_schema = SSHOperator(task_id="%s-jdbc-%s" % (SPARK_TASK_NAME, schema),
                                                ssh_conn_id=SSH_CONN_NODE,
                                                command=';'.join(SPARK_COMMAND_LIST_LOW),
                                                retries=1,
                                                execution_timeout=timedelta(minutes=180),
                                                dag=dag)

    branch_job.set_downstream(spark_submit_onHR_hive_schema)
    spark_submit_onHR_hive_schema.set_downstream([spark_submit_onHR_jdbc_schema, spark_submit_onHR_jdbc])
    spark_submit_onHR_jdbc_schema.set_downstream([sftp_folder_remove, hdfs_folder_remove])

sftp_folder_download.set_downstream(clean_files)
clean_files.set_downstream(node_to_hdfs)
node_to_hdfs.set_downstream([node_folder_remove, spark_submit_onHR_hive])

spark_submit_onHR_hive.set_downstream(branch_job)
branch_job.set_downstream(spark_submit_onHR_jdbc)
spark_submit_onHR_jdbc.set_downstream([sftp_folder_remove, hdfs_folder_remove])
