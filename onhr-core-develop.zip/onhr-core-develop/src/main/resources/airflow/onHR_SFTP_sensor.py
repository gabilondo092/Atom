import re
from datetime import datetime
from os import path

from airflow import DAG
from airflow.contrib.hooks.sftp_hook import SFTPHook
from airflow.models import Variable
from airflow.operators.dagrun_operator import TriggerDagRunOperator
from airflow.operators.sensors import BaseSensorOperator
from airflow.utils.decorators import apply_defaults
from paramiko import SFTP_NO_SUCH_FILE


class CustomSFTPSensorr(BaseSensorOperator):
    """
    Custom implementation of SFTPSensor to be able to push XCOM data and list folders recursively over SFTP
    """

    template_fields = ('filepath', 'primary_file_pattern', 'secondary_file_pattern')

    @apply_defaults
    def __init__(self, filepath, primary_file_pattern, secondary_file_pattern, sftp_conn_id='sftp_default', *args, **kwargs):
        super(CustomSFTPSensorr, self).__init__(*args, **kwargs)
        self.filepath = filepath
        self.primary_file_pattern = primary_file_pattern
        self.secondary_file_pattern = secondary_file_pattern
        self.hook = SFTPHook(sftp_conn_id)

    def poke(self, context):
        task_instance = context["task_instance"]

        full_path = self.filepath

        primary_file_pattern = re.compile(self.primary_file_pattern)
        secondary_file_pattern = re.compile(self.secondary_file_pattern)

        task_dict = Variable.get(key="TASK_MONITOR", deserialize_json=True)

        try:
            entity_path = path.join(full_path, "entities")
            entity_directory = self.hook.list_directory(entity_path)
            self.log.info("%s entities found: %s" % (len(entity_directory), str(entity_directory)))
            for folder in entity_directory:
                json_match = False
                csv_match = False
                self.log.info("Looking in %s" % folder)
                for extraction_file in self.hook.list_directory(path.join(entity_path, folder)):
                    self.log.info("%s file found on %s" % (extraction_file, folder))

                    json_match = True if json_match or re.match(secondary_file_pattern, extraction_file) else False
                    csv_match = True if csv_match or re.match(primary_file_pattern, extraction_file) else False

                    if json_match and csv_match and folder not in task_dict["entities"] and folder not in task_dict["failed"]:
                        task_instance.xcom_push(key="trigger_etl_parameters",
                                                value={"type": "ENTITY",
                                                       "folder": folder})

                        self.hook.close_conn()
                        return True

            if len(task_dict["entities"]) == 0:

                extraction_path = path.join(full_path, "extractions")
                extraction_directory = self.hook.list_directory(extraction_path)
                self.log.info("%s extractions found: %s" % (len(extraction_directory), str(extraction_directory)))

                for folder in extraction_directory:
                    self.log.info("Looking in %s" % folder)
                    for extraction_file in self.hook.list_directory(path.join(extraction_path, folder)):
                        self.log.info("%s file found on %s" % (extraction_file, folder))
                        if re.match(secondary_file_pattern, extraction_file):
                            if folder not in task_dict["extractions"] and folder not in task_dict["failed"]:
                                task_instance.xcom_push(key="trigger_etl_parameters",
                                                        value={"type": "EXTRACTION",
                                                               "folder": folder})

                                self.hook.close_conn()
                                return True
                    
            return False
        except IOError as e:
            if e.errno != SFTP_NO_SUCH_FILE:
                raise e
            return False


my_args = {
    'owner': 'airflow',
    'email_on_failure': False
}

dag = DAG('onHR_SFTP_sensor',
          schedule_interval='*/5 * * * *',
          start_date=datetime(year=2019, month=12, day=16, hour=15, minute=45, second=33),
          max_active_runs=1,
          default_args=my_args)

conn_id = "sftp_onhr_sftp"

remote_path = Variable.get("LANDING_PATH_SFTP")

json_regex = r'^[a-zA-Z0-9\s_\\.\-\(\):]+\.json$'
csv_regex = r'^[a-zA-Z0-9\s_\\.\-\(\):]+\.csv$'

SFTP_TASK_NAME = "sftp_sensor"
TRIGGER_TASK_NAME = "trigger_ETL"
TARGET_DAG = 'onHR_ETL'

MONITOR_VAR = "TASK_MONITOR"


def get_xcom_as_argument(context, dag_run_obj):
    task_instance = context['ti']

    orig_task_id = task_instance.task_id

    task_dict = Variable.get(key=MONITOR_VAR,
                             deserialize_json=True)

    trigger_etl_parameters = task_instance.xcom_pull(task_ids=SFTP_TASK_NAME,
                                                     key="trigger_etl_parameters")

    dag_run_obj.payload = {'folder_name': trigger_etl_parameters["folder"], 'folder_type': trigger_etl_parameters["type"]}
    dag_run_obj.run_id = '%s_%s_%s' % (trigger_etl_parameters["type"], trigger_etl_parameters["folder"],  context['ts'])

    task_instance.task_id = SFTP_TASK_NAME
    task_instance.clear_xcom_data()
    task_instance.task_id = orig_task_id

    if trigger_etl_parameters["type"] == "ENTITY":
        task_dict["entities"].append(trigger_etl_parameters["folder"])
    else:
        task_dict["extractions"].append(trigger_etl_parameters["folder"])

    Variable.set(key=MONITOR_VAR,
                 value=task_dict,
                 serialize_json=True)

    return dag_run_obj


sftp_sensor = CustomSFTPSensorr(task_id=SFTP_TASK_NAME,
                                filepath=remote_path,
                                primary_file_pattern=csv_regex,
                                secondary_file_pattern=json_regex,
                                mode='reschedule',
                                sftp_conn_id=conn_id,
                                poke_interval=60 * 1,
                                dag=dag)

trigger_dag = TriggerDagRunOperator(task_id=TRIGGER_TASK_NAME,
                                    trigger_dag_id=TARGET_DAG,
                                    python_callable=get_xcom_as_argument,
                                    dag=dag)

sftp_sensor >> trigger_dag
