#!/bin/sh
while getopts ":p:g:l:f:j:m:n:d:e:c:t:" opt; do
  case $opt in
    p) path="$OPTARG"
    ;;
    g) log_file="$OPTARG"
    ;;
    l) lib_jars="$OPTARG"
    ;;
    f) files="$OPTARG"
    ;;
    j) jar_param="$OPTARG"
    ;;
    m) master="$OPTARG"
    ;;
    n) num_executors="$OPTARG"
    ;;
    d) driver_memory="$OPTARG"
    ;;
    e) executor_memory="$OPTARG"
    ;;
    c) executor_cores="$OPTARG"
    ;;
    t) threshold="$OPTARG"
    ;;
    \?) echo "Invalid option -$OPTARG" >&2 && exit 1
    ;;
  esac
done
if [ -z ${path+x} ]; then echo "-p is necessary" && exit 1;  fi
if [ -z ${log_file+x} ]; then echo "-g is necessary" && exit 1;  fi
if [ -z ${lib_jars+x} ]; then echo "-l is necessary" && exit 1;  fi
if [ -z ${files+x} ]; then echo "-f is necessary" && exit 1;  fi
if [ -z ${master+x} ]; then echo "-m is necessary" && exit 1;  fi
if [ -z ${num_executors+x} ]; then echo "-n is necessary" && exit 1;  fi
if [ -z ${driver_memory+x} ]; then echo "-d is necessary" && exit 1;  fi
if [ -z ${executor_memory+x} ]; then echo "-e is necessary" && exit 1;  fi
if [ -z ${executor_cores+x} ]; then echo "-c is necessary" && exit 1;  fi
if [ -z ${threshold+x} ]; then echo "-t is necessary" && exit 1;  fi
if [ -z ${jar_param+x} ]; then echo "-j is necessary" && exit 1;  fi
SPARK_SUBMIT_PROPERTIES="--class ExtractionWriter --master $master --num-executors $num_executors --driver-memory $driver_memory --executor-memory $executor_memory --executor-cores $executor_cores --conf spark.sql.autoBroadcastJoinThreshold=$threshold --driver-java-options \"-Dlog4j.configuration=file:$log_file\" --files $files --jars $lib_jars"
JAR_PARAMETERS="$jar_param"
export SPARK_MAJOR_VERSION=2
 # Set spark version to pick, 2.+
cd $path
# Change directory to project root
spark-submit $SPARK_SUBMIT_PROPERTIES $JAR_PARAMETERS
