while getopts ":p:r:u:w:h:e:x:o:n:" opt; do
  case $opt in
    r) path="$OPTARG"
    ;;
    p) port="$OPTARG"
    ;;
    u) user="$OPTARG"
    ;;
    w) passwd="$OPTARG"
    ;;
    h) host="$OPTARG"
    ;;
    e) epath="$OPTARG"
    ;;
    o) operation="$OPTARG"
    ;;
    n) onhr_extraction="$OPTARG"
    ;;
    \?) echo "Invalid option -$OPTARG" >&2 && exit 1
    ;;
  esac
done
if [ -z ${path+x} ]; then echo "-r is necessary" && exit 1;  fi
if [ -z ${port+x} ]; then echo "-p is necessary" && exit 1;  fi
if [ -z ${user+x} ]; then echo "-u is necessary" && exit 1;  fi
if [ -z ${passwd+x} ]; then echo "-w is necessary" && exit 1;  fi
if [ -z ${host+x} ]; then echo "-h is necessary" && exit 1;  fi
if [ -z ${epath+x} ]; then echo "-e is necessary" && exit 1;  fi
if [ -z ${onhr_extraction+x} ]; then echo "-n is necessary" && exit 1;  fi
if [ -z ${operation+x} ] || [ "$operation" != "rm -r" ] && [ "$operation" != "mirror" ]; then echo "-o is necessary and it has to be \"rm -r\" or \"mirror\"" && exit 1;  fi
cd $path
lftp -p $port sftp://$user:$passwd@$host -e "$operation $epath/$onhr_extraction; bye"