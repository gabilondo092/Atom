while getopts ":l:x:" opt; do
  case $opt in
    l) landing_path_hdfs="$OPTARG"
    ;;
    x) extraction_name="$OPTARG"
    ;;
    \?) echo "Invalid option -$OPTARG" >&2 && exit 1
    ;;
  esac
done
if [ -z ${landing_path_hdfs+x} ]; then echo "-l is necessary" && exit 1;  fi
if [ -z ${extraction_name+x} ]; then echo "-x is necessary" && exit 1;  fi
hadoop fs -rm -r -f $landing_path_hdfs/$extraction_name