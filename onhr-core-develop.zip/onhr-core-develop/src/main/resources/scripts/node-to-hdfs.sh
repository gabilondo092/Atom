while getopts ":l:x:n:" opt; do
  case $opt in
    l) landing_path="$OPTARG"
    ;;
    x) extraction_name="$OPTARG"
    ;;
    n) node_folder="$OPTARG"
    ;;
    \?) echo "Invalid option -$OPTARG" >&2 && exit 1
    ;;
  esac
done
if [ -z ${landing_path+x} ]; then echo "-l is necessary" && exit 1;  fi
if [ -z ${extraction_name+x} ]; then echo "-x is necessary" && exit 1;  fi
if [ -z ${node_folder+x} ]; then echo "-n is necessary" && exit 1;  fi
hadoop fs -rm -r -f $landing_path/$extraction_name; hadoop fs -put -f $node_folder $landing_path