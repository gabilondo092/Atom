while getopts ":d:s:m:" opt; do
  case $opt in
    d) data_file="$OPTARG"
    ;;
    s) file_separator="$OPTARG"
    ;;
    m) metadata_file="$OPTARG"
    ;;
    \?) echo "Invalid option -$OPTARG" >&2 && exit 1
    ;;
  esac
done

if [ -z ${data_file+x} ]; then echo "-d is necessary" && exit 1;  fi
if [ -z ${file_separator+x} ]; then echo "-s is necessary" && exit 1;  fi
if [ -z ${metadata_file+x} ]; then echo "-m is necessary" && exit 1;  fi

FILE_PATH=$data_file
sed -i -e 's/\\|\\//' ${FILE_PATH}
SEP="\\"$file_separator

for line in $(ls -1 ${FILE_PATH})
  do
  echo "$line"
  COLUMNS_LEN=$(awk -F"$SEP" '{print NF; exit}' "$line")
  awk -F"$SEP" -v col="$COLUMNS_LEN" '{if(NF==col) {print $0}}' "$line" > "$line"_new
  mv "$line"_new "$line"
done
awk -v RS= '{$1=$1}1' $metadata_file > "$metadata_file"_clean
mv "$metadata_file"_clean $metadata_file