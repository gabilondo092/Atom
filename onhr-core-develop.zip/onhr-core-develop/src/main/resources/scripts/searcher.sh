route = $1
csvPattern = $2
jsonPattern = $3
mode = $4
sftp_conn = $5

