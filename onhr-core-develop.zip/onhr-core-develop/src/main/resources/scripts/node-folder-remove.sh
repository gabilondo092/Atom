while getopts ":f:" opt; do
  case $opt in
    f) folder="$OPTARG"
    ;;
    \?) echo "Invalid option -$OPTARG" >&2 && exit 1
    ;;
  esac
done
if [ -z ${folder+x} ]; then echo "-f is necessary" && exit 1;  fi
rm -r -f $folder