while getopts ":d:s:m:l:x:f:i:n:r:p:u:w:h:e:X:o:P:g:L:F:j:M:N:D:E:c:t:" opt; do
  case $opt in
    d) data_file="$OPTARG"
    ;;
    s) file_separator="$OPTARG"
    ;;
    m) metadata_file="$OPTARG"
    ;;
    l) landing_path_hdfs="$OPTARG"
    ;;
    x) extraction_name="$OPTARG"
    ;;
    f) folder="$OPTARG"
    ;;
    i) landing_path="$OPTARG"
    ;;
    n) node_folder="$OPTARG"
    ;;
    r) path="$OPTARG"
    ;;
    p) port="$OPTARG"
    ;;
    u) user="$OPTARG"
    ;;
    w) passwd="$OPTARG"
    ;;
    h) host="$OPTARG"
    ;;
    e) epath="$OPTARG"
    ;;
    X) extract="$OPTARG"
    ;;
    o) onhr_extraction="$OPTARG"
    ;;
    P) onhr_core_path="$OPTARG"
    ;;
    g) log_file="$OPTARG"
    ;;
    L) lib_jars="$OPTARG"
    ;;
    F) files="$OPTARG"
    ;;
    j) jar_param="$OPTARG"
    ;;
    M) master="$OPTARG"
    ;;
    N) num_executors="$OPTARG"
    ;;
    D) driver_memory="$OPTARG"
    ;;
    E) executor_memory="$OPTARG"
    ;;
    c) executor_cores="$OPTARG"
    ;;
    t) threshold="$OPTARG"
    ;;
    \?) echo "Invalid option -$OPTARG" >&2 && exit 1
    ;;
  esac
done
#clean-files
if [ -z ${data_file+x} ]; then echo "-d is necessary" && exit 1;  fi
if [ -z ${file_separator+x} ]; then echo "-s is necessary" && exit 1;  fi
if [ -z ${metadata_file+x} ]; then echo "-m is necessary" && exit 1;  fi
#hdfs-folder-remove
if [ -z ${landing_path_hdfs+x} ]; then echo "-i is necessary" && exit 1;  fi
if [ -z ${extraction_name+x} ]; then echo "-x is necessary" && exit 1;  fi
#node-folder-remove
if [ -z ${folder+x} ]; then echo "-f is necessary" && exit 1;  fi
#node-to-hdfs
if [ -z ${landing_path+x} ]; then echo "-i is necessary" && exit 1;  fi #cambiar el -l
if [ -z ${node_folder+x} ]; then echo "-n is necessary" && exit 1;  fi
#sftp-folder
if [ -z ${path+x} ]; then echo "-r is necessary" && exit 1;  fi
if [ -z ${port+x} ]; then echo "-p is necessary" && exit 1;  fi
if [ -z ${user+x} ]; then echo "-u is necessary" && exit 1;  fi
if [ -z ${passwd+x} ]; then echo "-w is necessary" && exit 1;  fi
if [ -z ${host+x} ]; then echo "-h is necessary" && exit 1;  fi
if [ -z ${epath+x} ]; then echo "-e is necessary" && exit 1;  fi
if [ -z ${extract+x} ]; then echo "-X is necessary" && exit 1;  fi #cambiar el -x
#spark-submit-onHR
if [ -z ${onhr_core_path+x} ]; then echo "-P is necessary" && exit 1;  fi #cambiar el -p
if [ -z ${log_file+x} ]; then echo "-g is necessary" && exit 1;  fi
if [ -z ${lib_jars+x} ]; then echo "-L is necessary" && exit 1;  fi #cambiar el -l
if [ -z ${files+x} ]; then echo "-F is necessary" && exit 1;  fi #cambiar el -f
if [ -z ${master+x} ]; then echo "-M is necessary" && exit 1;  fi #cambiar el -m
if [ -z ${num_executors+x} ]; then echo "-N is necessary" && exit 1;  fi #cambiar el -n
if [ -z ${driver_memory+x} ]; then echo "-D is necessary" && exit 1;  fi #cambiar el -d
if [ -z ${executor_memory+x} ]; then echo "-E is necessary" && exit 1;  fi #cambiar el -e
if [ -z ${executor_cores+x} ]; then echo "-c is necessary" && exit 1;  fi
if [ -z ${threshold+x} ]; then echo "-t is necessary" && exit 1;  fi
if [ -z ${jar_param+x} ]; then echo "-j is necessary" && exit 1;  fi
if [ -z ${onhr_extraction+x} ]; then echo "-o is necessary" && exit 1;  fi

echo "mi variable es: $onhr_core_path"

#sh sftp-folder.sh -r $path -p $port -u $user -w $passwd -h $host -e $epath -x $extract -o "mirror" -n onhr_extraction \
#&& sh clean_files.sh d- $data_file -s $file_separator -m $metadata_file \
#&& sh node-to-hdfs.sh -l $landing_path -x $extraction_name -n $node_folder \
#&& sh spark-submit-onHR.sh -p $onhr_core_path -g $log_file -l $lib_jars -f $files -m $master -n $num_executors -d $driver_memory -e $executor_memory -c $executor_cores -t $threshold -j $jar_param \
#&& sh node-folder-remove.sh -f $folder \
#&& sh sftp-folder.sh -r $path -p $port -u $user -w $passwd -h $host -e $epath -x $extract -o "rm -r" \
#&& sh hdfs-folder-remove -l $landing_path_hdfs -x $extraction_name