# onhr-core

Proyecto para la ingesta, transformación, anonimización y publicación de workspaces de la información de SuccessFactors en OnHR.

