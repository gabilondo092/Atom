#!/usr/bin/env bash
clear

#./run_local.sh ExtractionWriter src/main/resources/conf/properties.json EXT_EXAMPLE

# Get the path where the jars are stored locally
repositoryPath=$(mvn help:evaluate -Dexpression=settings.localRepository | grep -v '[INFO]')

# Get the root path of the project
rootPath=$(pwd)
extractionName=input/$4/$4

mvn -Dmaven.test.skip=true package
if [[ $? -eq 0 ]]; then # If the build fails it wont' run the spark-submit
    cp ${extractionName}.json ${extractionName}_bck.json

    awk -v RS= '{$1=$1}1' ${extractionName}.json > ${extractionName}_clean.json
    mv ${extractionName}_clean.json ${extractionName}.json

    # The class to run must be passed as parameter
    spark-submit --class $1  \
                 --driver-java-options "-Dlog4j.configuration=file:src/main/resources/conf/log4j.properties" \
                 --jars ${repositoryPath}/net/liftweb/lift-json_2.11/3.3.0/lift-json_2.11-3.3.0.jar,${repositoryPath}/org/mariadb/jdbc/mariadb-java-client/2.5.1/mariadb-java-client-2.5.1.jar \
                 "${rootPath}/target/onhr-core-3.0.0-SNAPSHOT.jar" $2 $3 $4

    mv ${extractionName}_bck.json ${extractionName}.json
else
    echo "Compilation unsuccessful"
fi
# --files ${rootPath}/src/main/resources/conf/properties.json \